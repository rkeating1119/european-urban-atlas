var c=(b,a)=>()=>(a||b((a={exports:{}}).exports,a),a.exports);export{c as a};
//# sourceMappingURL=map-TI2A7TXP.js.map
