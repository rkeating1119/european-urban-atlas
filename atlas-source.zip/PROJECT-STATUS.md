# Live native speech release · November 12, 2026

Production: https://rkeating1119.github.io/european-urban-atlas/
Speech: https://rkeating1119.github.io/european-urban-atlas/listen/

Release `7eb1e7c9d96f` is live. GitHub Pages run 43305245650 succeeded from commit `4404384b2d828e42bbd625a33306fa75fd652784`. All 48 site samples and 19 speech/city-page/audio-format samples match the tested artifact; public ZIP SHA256 is394f183afe87cfe2c9e6fa94867ac210ff44f9902109ac673b69b21b591fc78d. Live London city-page playback passes. The source and deployment process are preserved.

## Current audio requirement

Audio means native speakers speaking their local language/variety so readers can hear language and accents. The user rejected soundscapes. Do not restore ambient recordings or the historical OldIrishliterary reading. Recording location alone is insufficient proof of a city accent. Require speaker-origin evidence and suitable reuse rights. All rejected work remains in Git/local archives; build ships only active verified speech assets.

Four examples are currently published: London English (Benedict Cumberbatch, BBC interview), Dublin English (native VCTK participant p245, documented Dublin region, modern read speech), Berlin German (Gregor Gysi, verified speaking interval00:22–00:45), Stockholm Swedish (Greta Thunberg self-introduction identifying Stockholm). Both English and Spanish pages include the recordings; covered city pages have a Language and accent jump link. Sources, rights, speaker origins, actual recording sites and excerpt details are displayed. Audio loads only on request; both Opus and AAC are available.

The first ten-city group is PARTIAL. Madrid, Paris, Rome, Zurich, Athens and Oslo still need suitable verified speech. No full ten-city native coverage is claimed. Do not advance to second/third city groups until the first group is completed where suitable recordings can be found, or its genuine gaps are explicitly accepted. Follow the user's request to publish incrementally and limit repeated research/usage.

## Existing functionality and remaining expansion

Preserved:417 bilingual city profiles across10 countries,123 regions,8,730-place explorer/all 8132Spanishmunicipalities, four basemaps and independently sourced national map layers,2012/2016 historical night lights, return-map continuity. The new release also includes the previously saved first 10 capital timelines (83 milestones),27 calendar entries and4 cultural additions. Further city timelines, additional thematic layers and expanded comparison remain unfinished; do not describe the wider handoff as complete.

Evidence: docs/AUDIO-BATCHES.json, docs/SPEECH-NORTH-RESEARCH.json, docs/SPEECH-SOUTH-RESEARCH.json, docs/PUBLIC-NATIVE-SPEECH-RELEASE.json, docs/PUBLIC-SPEECH-PLAYBACK-ASSETS.json, docs/TIMELINE-RESEARCH.json and map/reader audits. Previous continuation notes are archived in docs/archive/PROJECT-STATUS-2026-11-12-before-native-publication.md.

## Publishing

Use the authenticated GitHub tab inside the in-app browser, not native Chrome. The user signed in there on November 12; this avoids interrupting their Chrome work. File chooser API uploads work with absolute local archive paths. Updating atlas-site.zip on main triggers the established Pages workflow. Publish and verify each useful batch before broader work. Current immutable site archive: outputs/releases/7eb1e7c9d96f/atlas-site.zip (relative to the enclosing workspace, not this repo). Matching source/history backups are being updated after public verification. Normal builds use saved JSON; authoring environments are optional.
