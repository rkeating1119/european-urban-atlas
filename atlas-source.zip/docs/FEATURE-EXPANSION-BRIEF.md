# Approved feature expansion · November 8, 2026

The user explicitly approved carrying out the wider attached Master Project Handoff after publishing the popup/country-map fixes. The complete attachment is preserved locally in work/feature-expansion/handoff.txt. Direct instructions in this conversation take precedence over that consolidated handoff. Build on the current published ten-country, 417-city English/Spanish edition; do not reconstruct it or discard content.

## First publication

City popups must appear above region and city labels. The Europe-wide map is country selection only: no city or regional hover cards or direct city targets. Country names and incorporated country shapes select countries. National/regional maps retain city dots, hover summaries and independent region-name links.

## Wider approved work

- Audit the current geographic inventory, map architecture, sources, data rights, content and performance before major implementation.
- Improve continuous geographic exploration and real zoom-dependent detail. Add independent atlas/topographic/satellite/dark basemaps and reusable controls for genuinely sourced physical/human layers, opacity, legends, inspection and honest country/date coverage.
- Requested layer subjects include terrain, hydrology, ecosystems, climate/environment, population, night illumination, rail/roads, urbanization, linguistic areas and historical geography. Genuine historical datasets should have date controls, manual scrubbing and play/pause; never fabricate temporal coverage.
- Preserve curated substantial city profiles and country-aware administrative systems. Restore the broader searchable geographic directory, including all indexed Spanish municipalities, without forcing long articles onto minor settlements. City-profile counts are flexible, not fixed quotas.
- Improve profiles with locally evidenced daily rhythms, aesthetics, rituals, annual calendars/holidays, languages/accents, cultural history and relevant figures. Expanded content must add information, avoid repetitive templates and unsupported resident stereotypes, and remain navigable.
- Keep comparisons compact, with immediate inline expansion of researched context, geographic differences and sources. Add meaningful qualitative categories without arbitrary scores; previous user instructions retain the existing explained scores. Synchronized paired city maps are desirable if technically straightforward.
- Add random geographic exploration across the indexed directory, with map animation, a valid preview/profile, country/region/place options where supported and short-session repeat avoidance.
- Independently source authentic language/variety recordings and city soundscapes. Use reusable lazy audio components, actual recording locations, accurate linguistic scope, transcripts/translations where available and verified reuse rights. Shared regional speech may serve relevant cities if honestly labeled. Missing suitable audio stays unavailable; no generated audio masquerading as authentic recordings.
- Independently research and integrate reusable interactive city timelines, with meaningful dated milestones, concise context, source links and geographic/media connections when real evidence exists. The suggested8–15events is not a quota; never invent dates or filler to reach it.
- Keep static-first architecture, stable IDs, saved bilingual content, current references and no paid services or new hosting identity. Preserve the existing GitHub Pages URL and complete actual public deployment.
- Measure responsiveness, payload and interaction behavior; test desktop, phone and iPad-sized portrait/landscape/touch environments. Do not claim physical iPad/Safari testing without actual hardware/browser evidence.

## Completion reporting

Track component implementation separately from researched content and verified rights/coverage. Record planned, started, tested and published states honestly in PROJECT-STATUS.md. A coded player or timeline with no sourced content is not a completed feature. Initial audit, implementation, integration and deployment milestones need meaningful updates. Do not stop at a local preview or archive. Preserve matching source/history and public proof.
