# Expansion starting audit · November 8, 2026

This audit starts from the existing production reader edition; it is not a reconstruction. The complete bilingual source and prior release history are preserved. The user approved the broader handoff after the immediate map correction.

## Existing foundation

- The current reader contains417 substantial city profiles and123 regions across ten countries in both English and Spanish. All articles are pre-rendered; bibliography and population definitions are retained.
- The original Spain geographic foundation still contains8,132 municipal entries,52 provincial-level references (50 provinces plus the autonomous cities),19 first-level units and68 independently dated functional urban areas. Municipality polygons are partitioned by province and available for lazy loading. These are preserved but disconnected from the current reader build.
- Country-aware adapters, relationship validation and old directory templates are saved. France/Italy's old adapter placeholders must not be confused with the ten-country curated reader catalog.
- MapLibre5.24 renders packaged world/regional geography, city circles, city and regional text links, saved camera state and insets. There is no real street or building basemap: maxZoom14 only enlarges the existing generalized geometry. Basemap/layer controls, genuine historical data controls and layer inspection need new work.
- In-page menus, aliases, search, city carousels, explanatory comparisons, language/sound controls and static route validation work. Comparisons have16 full categories but no compact inline detail expansion or paired map view.
- There are no implemented speech/soundscape modules, recording-rights registry, interactive city timelines or directory-wide random exploration.

## Immediate map repair

A missing popup stacking priority allowed positioned text labels to cover the card. The popup container now sits at5, above city labels2 and region/leader labels1. Browser overlap hit tests for Cologne pass over three regional names and two city names. The Europe overview now supplies an empty city collection, suppresses city handlers and keeps country-name links visible at closer zoom. Incorporated country shapes can also select countries. Country/city maps retain their established city behavior. All existing map, TypeScript, worker and content tests pass. Publication is being completed before wider changes.

## Implementation decisions

Preserve the static-first renderer and stable IDs. Add reusable TypeScript modules and structured bilingual feature JSON rather than replacing the application with a framework. Keep geographic directory data separate from long-form articles, load larger boundaries/media only when requested, and let component coverage differ from data coverage. Reuse the actual municipal hierarchy and validated references. Do not infer unavailable data or record generic audio as a city-specific sample.

Research/data priorities: inspect official basemap/tile terms and real maximum zoom; acquire licensed physical geography and dated population/built-area layers; identify genuine temporal coverage; source authentic recordings with individual rights; research actual city milestones. No paid infrastructure, new account or invented historical continuity.

## Quality and known limits

The reader's previous0-error audits concern its established scope; the new features need their own validation. Generalized outlines can differ from accurate coastal point locations. Several countries still lack comparable municipal population metadata, and the previous HTTP audit records blocked/transient sources separately from confirmed dead links. A new UI must never imply full European coverage for a partial dataset. Responsive browser tests are not actual iPad Safari certification.

The preserved architecture can support the expansion. Data sourcing, rights verification, multilingual content and per-city historical review are the substantial remaining work, not just coding the controls. Track those separately in PROJECT-STATUS.md and the feature registry.
