# Reader edition audit

This audit checks the revised city-selection, writing and comparison requirements. The previous all-municipality completion target is superseded by the user’s curated city scope.

Result: **PASS** · 0 material errors · 21 review notes.

Mode: final selection. Built site checked: yes. Generated 2026-11-08T18:13:28.111551+00:00.

## What a reader may look for

The matrix checks actual summaries, named categories or text signals. A mention is not a guarantee of suitability. Family/student/language topics vary by place rather than being filled with invented advice.

| Reader interest | Spain | France | Italy | United Kingdom | Ireland | Germany | Switzerland | Greece | Norway | Sweden |
|---|---|---|---|---|---|---|---|---|---|---|
| Quick impression | 60/60 | 51/51 | 50/50 | 50/50 | 25/25 | 50/50 | 30/30 | 35/35 | 31/31 | 35/35 |
| General city life | 60/60 | 51/51 | 50/50 | 50/50 | 25/25 | 50/50 | 30/30 | 35/35 | 31/31 | 35/35 |
| Geography and city layout | 60/60 | 51/51 | 50/50 | 50/50 | 25/25 | 50/50 | 30/30 | 35/35 | 31/31 | 35/35 |
| Architecture and visual character | 60/60 | 51/51 | 50/50 | 50/50 | 25/25 | 50/50 | 30/30 | 35/35 | 31/31 | 35/35 |
| What neighborhoods are like | 60/60 | 51/51 | 50/50 | 50/50 | 25/25 | 50/50 | 30/30 | 35/35 | 31/31 | 35/35 |
| Housing and inequality | 60/60 | 51/51 | 50/50 | 50/50 | 25/25 | 50/50 | 30/30 | 35/35 | 31/31 | 35/35 |
| Work and the economy | 60/60 | 51/51 | 50/50 | 50/50 | 25/25 | 50/50 | 30/30 | 35/35 | 31/31 | 35/35 |
| Culture and public life | 60/60 | 51/51 | 50/50 | 50/50 | 25/25 | 50/50 | 30/30 | 35/35 | 31/31 | 35/35 |
| Local food | 60/60 | 51/51 | 50/50 | 50/50 | 25/25 | 50/50 | 30/30 | 35/35 | 31/31 | 35/35 |
| Important history | 60/60 | 51/51 | 50/50 | 50/50 | 25/25 | 50/50 | 30/30 | 35/35 | 31/31 | 35/35 |
| Getting around | 60/60 | 51/51 | 50/50 | 50/50 | 25/25 | 50/50 | 30/30 | 35/35 | 31/31 | 35/35 |
| Weather through the year | 60/60 | 51/51 | 50/50 | 50/50 | 25/25 | 50/50 | 30/30 | 35/35 | 31/31 | 35/35 |
| Nature and outdoor time | 60/60 | 51/51 | 50/50 | 50/50 | 25/25 | 50/50 | 30/30 | 35/35 | 31/31 | 35/35 |
| Education and schools | 60/60 | 51/51 | 50/50 | 50/50 | 25/25 | 50/50 | 30/30 | 35/35 | 31/31 | 35/35 |
| Dated politics and civic life | 60/60 | 51/51 | 50/50 | 50/50 | 25/25 | 50/50 | 30/30 | 35/35 | 31/31 | 35/35 |
| LGBT life and institutions | 60/60 | 51/51 | 50/50 | 50/50 | 25/25 | 50/50 | 30/30 | 35/35 | 31/31 | 35/35 |
| Population and social relations | 60/60 | 51/51 | 50/50 | 50/50 | 25/25 | 50/50 | 30/30 | 35/35 | 31/31 | 35/35 |
| Student and university life | 60/60 | 51/51 | 50/50 | 50/50 | 25/25 | 50/50 | 29/30 | 35/35 | 31/31 | 35/35 |
| Families, schools and children | 60/60 | 51/51 | 50/50 | 50/50 | 25/25 | 50/50 | 30/30 | 35/35 | 31/31 | 35/35 |
| Nightlife and social opportunities | 59/60 | 50/51 | 49/50 | 50/50 | 25/25 | 50/50 | 30/30 | 35/35 | 28/31 | 35/35 |
| Language and settling in | 60/60 | 23/51 | 17/50 | 26/50 | 24/25 | 13/50 | 27/30 | 5/35 | 20/31 | 32/35 |
| Major suburbs and satellite cities | 4/60 | 3/51 | 1/50 | 2/50 | 4/25 | 0/50 | 5/30 | 5/35 | 2/31 | 3/35 |
| Clear compromises | 60/60 | 51/51 | 50/50 | 50/50 | 25/25 | 50/50 | 30/30 | 35/35 | 31/31 | 35/35 |

## Previous edition review

The first edition overemphasized administrative completeness and audit language. Its abstract thesis statements did not give readers a useful quick impression, and its short notes did not cover the practical categories consistently. The revised checks specifically address those defects.

- The public selection is curated cities and major suburbs; the exhaustive municipality catalog is no longer the browsing experience.
- A concise plain-language summary appears before the detailed reading sections.
- Each city has a general everyday-life overview and fifteen sections, including separate geography/architecture and detailed education, politics, LGBT and population topics.
- Sources and score explanations remain accessible in collapsed disclosures, without evidence classifications interrupting the prose.
- Comparison uses the real city summaries plus seven explained category ratings and clear compromises.
- In-page country selection and top-ten city labels are tested explicitly; deployment requires separate public access verification.

## Writing and selection

| Country | Cities | Regions | Section words | Mean sentence length |
|---|---:|---:|---:|---:|
| ES | 60 | 19 | 90,859 | 16.9 words |
| FR | 51 | 18 | 71,213 | 16.4 words |
| IT | 50 | 20 | 81,724 | 18.1 words |
| GB | 50 | 12 | 62,613 | 15.0 words |
| IE | 25 | 3 | 32,086 | 14.0 words |
| DE | 50 | 16 | 63,895 | 15.3 words |
| CH | 30 | 7 | 37,771 | 14.9 words |
| GR | 35 | 13 | 39,240 | 20.5 words |
| NO | 31 | 7 | 44,466 | 16.7 words |
| SE | 35 | 8 | 50,804 | 16.7 words |

Exact duplicate reading paragraphs: 0. Similar paragraph pairs flagged: 3201.

The content checks require fifteen substantive two-or-more-paragraph sections, a general overview, a short top summary, named neighborhood signals, actual food discussion, seven explained category scores, sources and clear compromises. Unknown financial or population values are allowed to remain unknown.

## Navigation, maps and comparison

- All built HTML links/assets/anchors, redirects, stylesheet url() imports and JavaScript chunks resolve under the configured GitHub Pages base path.
- Every regional boundary and featured city point is packaged. Ten principal cities per country carry permanent names, using explicit selections where population metadata is not comparable. Other cities have hover cards and direct taps. Zoom scaling and marker anchoring require separate browser checks.
- Client data and source inspected for short summaries, seven scored-and-explained categories and compromises; live behavior remains a separate browser check.
- Seven explained 1–5 editorial categories; no arbitrary overall score, missing price or salary figures are not fabricated.

HTML pages: 1253. Internal targets: 44919. Section fragments: 16743. Hosting base path: `/european-urban-atlas`.

Country dropdowns, direct city routes, source disclosure controls and image alternatives are checked in the built documents. Browser gestures, layout, keyboard use and the live comparison still require the separate browser audit.

## Material findings

No material structural/content defects were found by this run.

## Review notes

- **city-outside-region**: Map point lies outside its stated regional polygon — spain/city/a-coruna
- **city-outside-region**: Map point lies outside its stated regional polygon — spain/city/ceuta
- **city-outside-region**: Map point lies outside its stated regional polygon — spain/city/melilla
- **city-outside-region**: Map point lies outside its stated regional polygon — france/city/ajaccio
- **population-not-published**: 1 cities omit unknown population rather than inventing it — france
- **population-not-published**: 50 cities omit unknown population rather than inventing it — united-kingdom
- **population-not-published**: 25 cities omit unknown population rather than inventing it — ireland
- **population-not-published**: 50 cities omit unknown population rather than inventing it — germany
- **population-not-published**: 30 cities omit unknown population rather than inventing it — switzerland
- **city-outside-region**: Map point lies outside its stated regional polygon — greece/city/alexandroupoli
- **city-outside-region**: Map point lies outside its stated regional polygon — greece/city/corfu
- **population-not-published**: 35 cities omit unknown population rather than inventing it — greece
- **city-outside-region**: Map point lies outside its stated regional polygon — norway/city/stavanger
- **city-outside-region**: Map point lies outside its stated regional polygon — norway/city/alesund
- **city-outside-region**: Map point lies outside its stated regional polygon — norway/city/bodo
- **city-outside-region**: Map point lies outside its stated regional polygon — norway/city/molde
- **city-outside-region**: Map point lies outside its stated regional polygon — norway/city/narvik
- **population-not-published**: 31 cities omit unknown population rather than inventing it — norway
- **city-outside-region**: Map point lies outside its stated regional polygon — sweden/city/karlskrona
- **population-not-published**: 35 cities omit unknown population rather than inventing it — sweden
- **similar-reading-paragraphs**: Review similar paragraphs for generic or copied descriptions — [{'section': 'people', 'cities': ['ES:sevilla', 'ES:dos-hermanas'], 'wordSetSimilarity': 1.0}, {'section': 'people', 'cities': ['ES:murcia', 'ES:cartagena'], 'wordSetSimilarity': 1.0}, {'section': 'people', 'cities': ['ES:las-palmas', 'ES:santa-cruz-tenerife'], 'wordSetSimilarity': 1.0}, {'section': 'people', 'cities': ['IT:palermo', 'IT:catania'], 'wordSetSimilarity': 1.0}, {'section': 'education', 'cities': ['ES:barcelona', 'ES:girona'], 'wordSetSimilarity': 0.968}, {'section': 'education', 'cities': ['ES:barcelona', 'ES:tarragona'], 'wordSetSimilarity': 0.968}, {'section': 'education', 'cities': ['ES:barcelona', 'ES:palma'], 'wordSetSimilarity': 0.968}, {'section': 'education', 'cities': ['ES:barcelona', 'ES:reus'], 'wordSetSimilarity': 0.968}, {'section': 'education', 'cities': ['ES:barcelona', 'ES:terrassa'], 'wordSetSimilarity': 0.968}, {'section': 'education', 'cities': ['ES:barcelona', 'ES:lleida'], 'wordSetSimilarity': 0.968}, {'section': 'education', 'cities': ['ES:girona', 'ES:tarragona'], 'wordSetSimilarity': 0.968}, {'section': 'education', 'cities': ['ES:girona', 'ES:palma'], 'wordSetSimilarity': 0.968}, {'section': 'education', 'cities': ['ES:girona', 'ES:reus'], 'wordSetSimilarity': 0.968}, {'section': 'education', 'cities': ['ES:girona', 'ES:terrassa'], 'wordSetSimilarity': 0.968}, {'section': 'education', 'cities': ['ES:girona', 'ES:lleida'], 'wordSetSimilarity': 0.968}]

## Public access

Public URL: https://rkeating1119.github.io/european-urban-atlas/. Checked: True. All sampled routes passed: True.

A successful static audit is not evidence of public publication. Use `--require-public` after deploying, and open the actual production URL in an ordinary browser.

## Limits

This is a content and implementation audit, not a statistical certification of subjective ratings or a claim that every linked source was available. It does not invent prices, salaries, quotations, resident opinions or current construction status. Source HTTP checks and substantive fact review remain separate. The complete JSON report contains per-city section lengths, named-detail signals and every finding.
