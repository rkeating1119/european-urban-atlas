# Native speech publication in progress · November 12, 2026

Corrected release 7eb1e7c9d96f contains four verified native-speaker examples: London English (Benedict Cumberbatch), Dublin English (VCTK participant p245, modern read speech), Berlin German (Gregor Gysi, verified speaking interval00:22–00:45), Stockholm Swedish (Greta Thunberg self-introduction identifying Stockholm). Speaker origins and recording sites are separate. London/Stockholm/Berlin sources are openly licensed Commons recordings with primary speaker-origin evidence; Dublin is original University Edinburgh corpus CC BY4 with documented Dublin region/nativeEnglish. All8Opus/AAC files decode; bilingualrecords, source/rights/segmentattribution are in docs/SPEECH-NORTH-RESEARCH.json and docs/SPEECH-SOUTH-RESEARCH.json. Six other first-batchcities remain genuinelyunavailable; no fullten-city nativecoverage isclaimed. Allactive soundscapes and the OldIrishreading were removed. Oldfiles/history remain preserved locally; build ships only activeverifiedspeechassets.

The user signed into GitHub in the in-appbrowser, enabling independent filechooseruploads without Chrome interference. Bound publishing tab githubUpload currently uploading outputs/atlas-site.zip (7eb1e7c9d96f); use this route for futurebatches. Do not revert to nativeChrome. Authorizations persist. GitHubpublicmainstillmaps-only at lastcheck; the earlier rejectedbatch servercommit remainedunobserved (monitor, do notclaimcancelled). Finishcorrecteduploadcommit, verifyPagesworkflow and public /listen/ playback, then update config/reportsand matching sourcebackup. This is the immediatepriority beforemore research.

# Correction: native speech only · November 12, 2026

The user rejected ambient soundscapes. Audio means native speakers from each city speaking the local language/variety, so readers can hear accents. Recording location alone does not prove speaker origins. Historical Old Irish literary reading and unverified-originMadridoralhistory also fail that purpose. The rejectedfirstaudio batch d07c9ebcc0eb is preserved in Git/artifacts but must not be presented as completed native speech. Rootstartedupload+commitbeforecorrection; GitHub UI saysProcessingyourfiles but APIstillshowsmain a19b427fe0f242da1a2d61fb7341704ff5295bdd/maps-only and no newerworkflow as of lastcheck. Monitorandcancelwrongrunifitappears; publishcorrectedverifiedspeechdata instead. Do not claim the incorrectqueuedcommitwas successfullycancelled.

Activeaudio.jsonwascleared; user-facingrendererrequireskind=speech and documented speaker.originSourceUrl. All rejectedfiles/research remain locallypreserved; futurebuild copiesonlyactiveverifiedspeechassets. Native-speech agents are researchingfirsttenlargestcitieswithaccuratespeakerorigin/native-languageevidence. UI nowLanguagesandaccents/Lenguas y acentos. Publishfirstauthenticverifiedsamplespromptly andstateactualcitycoveragehonestly; no inventedquota-filling. Nextbatchesafterfirstcorrectedpublication.

# Immediate continuation: publish audio batch 1

November12: first ten-city audio release d07c9ebcc0eb is ready and fully saved. Local commit911b6fe includes all implementation/data. outputs/atlas-site.zip is25,918,136bytes, SHA256dfea06d2a83b0b410e32a98e09b07da3a4f286067e707410b42448cd60889cc8. Matching source outputs/atlas-source.zip is24,754,925bytes, SHA256381a32848e4f970d4ebeecbdc34afbf5d7df83d32aff34ba9c101ad35efff459. Immutable site copy: outputs/releases/d07c9ebcc0eb/atlas-site.zip. Complete Git bundle also saved.

Publication blocker: nativeChrome controls were repeatedly interrupted by concurrent use, then timed out/reset. User was asked through the asynchronous input tool to leave Chrome on the GitHub Upload files tab for about2minutes and reply ready. Do not mistake the local preview for publication: current live production is still bf37b88c6dea (maps). No audio upload or new workflow run occurred yet. The upload tab was logged in asowner. When access returns, upload atlas-site.zip (and preferably matching atlas-source.zip) to repository main via established UI, commit, verify workflow and public /listen/ exactrelease+actualplayback. Never reconstruct or discard this work. Current CUA kernel reset; initialize from observed state afresh. Local preview4173 is alive; /listen/ and /es/listen/ show ten cities. Browser playback of Madrid, Paris andLondon was verified; all24Opus/AAC files decode, correct source hashes andscopes recorded. Do not research secondten until firstbatch ispubliclyverified.

# Audio first: ten-city batches · November 12, 2026

The user now prioritizes audio, one largest city per country first, then the second and third city in each. Publish each ten-city batch immediately after verification; preserve the existing work and avoid repeating research. docs/AUDIO-BATCHES.json records the batch and subsequent pending work.

First audio batch d07c9ebcc0eb is built, locally tested and ready to publish. All ten have recordings explicitly from their location: Madrid, Paris, Rome, London, Dublin, Berlin, Zurich, Athens, Oslo and Stockholm. There are12preserved recording records overall (the extra two are previously researched regional examples), each with Opus and AAC assets, source/creator/date/rights and truthful scope. Madrid and Dublin clips contain speech; the remaining first-batch recordings are labelled ambient soundscapes. /listen/ and /es/listen/ show the first batch and the homepage links to it. No audio is fetched before Listen. Phone playback, pause, other-player stopping, Spanish labels and no-overflow checks pass; all24mediafiles decode and match research hashes. The release also includes already-saved ten-capital timelines and27calendar entries; their source coverage is separately documented.

Current live map release bf37b88c6dea was verified across48publicfiles withmatching fullarchiveSHA. Audio publication is being completed next. Second/third audio batches, othercitytimelines, expandedcomparison andadditionalthematicmaps remain pending. Do not claim full widerexpansion complete.

# Incremental feature publication · November 11, 2026

The user requests separate verified publications: maps/explorer, then history, then audio/calendars, while continuing the same task. Preserve each release and report its live verification before proceeding to the next integration.

Maps/explorer implementation and local checks are ready. New directory: 8,730 places including all 8,132 Spanish municipalities and68functional urban areas. Four independent basemaps, real close street detail, six country-clipped Natural Earth subjects, Spain provincial population density, and genuine2012/2016masked nightlights. Actual data and responsive/interaction audit files are docs/MAP-FEATURE-AUDIT.json, docs/MAP-GEOMETRY-QA.json and docs/MAP-BROWSER-QA.json. Coverage limits are explicit: ecosystems, climate, pollution, language areas and political historical layers still require data and implementation.

Maps release bf37b88c6dea is committed remotely as a19b427fe0f242da1a2d61fb7341704ff5295bdd; deployment43099153113 is waiting during the confirmed GitHub Actions/Pages outage (November11). The exact24,249,622-byte artifact is preserved in outputs/releases/bf37b88c6dea/ and GitHub. History batch45f8f0b49b70 is built and locally tested:10capitals,83events,66sources, EN/ES. Its source and separate artifact are saved;407city timelines remain pending. Do not claim this batch live until deployment succeeds and its exact release is checked publicly. History/media research is saved separately and will be integrated after map publication. Current production remains the prior popup/country-only fix releaseaf060ef83156.

# Feature expansion in progress

The user approved the wider November8handoff after the immediate map fixes. See docs/FEATURE-EXPANSION-BRIEF.md. Production now includes the verified map fix, release af060ef83156, GitHub Pages run42524765328. The broader layers, historical controls, richer modules, audio, random exploration, comparison expansion and city timelines are new work and are not yet complete.

The popup/country-only-map change is implemented locally, TypeScript and map/worker/content checks pass, and browser verification confirms popup z-index5 above overlapping city/region labels and Europe with10country labels and no city/region labels through zoom5.84. The exact archive checksum and public country-only overview/popup hit tests are verified. Wider implementation is next.

## Previous reader release

# Ten-country edition live and verified

The permanent site https://rkeating1119.github.io/european-urban-atlas/ now serves release `33e920cbab96`:417 cities,123 regions,10 countries and complete English/Spanish editions. GitHub Pages run42508762817 succeeded; the public archive checksum and49 unauthenticated public samples match the local release.

The saved development environment was recovered without a reset. Recovery commit6197f02 preserved the previous uncommitted work; review files and the served draft were backed up before finalization. Remaining exact paired reviews, finite prose/category corrections, source-link repairs and publication are complete. All Spanish files are reviewed, frozen and tied to current English hashes. Strict build and audits pass with0 errors.

Read RELEASE-REPORT.md, docs/LANGUAGE-REVIEW.json, docs/LANGUAGE-SCREENING.json, docs/READER-AUDIT.json, docs/READER-SOURCE-LINKS.json and docs/BROWSER-QA-READER.json for evidence and limitations. Historical drafts/reports remain in Git and docs/archive. Normal builds use saved JSON and do not require translation models.

Remaining maintenance: dated content refreshes, restricted/inconclusive source links and missing comparable population figures. No requested implementation or production deployment remains pending.
