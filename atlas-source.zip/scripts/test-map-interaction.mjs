import { build } from 'esbuild';
import { readFileSync, readdirSync } from 'node:fs';
import assert from 'node:assert/strict';
const bundle = await build({entryPoints:['src/map-hit.ts'],bundle:true,write:false,format:'esm',platform:'node'});
const { nearestCity, cityDotHitRadius } = await import('data:text/javascript;base64,'+Buffer.from(bundle.outputFiles[0].text).toString('base64'));
const cities = readdirSync('public/data/editorial').filter(x=>x.endsWith('.json')).flatMap(file=>JSON.parse(readFileSync('public/data/editorial/'+file)).cities);
let checks=0;
for (const zoom of [4.3,5.3,7,10]) {
 const scale=512*2**zoom;
 const project=([lon,lat])=>({x:(lon+180)/360*scale,y:(.5-Math.log(Math.tan(Math.PI/4+lat*Math.PI/360))/(2*Math.PI))*scale});
 for (const city of cities) {
  const p=project([city.lon,city.lat]);
  const selected=nearestCity(cities,project,p,23);
  assert.equal(selected?.id,city.id,'An exact city coordinate must resolve to that city');
  const nearby=nearestCity(cities,project,{x:p.x+11,y:p.y+9},23);
  assert(nearby?.countryId,'A padded mobile tap must still select a city, never a region');
  checks+=2;
 }
}
assert.equal(nearestCity([{lon:0,lat:0}],([x,y])=>({x,y}),{x:50,y:50},23),undefined,'Background taps must not invent a city');
const onlyCity={id:'city',lon:0,lat:0};
assert.equal(nearestCity([onlyCity],([x,y])=>({x,y}),{x:9,y:0},cityDotHitRadius(10))?.id,'city','A visible dot edge must beat overlapping region text at street zoom');
assert.equal(nearestCity([onlyCity],([x,y])=>({x,y}),{x:9,y:0},cityDotHitRadius(2)),undefined,'Region text outside the small zoomed-out dot must remain a region link');
console.log(`PASS: ${checks+3} city selection checks across country and street zooms; padded mobile targets; background taps; visible-dot overlap`);
