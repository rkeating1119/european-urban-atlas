#!/usr/bin/env python3
"""Validate packaged map data and the complete indexed directory."""
from pathlib import Path
import json,math
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'dist/client';errors=[]
def check(ok,message):
    if not ok:errors.append(message)
def read(p):return json.loads(p.read_text())
m=read(OUT/'data/features/maps/manifest.json');counts={}
for layer in m['layers']:
    check(bool(layer['legend']['en'])and bool(layer['legend']['es']),layer['id']+' legend')
    for cc,count in layer['countries'].items():
        geo=read(OUT/f'data/features/maps/{cc}/{layer["id"]}.geojson')
        check(count==len(geo['features']),cc+':'+layer['id']+' count')
        for f in geo['features']:
            check(f['geometry']['type']in({'LineString','MultiLineString'}if layer['type']=='line'else{'Polygon','MultiPolygon'}if layer['type']=='fill'else{'Point','MultiPoint'}),cc+':'+layer['id']+' geometry')
            if layer['id']=='density':check(f['properties']['population']>0 and math.isfinite(f['properties']['density']),cc+' density')
        counts[layer['id']]=counts.get(layer['id'],0)+count
for cc,years in m['nightlights'].items():
    check(set(years)=={'2012','2016'},cc+' epochs')
    for year,images in years.items():
        check(bool(images),cc+' missing imagery '+year)
        for image in images:
            p=OUT/'data/features/maps'/image['url'];check(p.exists()and p.read_bytes().startswith(b'\x89PNG\r\n\x1a\n'),cc+' PNG')
            check(len(image['coordinates'])==4 and all(-180<=c[0]<=180 and -85.06<=c[1]<=85.06 for c in image['coordinates']),cc+' image corners')
d=read(OUT/'data/directory.json');ids=[p['id']for p in d['entries']]
check(len(set(ids))==len(ids),'Directory duplicate IDs');check(sum(p['kind']=='municipality'and p['countryId']=='ES'for p in d['entries'])==8132,'All Spanish municipalities indexed');check(sum(p['kind']=='functional-urban-area'for p in d['entries'])==68,'All Spanish functional urban areas indexed')
for p in d['entries']:
    check(-180<=p['lon']<=180 and -90<=p['lat']<=90,p['id']+' coordinate')
    if p.get('profile'):check((OUT/p['profile'].lstrip('/')/'index.html').exists(),p['id']+' profile')
summary={'release':read(OUT/'data/release.json')['release'],'errors':errors,'directoryEntries':len(ids),'spanishMunicipalities':8132,'functionalUrbanAreas':68,'featureCounts':counts,'nightlightCountries':list(m['nightlights']),'years':[2012,2016],'payloadBytes':{'index':(OUT/'data/atlas-index.json').stat().st_size,'fullComparisonIndex':(OUT/'data/atlas.json').stat().st_size,'directoryLazy':(OUT/'data/directory.json').stat().st_size},'limits':['Generalized Natural Earth overlays are not exhaustive local networks.','Satellite and shaded relief are coarse 2004 Blue Marble; street data is live.','Population density is Spain provincial-level only.','Ecosystem/climate/pollution/language-area/political-history layers are not supplied in this batch.']}
(ROOT/'docs/MAP-FEATURE-AUDIT.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False,indent=2));raise SystemExit(bool(errors))
