#!/usr/bin/env python3
"""Local bilingual transfer/meaning checks; writes every prose pair for editorial review."""
from pathlib import Path
import argparse,hashlib,json,re,sqlite3,time
from collections import Counter
from audit_reader_edition import prose_pairs,words
ROOT=Path(__file__).resolve().parents[1]
def main():
 p=argparse.ArgumentParser();p.add_argument('--country');p.add_argument('--limit',type=int);p.add_argument('--no-semantic',action='store_true');p.add_argument('--include-stale',action='store_true');a=p.parse_args()
 pairs=[];states={}
 for ep in sorted((ROOT/'public/data/editorial').glob('*.json')):
  if a.country and ep.stem not in a.country.split(','):continue
  sp=ep.parent/'es'/ep.name
  if not sp.exists():continue
  source_bytes=ep.read_bytes();spanish_bytes=sp.read_bytes();en=json.loads(source_bytes);es=json.loads(spanish_bytes);source_hash=hashlib.sha256(source_bytes).hexdigest()
  if es.get('translationSourceHash')!=source_hash and not a.include_stale:
   print('SKIP stale translation:',ep.stem,flush=True);continue
  states[ep.stem]={'sourceHash':source_hash,'spanishHash':hashlib.sha256(spanish_bytes).hexdigest(),'translatedSourceHash':es.get('translationSourceHash'),'status':es.get('translationStatus')}
  for loc,source,target in prose_pairs(en,es):
   pairs.append({'country':ep.stem,'location':loc,'english':source,'spanish':target})
 if a.limit:pairs=pairs[:a.limit]
 if not a.no_semantic:
  import numpy as np,torch
  from sentence_transformers import SentenceTransformer
  torch.set_num_threads(2)
  model=SentenceTransformer(str(ROOT.parent/'models/multilingual-minilm'),device='cpu',local_files_only=True);model.max_seq_length=256
  db=sqlite3.connect(ROOT/'work/spanish-embeddings.sqlite');db.execute('CREATE TABLE IF NOT EXISTS vectors (key TEXT PRIMARY KEY, vector BLOB)');vectors={}
  unique=list(dict.fromkeys(s for r in pairs for s in [r['english'],r['spanish']]if s));missing=[]
  def key(s):return hashlib.sha256(('minilm-256-v1:'+s).encode()).hexdigest()
  for s in unique:
   row=db.execute('SELECT vector FROM vectors WHERE key=?',(key(s),)).fetchone()
   if row:vectors[s]=np.frombuffer(row[0],dtype=np.float32)
   else:missing.append(s)
  start=time.time()
  for i in range(0,len(missing),48):
   batch=missing[i:i+48];encoded=model.encode(batch,batch_size=24,normalize_embeddings=True,show_progress_bar=False)
   for s,v in zip(batch,encoded):vectors[s]=v;db.execute('INSERT OR REPLACE INTO vectors VALUES (?,?)',(key(s),v.astype(np.float32).tobytes()))
   db.commit()
   if i%480==0:print('semantic',min(i+48,len(missing)),'/',len(missing),'elapsed',round(time.time()-start),flush=True)
  for r in pairs:r['semanticSimilarity']=round(float(np.dot(vectors[r['english']],vectors[r['spanish']])),4)if r['english']and r['spanish']else 0
  db.close()
 issues=Counter()
 for r in pairs:
  en,es=r['english'],r['spanish'];flags=[]
  years={v[:4]for v in re.findall(r'\b(?:18|19|20)\d{2}(?:s)?\b',en)};targetyears={v[:4]for v in re.findall(r'\b(?:18|19|20)\d{2}(?:s)?\b',es)}
  if years!=targetyears:flags.append('year-transfer')
  percentages=lambda s:{float(v.replace(',','.'))for v in re.findall(r'\b(\d+(?:[.,]\d+)?)\s*%',s)}
  if percentages(en)!=percentages(es):flags.append('percentage-transfer')
  if re.search(r"\b(?:not|never|no longer|doesn't|isn't|aren't|wasn't|weren't|cannot|can't)\b",en,re.I)and not re.search(r'\b(?:no|ni|nunca|tampoco|sin|deja|dejan|dej[oó]|distint[ao]s?|ajeno|diferente)\b',es,re.I):flags.append('negation-review')
  if r.get('semanticSimilarity',1)<(.60 if len(words(en))<9 else .68):flags.append('meaning-review')
  ratio=len(words(es))/max(1,len(words(en)));r['wordRatio']=round(ratio,3)
  if len(words(en))>=12 and(ratio<.7 or ratio>1.8):flags.append('length-review')
  if not es.strip():flags.append('missing')
  if en.strip()==es.strip()and len(words(en))>6:flags.append('untranslated')
  patterns={'literal-register':r'\b(?:se ejecuta|se ejecutan|de larga data|un tema definitorio|hospitalidad|captación geográfica|propiedades de apartamentos|una lista de verificación|tierra de vivienda|maquinaria social)\b','encoding':r'<unk>|�','english-sentence':r'\b(?:the city|in the city|housing pressure|public transport|working class|school system)\b'}
  for name,pattern in patterns.items():
   if re.search(pattern,es,re.I):flags.append(name)
  r['flags']=flags;issues.update(flags)
 out=ROOT/'work/spanish-review';out.mkdir(exist_ok=True)
 for country in states:
  rows=[r for r in pairs if r['country']==country];summary={'country':country,**states[country],'fields':len(rows),'flagged':sum(bool(r['flags'])for r in rows),'issues':dict(Counter(f for r in rows for f in r['flags'])),'minimumSimilarity':min((r.get('semanticSimilarity',1)for r in rows),default=None),'pairs':rows}
  (out/(country+'.json')).write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
  (out/(country+'-flags.json')).write_text(json.dumps([r for r in rows if r['flags']],ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'fields':len(pairs),'countries':len(states),'issues':dict(issues),'reviewDirectory':str(out)},ensure_ascii=False),flush=True)
if __name__=='__main__':main()
