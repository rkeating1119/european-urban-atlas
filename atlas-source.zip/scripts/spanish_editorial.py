"""Shared conservative repairs for saved Spanish drafts; not a substitute for review."""
import difflib,re,unicodedata

REVISION=3

def repair_names(source,target):
    # OPUS's Spanish vocabulary lacks some foreign letters. Restore a name only
    # when the corresponding damaged spelling actually occurs in the target.
    words=re.findall(r"[\wÀ-ž]+(?:[-’'][\wÀ-ž]+)*",source)
    for word in sorted({re.sub(r"[’']s$",'',w)for w in words},key=len,reverse=True):
        if len(word)<4:continue
        special=any(ord(c)>127 and c not in "áéíóúüñÁÉÍÓÚÜÑ’"for c in word)or(word[0].isupper()and any(ord(c)>127 and c!='’'for c in word))
        institutional=bool(re.search(r'beratung|hochschule|gymnasium|universit[äè]|folkhögskola',word,re.I))
        if not(special or institutional):continue
        shadows={''.join(c for c in word if ord(c)<128),
                 ''.join(c for c in unicodedata.normalize('NFKD',word)if not unicodedata.combining(c))}
        for shadow in sorted(shadows,key=len,reverse=True):
            if len(shadow)>=3 and shadow!=word:
                target=re.sub(r'(?<!\w)'+re.escape(shadow)+r'(?!\w)',lambda _:word,target,flags=re.I)
        if institutional:
            for candidate in set(re.findall(r'\b[A-ZÀ-Ž][\wÀ-ž-]{8,}\b',target)):
                if candidate[:3].casefold()==word[:3].casefold()and difflib.SequenceMatcher(None,candidate.casefold(),word.casefold()).ratio()>.91:
                    target=re.sub(r'(?<!\w)'+re.escape(candidate)+r'(?!\w)',lambda _:word,target)
    return target

def polish(source,target):
    target=repair_names(source,target)
    fixes={
      'vecindarios':'barrios','vecindario':'barrio',
      'distritos de apartamentos':'barrios de bloques de viviendas',
      'distritos de vivienda':'barrios residenciales',
      'el patrón de la calle':'el trazado urbano',
      'el patrón de las calles':'el trazado de las calles',
      'antiguo centro':'centro histórico',
      'Citt Alta':'Città Alta','Citt Bassa':'Città Bassa',
      'sustanciales murallas':'imponentes murallas',
      'las escuelas estatales':'los centros públicos',
      'escuelas estatales':'centros públicos',
      'LGBTQ +':'LGBTQ+','LGBTQI +':'LGBTQI+',
      'anti-queer':'contra las personas queer',
      'tema público definitorio':'uno de los grandes asuntos de la vida pública',
      'un tema definitorio':'un asunto central',
      'de larga data':'de larga trayectoria',
      'viajes al trabajo':'desplazamientos al trabajo',
      'la geografía de captación':'las zonas de escolarización',
      'Geografía de captación':'Zonas de escolarización',
      'rutas vocacionales':'itinerarios de formación profesional',
      'caminos educativos':'itinerarios educativos',
      'collge':'collège',
      'til transporte público':'Buen transporte público',
      'Transporte útil público':'Buen transporte público',
    }
    for a,b in fixes.items():target=target.replace(a,b)
    if 'social housing' in source.lower():
        target=target.replace('viviendas de protección pública','viviendas sociales').replace('vivienda de protección pública','vivienda social')
    elif 'public housing' in source.lower():
        target=target.replace('viviendas de protección pública','viviendas públicas').replace('vivienda de protección pública','vivienda pública')
    if re.search(r'\b(?:housing|apartment|residential|postwar|council|outer) estates?\b',source,re.I):
        target=re.sub(r'\bfincas\b','barrios residenciales',target)
        target=target.replace('propiedades de apartamentos','conjuntos de bloques de viviendas').replace('propiedades residenciales','barrios residenciales')
    if re.search(r'\bbasin\b',source,re.I):target=re.sub(r'\bpalangana\b','cuenca',target,flags=re.I)
    if re.search(r'\blie[sd]?\b',source,re.I):
        target=re.sub(r'\bmienten\b','se encuentran',target,flags=re.I)
        target=re.sub(r'\bmiente\b','se encuentra',target,flags=re.I)
    target=re.sub(r'\btil\b','útil',target)
    target=re.sub(r'\btiles\b','útiles',target)
    if re.search(r'hospitality',source,re.I):
        target=re.sub(r'\bhospitalidad\b','hostelería',target,flags=re.I)
    if re.search(r'new(?:er)? market rents',source,re.I):
        target=target.replace('nuevas rentas del mercado','los alquileres de los nuevos contratos').replace('las nuevas rentas del mercado','los alquileres de los nuevos contratos')
    if 'grammar school'in source.lower():
        target=re.sub(r'escuelas? de gramática','centros selectivos (grammar schools)',target,flags=re.I)
    if 'concertad'in source.lower():
        target=target.replace('escuelas privadas financiadas por el estado conocidas como concertados','centros concertados de titularidad privada y financiación pública')
    if 'runs through'in source.lower()or'run through'in source.lower():
        target=target.replace('se ejecuta a través de','se desarrolla en').replace('se ejecutan a través de','se desarrollan en')
    if 'drift between'in source.lower():
        target=target.replace('la deriva entre','va pasando por').replace('deriva entre','pasa de un lugar a otro entre')
    target=re.sub(r'\s+([,.;:])',r'\1',target)
    return target.strip()
