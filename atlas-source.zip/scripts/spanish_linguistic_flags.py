#!/usr/bin/env python3
"""Find plausible literal translations that multilingual embeddings may miss."""
from pathlib import Path
import json,re
from audit_reader_edition import prose_pairs
ROOT=Path(__file__).resolve().parents[1];out={}
checks=[('waterfront: lake',r'\blakefront\b',r'\b(?:frente al mar|mar[ií]timo)\b'),('waterfront: river',r'\briverfront\b',r'\bmar[ií]timo\b'),('urban fabric',r'\burban fabric\b',r'\btela\b'),('campus quarter',r'\bcampus quarter\b',r'\btrimestre\b'),('terrain slopes',r'\bslopes?\b',r'\bpistas?\b'),('overseas',r'\boverseas\b',r'\bextranjer[oa]s?\b'),('Réunionese',r'Réunionese',r'\buruguay[oa]s?\b'),('rendered facades',r'\brendered\b',r'\brenderizad[oa]s?\b'),('election seats',r'\bseats?\b',r'\basientos?\b'),('queer as strange',r'\bqueer\b',r'\b(?:extrañ[oa]s?|rar[oa]s?)\b'),('Swords',r'\bSwords\b',r'\bespadas\b'),('Hull',r'\bHull\b',r'\bcasco\b'),('Cork',r'\bCork\b',r'\bcorcho\b'),('Reading',r'\bReading\b',r'\blectura\b'),('Bath',r'\bBath\b',r'\bbañ[oa]s?\b'),('Tours',r'\bTours\b',r'\bexcursiones?\b'),('Moss',r'\bMoss\b',r'\bmusgo\b'),('Nice',r'\bNice\b',r'\bagradable\b'),('river Main',r'\bMain\b',r'\bprincipal\b'),('basin',r'\bbasin\b',r'\bpalangana\b'),('geographic lie',r'\blie[sd]?\b',r'\bmient[ea]n?\b'),('housing estate',r'\b(?:housing|apartment|residential|postwar|council|outer) estates?\b',r'\bfincas?\b'),('further education',r'\bfurther education\b',r'\beducaci[oó]n superior\b'),('French collège',r'\bcollège\b',r'\buniversidad\b'),('specialist jobs',r'\bspecialist (?:jobs|employment|careers)\b',r'\bdel especialista\b'),('federal state',r'\bfederal state\b',r'\bestado federal\b')]
for ep in sorted((ROOT/'public/data/editorial').glob('*.json')):
 sp=ep.parent/'es'/ep.name
 if not sp.exists():continue
 en=json.loads(ep.read_text());es=json.loads(sp.read_text());rows=[]
 for loc,source,target in prose_pairs(en,es):
  flags=[name for name,src,dst in checks if re.search(src,source)and re.search(dst,target,re.I)]
  if re.search(r'\b(?:housing|apartment|residential|postwar|council|outer) estates?\b',source,re.I)and re.search(r'\bpropiedades\b',target,re.I):flags.append('housing estate as properties')
  if flags:rows.append({'location':loc,'flags':flags,'english':source,'spanish':target})
 out[ep.stem]=rows
folder=ROOT/'work/spanish-linguistic-flags';folder.mkdir(exist_ok=True)
for name,rows in out.items():(folder/(name+'.json')).write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:len(v)for k,v in out.items()},ensure_ascii=False))
