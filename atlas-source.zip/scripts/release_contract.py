"""Content identity shared by the renderer, audit and release exporter."""
from pathlib import Path
import hashlib,json

def source_release(root:Path)->str:
    data=root/'public/data'
    files=[root/p for p in ['scripts/build.py','scripts/bundle.mjs','scripts/release_contract.py','scripts/ui_copy.py','scripts/feature_directory.py','public/data/atlas-catalog.json','public/data/images.json','src/app.ts','src/map-hit.ts','src/map-labels.ts','public/assets/style.css']]
    files+=list((root/'scripts').glob('feature_*.py'))+list((root/'src').glob('*.ts'))+list((data/'features').rglob('*'))+list((root/'public/assets/audio').rglob('*'))+list((data/'geography').glob('*.json'))
    files=[p for p in set(files)if p.is_file()]
    files+=list((data/'editorial').rglob('*.json'))+list((data/'maps').glob('*.geojson'))
    config=json.loads((root/'.openai/github-pages.json').read_text())
    digest=hashlib.sha256(json.dumps({k:config.get(k)for k in ['base_path','expected_url']},sort_keys=True).encode())
    for p in sorted(files):
        digest.update(p.relative_to(root).as_posix().encode()+b'\0'+p.read_bytes()+b'\0')
    return digest.hexdigest()[:12]
