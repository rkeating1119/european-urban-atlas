import { build } from "esbuild";
import assert from "node:assert/strict";

const bundle = await build({
  entryPoints: ["src/map-labels.ts"],
  bundle: true,
  write: false,
  format: "esm",
  platform: "node",
});
const { placeCityLabels, placeRegionLabels } = await import(
  "data:text/javascript;base64," +
    Buffer.from(bundle.outputFiles[0].text).toString("base64")
);

let cityChecks = 0;
let regionChecks = 0;
const widths = [340, 768, 1200];

function cityBox(label) {
  return {
    x: label.x + label.dx,
    y: label.y + label.dy - label.height / 2,
    width: label.width,
    height: label.height,
  };
}

// Region markers keep MapLibre's default center anchor, unlike city markers.
function regionBox(label) {
  return {
    x: label.x + label.dx - label.width / 2,
    y: label.y + label.dy - label.height / 2,
    width: label.width,
    height: label.height,
  };
}

function intersects(a, b) {
  return (
    a.x < b.x + b.width &&
    a.x + a.width > b.x &&
    a.y < b.y + b.height &&
    a.y + a.height > b.y
  );
}

function assertBounds(box, width, height, context) {
  assert(
    box.x >= 0 &&
      box.x + box.width <= width &&
      box.y >= 0 &&
      box.y + box.height <= height,
    context,
  );
}

for (const width of widths) {
  const height = 588;
  const original = Array.from({ length: 10 }, (_, i) => ({
    key: String(i),
    x: width / 2 + ((i % 3) - 1) * 9,
    y: height / 2 + Math.floor(i / 3) * 6,
    width: 55 + (i % 3) * 12,
    height: 28,
  }));
  const dots = original.map((p) => ({
    x: p.x - 4,
    y: p.y - 4,
    width: 8,
    height: 8,
  }));
  const placed = placeCityLabels(original, width, height, [], dots);
  assert.equal(placed.length, 10);
  for (const p of placed) {
    assert.equal(
      p.x,
      original[Number(p.key)].x,
      "Text must not change city geography",
    );
    assert.equal(p.y, original[Number(p.key)].y);
    assert(
      Math.abs(p.dy) <= 2 * (p.height + 5),
      "Cluster labels must stay close to their city's latitude",
    );
    const box = cityBox(p);
    assertBounds(box, width, height, "City labels must fit the map");
    for (const q of placed) {
      if (p.key >= q.key) continue;
      assert(
        !intersects(box, cityBox(q)),
        "Clustered city names must not overlap",
      );
      cityChecks++;
    }
  }
}

function checkRegions(name, original, dots, width, height, maxDistance = 72) {
  // Frozen inputs catch changes to geographic anchors or visible dot positions.
  const labels = Object.freeze(original.map((p) => Object.freeze({ ...p })));
  const obstacles = Object.freeze(dots.map((p) => Object.freeze({ ...p })));
  const before = JSON.stringify({ labels, obstacles });
  const placed = placeRegionLabels(labels, width, height, obstacles);
  assert.equal(
    placed.length,
    labels.length,
    `${name}: all names must be retained`,
  );
  assert.deepEqual(
    placed.map((p) => p.key),
    labels.map((p) => p.key),
  );
  assert.deepEqual(
    placeRegionLabels(labels, width, height, obstacles),
    placed,
    `${name}: identical views must give stable placement`,
  );
  assert.equal(
    JSON.stringify({ labels, obstacles }),
    before,
    `${name}: inputs must stay unchanged`,
  );
  for (let i = 0; i < placed.length; i++) {
    const p = placed[i];
    assert.equal(
      p.x,
      labels[i].x,
      `${name}: longitude projection must stay unchanged`,
    );
    assert.equal(
      p.y,
      labels[i].y,
      `${name}: latitude projection must stay unchanged`,
    );
    assert(
      Math.hypot(p.dx, p.dy) <= maxDistance + 0.001,
      `${name}: offsets must remain modest (${p.key})`,
    );
    const box = regionBox(p);
    assertBounds(box, width, height, `${name}: centered text must fit the map`);
    for (let j = i + 1; j < placed.length; j++) {
      assert(
        !intersects(box, regionBox(placed[j])),
        `${name}: region labels ${p.key} and ${placed[j].key} must not overlap`,
      );
      regionChecks++;
    }
    for (const dot of dots) {
      assert(!intersects(box, dot), `${name}: text must not cover a city dot`);
      regionChecks++;
    }
  }
  return placed;
}

for (const width of widths) {
  const height = 588;
  const x = width / 2;
  // Reproduces the observed Sweden overlap: long neighboring region names and
  // Stockholm's dot occupy almost the same small area at a countrywide zoom.
  checkRegions(
    `Sweden at ${width}px`,
    [
      { key: "stockholm", x: x + 18, y: 270, width: 126, height: 22 },
      { key: "east-central", x: x - 16, y: 275, width: 151, height: 22 },
    ],
    [
      { x: x + 13, y: 266, width: 12, height: 12 },
      { x: x - 10, y: 288, width: 10, height: 10 },
    ],
    width,
    height,
  );

  checkRegions(
    `Four clustered regions at ${width}px`,
    Array.from({ length: 4 }, (_, i) => ({
      key: `region-${i}`,
      x: x + (i % 2) * 4,
      y: 284 + i * 2,
      width: 118 + i * 4,
      height: 22,
    })),
    [{ x: x - 7, y: 279, width: 14, height: 14 }],
    width,
    height,
  );

  checkRegions(
    `Top-right edge at ${width}px`,
    [
      { key: "edge-a", x: width - 20, y: 15, width: 110, height: 22 },
      { key: "edge-b", x: width - 35, y: 20, width: 105, height: 22 },
    ],
    [{ x: width - 24, y: 11, width: 8, height: 8 }],
    width,
    height,
  );

  checkRegions(
    `Bottom-left edge at ${width}px`,
    [
      { key: "edge-c", x: 25, y: height - 16, width: 100, height: 22 },
      { key: "edge-d", x: 32, y: height - 20, width: 100, height: 22 },
    ],
    [{ x: 21, y: height - 20, width: 8, height: 8 }],
    width,
    height,
  );
}

const separated = checkRegions(
  "Uncrowded regions",
  [
    { key: "a", x: 110, y: 100, width: 100, height: 22 },
    { key: "b", x: 265, y: 240, width: 110, height: 22 },
  ],
  [],
  400,
  400,
);
assert(
  separated.every((p) => p.dx === 0 && p.dy === 0),
  "Uncrowded region text must remain at its original anchor",
);

const wideEdge = checkRegions(
  "Wide name exactly on an edge",
  [{ key: "wide", x: 0, y: 140, width: 180, height: 22 }],
  [],
  340,
  400,
  95,
);
assert.equal(wideEdge[0].dx, 95, "Only the minimum edge correction is needed");
assert.equal(wideEdge[0].dy, 0);
assert.deepEqual(placeRegionLabels([], 340, 588), []);
assert.deepEqual(placeRegionLabels([], 0, 0), []);

// Phone controls can span almost the full map width near a southern region.
// Both the region name and city name must stay visible above or beside them.
const controls = [
  { x: 12, y: 500, width: 316, height: 44 },
  { x: 70, y: 568, width: 270, height: 20 },
];
const nearControls = placeRegionLabels(
  [
    { key: "south", x: 130, y: 558, width: 110, height: 26 },
    { key: "neighbor", x: 135, y: 485, width: 120, height: 26 },
  ],
  340,
  588,
  [],
  controls,
);
for (const label of nearControls) {
  assert(Math.hypot(label.dx, label.dy) <= 96);
  for (const control of controls)
    assert(
      !intersects(regionBox(label), control),
      "Region names must avoid controls",
    );
}
assert(!intersects(regionBox(nearControls[0]), regionBox(nearControls[1])));
const cityNearControls = placeCityLabels(
  [{ key: "city", x: 70, y: 520, width: 75, height: 30 }],
  340,
  588,
  nearControls.map(regionBox),
  controls,
);
for (const control of controls)
  assert(
    !intersects(cityBox(cityNearControls[0]), control),
    "City names must avoid controls",
  );

console.log(
  `PASS: ${cityChecks} city separation and ${regionChecks} region/dot separation checks at phone, tablet and desktop widths; anchors preserved, offsets bounded and placement stable`,
);
