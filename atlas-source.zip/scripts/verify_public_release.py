#!/usr/bin/env python3
"""Verify a deployed release against the exact local static artifact."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import argparse,json,subprocess,hashlib,zipfile
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--archive',type=Path);args=p.parse_args()
config=json.loads((ROOT/'.openai/github-pages.json').read_text());site=config['expected_site_url'].rstrip('/');local=ROOT/'dist/client';archive=zipfile.ZipFile(args.archive)if args.archive else None;getlocal=lambda path:archive.read(path)if archive else(local/path).read_bytes();release=json.loads(getlocal('data/release.json'))['release'];catalog=json.loads((ROOT/'public/data/atlas-catalog.json').read_text());paths=['data/release.json','', 'es/','explore/','es/explore/','data/directory.json','assets/app.js','data/features/maps/manifest.json']
for c in catalog['countries']:
 doc=json.loads((ROOT/f'public/data/editorial/{c["slug"]}.json').read_text());city=doc['cities'][0]['id'];region=doc['regions'][0]['id']
 paths.extend([f'{c["slug"]}/',f'es/{c["slug"]}/cities/{city}/',f'{c["slug"]}/regions/{region}/',f'data/features/maps/{c["id"]}/rivers.geojson'])
def verify(path):
 url=site+'/'+path+'?v='+release
 r=subprocess.run(['curl','-fLsS','--max-time','30',url],capture_output=True)
 expected=path+'index.html'if path==''or path.endswith('/')else path
 try:good=r.returncode==0 and hashlib.sha256(r.stdout).digest()==hashlib.sha256(getlocal(expected)).digest()
 except(KeyError,FileNotFoundError):good=False
 return {'path':path or'/','matchesLocalArtifact':good,'bytes':len(r.stdout),'error':r.stderr.decode()[:160]if r.returncode else''}
with ThreadPoolExecutor(max_workers=6)as pool:results=list(pool.map(verify,paths))
report={'site':site+'/','release':release,'samples':results,'checked':len(results),'errors':sum(not r['matchesLocalArtifact']for r in results)}
args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='samples'}));raise SystemExit(bool(report['errors']))
