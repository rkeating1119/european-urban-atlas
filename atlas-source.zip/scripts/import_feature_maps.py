#!/usr/bin/env python3
"""Reproducible, country-clipped map overlays. Run with ../geodata-env/bin/python.

No invented observations: Natural Earth is pinned, density uses saved INE/GISCO
data, and the optional NASA imagery exposes only the two advertised epochs.
Use --download to acquire inputs; --nightlights adds masked NASA mosaics.
"""
import argparse
import concurrent.futures
import hashlib
import io
import json
import math
from pathlib import Path
import time
import urllib.request

from shapely.geometry import shape, mapping, box
from shapely.ops import unary_union, transform
from shapely.validation import make_valid
from pyproj import Transformer

ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / 'work/feature-expansion/map-inputs'
OUT = ROOT / 'public/data/features/maps'
COMMIT = 'ca96624a56bd078437bca8184e78163e5039ad19'
NAMES = {
    'rivers': 'rivers_lake_centerlines', 'lakes': 'lakes',
    'rail': 'railroads', 'roads': 'roads', 'urban': 'urban_areas',
    'elevation': 'geography_regions_elevation_points',
}
LABELS = {
    'rivers': ['Rivers', 'Ríos'], 'lakes': ['Lakes', 'Lagos'],
    'rail': ['Railways', 'Ferrocarriles'], 'roads': ['Major roads', 'Carreteras principales'],
    'urban': ['Urban footprint', 'Huella urbana'],
    'elevation': ['Named elevation points', 'Puntos de elevación'],
}
COLORS = {'rivers':'#087bab','lakes':'#218fba','rail':'#914997','roads':'#c76820','urban':'#bb4670','elevation':'#736147'}
COUNTRIES = {'spain':'ES','france':'FR','italy':'IT','united-kingdom':'GB','ireland':'IE','germany':'DE','switzerland':'CH','greece':'GR','norway':'NO','sweden':'SE'}


def write(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, separators=(',', ':')) + '\n')


def fetch(url, dest):
    if dest.exists():
        return
    dest.parent.mkdir(parents=True, exist_ok=True)
    for attempt in range(3):
        try:
            req = urllib.request.Request(url, headers={'User-Agent':'EuropeanUrbanAtlas/1.0 (public educational atlas)'})
            with urllib.request.urlopen(req, timeout=90) as response:
                data = response.read()
            dest.write_bytes(data)
            return
        except Exception:
            if attempt == 2:
                raise
            time.sleep(2)


def rounded(v):
    if isinstance(v, float):
        return round(v, 5)
    if isinstance(v, (tuple, list)):
        return [rounded(a) for a in v]
    if isinstance(v, dict):
        return {k:rounded(a) for k,a in v.items()}
    return v


def selected_properties(properties):
    p = {k.lower():v for k,v in properties.items()}
    result = {k:p[k] for k in ('name','name_en','name_es','featurecla','type','elevation','elev','scalerank','status','note','rank_max','sov_a3') if p.get(k) is not None}
    if p.get('namealt'):
        result['alternateName'] = p['namealt']
    return result


def build_vectors(download=False):
    masks = {}
    for slug, cc in COUNTRIES.items():
        data = json.loads((ROOT / f'public/data/maps/{slug}-regions.geojson').read_text())
        masks[cc] = make_valid(unary_union([make_valid(shape(f['geometry'])) for f in data['features']]))
    layers = []
    hashes = {}
    for kind, filename in NAMES.items():
        src = INPUT / (kind + '.geojson')
        url = f'https://raw.githubusercontent.com/nvkelso/natural-earth-vector/{COMMIT}/geojson/ne_10m_{filename}.geojson'
        if download:
            fetch(url, src)
        if not src.exists():
            raise FileNotFoundError(f'{src}; run --download or provide the pinned input')
        hashes[kind] = hashlib.sha256(src.read_bytes()).hexdigest()
        features = json.loads(src.read_text())['features']
        geometries = [(f, make_valid(shape(f['geometry']))) for f in features if f.get('geometry')]
        counts = {}
        for cc, mask in masks.items():
            clipped = []
            for f,g in geometries:
                if not g.intersects(mask):
                    continue
                intersection = g.intersection(mask)
                if intersection.is_empty:
                    continue
                # GeometryCollections can occur where a line touches a coast.
                parts = list(intersection.geoms) if intersection.geom_type == 'GeometryCollection' else [intersection]
                for part in parts:
                    if part.is_empty or (kind in ('rivers','rail','roads') and part.geom_type not in ('LineString','MultiLineString')):
                        continue
                    if kind in ('lakes','urban') and part.geom_type not in ('Polygon','MultiPolygon'):
                        continue
                    props = selected_properties(f.get('properties', {}))
                    props.update(countryId=cc, dataset=kind, snapshot='2022-06-02')
                    geometry = rounded(mapping(part))
                    # Tiny border-clipped line fragments can collapse under rounding.
                    # Preserve their actual coordinates instead of emitting invalid lines.
                    if not shape(geometry).is_valid:
                        geometry = mapping(part)
                    clipped.append({'type':'Feature','properties':props,'geometry':geometry})
            counts[cc] = len(clipped)
            write(OUT / f'{cc}/{kind}.geojson', {'type':'FeatureCollection','features':clipped})
        en, es = LABELS[kind]
        layers.append({'id':kind,'label':{'en':en,'es':es},'type':'circle' if kind=='elevation' else 'fill' if kind in ('lakes','urban') else 'line','color':COLORS[kind], 'countries':counts, 'source':'Natural Earth 1:10m', 'date':'2022-06-02', 'url':url, 'rights':'Public domain', 'legend':{'en':'Generalized 1:10 million geography; snapshot is the saved source revision, not a common observation year.','es':'Geografía generalizada a escala 1:10 millones; la fecha es la revisión guardada, no un año común de observación.'}})

    populations = {p['id']:p for p in json.loads((ROOT / 'public/data/geography/provinces.json').read_text())}
    provinces = json.loads((ROOT / 'public/data/geography/provinces.geojson').read_text())
    project = Transformer.from_crs(4326,3035,always_xy=True).transform
    for f in provinces['features']:
        p = populations[f['properties']['id']]
        g = make_valid(shape(f['geometry']))
        area = transform(project,g).area / 1e6
        f['properties'].update(population=p['population'],populationYear=2025,boundaryYear=2024,areaKm2=round(area,2),density=round(p['population']/area,2))
        f['geometry'] = rounded(mapping(g))
    write(OUT/'ES/density.geojson',provinces)
    layers.append({'id':'density','label':{'en':'Population density · Spain','es':'Densidad de población · España'},'type':'fill','color':'#85529b','countries':{'ES':52},'source':'INE Padrón 2025 / GISCO 2024','date':'2025-01-01 / boundaries 2024','url':'https://www.ine.es/jaxiT3/Tabla.htm?t=29005','rights':'Existing INE/GISCO attribution and reuse conditions apply','legend':{'en':'People/km² · 0–25 · 25–75 · 75–150 · 150–300 · 300–750 · ≥750. Province averages; not settlement density. Area calculated in EPSG:3035. Spain only.','es':'Habitantes/km² · 0–25 · 25–75 · 75–150 · 150–300 · 300–750 · ≥750. Medias provinciales; no densidad de núcleos. Área calculada en EPSG:3035. Solo España.'}})
    manifest = {'version':1,'sourceRevision':COMMIT,'snapshot':'2022-06-02','generated':'2026-11-11','countrySlugs':COUNTRIES,'layers':layers,'inputSHA256':hashes,'nightlights':{},'basemaps':{'atlas':{'source':'OpenFreeMap Liberty / OpenStreetMap + saved GISCO boundaries','coverage':'Global live cartographic context; national overview palette retained to zoom 6, fading through zoom 9','url':'https://openfreemap.org/quick_start/','cost':'Free public instance; no accounts or API keys','rights':'OpenFreeMap styles MIT; OpenMapTiles attribution; OpenStreetMap ODbL; existing GISCO boundary terms retained','date':'Live tiles, not a common dated snapshot'},'dark':{'source':'OpenFreeMap Dark / OpenStreetMap','url':'https://openfreemap.org/quick_start/','date':'Live tiles, not a common dated snapshot','coverage':'Global, variable mapped detail'},'topographic':{'source':'NASA GIBS MODIS BlueMarble_ShadedRelief + OpenFreeMap streets','url':'https://science.nasa.gov/earth/earth-observatory/blue-marble-next-generation/','date':'MODIS 2004 composite; live street data','coverage':'Global coarse shaded relief; native raster maximum zoom 8; no surveyed contours or 3D elevation'},'satellite':{'source':'NASA GIBS MODIS BlueMarble_NextGeneration','url':'https://science.nasa.gov/earth/earth-observatory/blue-marble-next-generation/','date':'MODIS 2004 composite','coverage':'Global coarse imagery; native raster maximum zoom 8; no close aerial detail'},'nasaRights':{'url':'https://www.nasa.gov/nasa-brand-center/images-and-media/','attribution':'NASA Earth Observatory; no NASA endorsement implied'}},'limitations':{'en':'Natural Earth overlays are generalized and incomplete for local streets, small waterways and small settlements. Live OpenStreetMap detail is independent. No ecosystem, climate, pollution, linguistic or political-history layer is asserted by this release.','es':'Las capas de Natural Earth son generalizadas y no incluyen todas las calles, aguas ni poblaciones pequeñas. El detalle de OpenStreetMap es independiente. Esta versión no presenta capas de ecosistemas, clima, contaminación, áreas lingüísticas ni historia política.'}}
    existing = OUT/'manifest.json'
    if existing.exists():
        manifest['nightlights'] = json.loads(existing.read_text()).get('nightlights',{})
    write(existing,manifest)
    write(ROOT/'docs/FEATURE-MAP-DATA.json',manifest)
    return masks,manifest


def build_nightlights(masks,manifest):
    """Mosaic genuine NASA WMTS z5 tiles and apply country alpha masks.

    Output is Mercator-rectified PNG with image-source corner coordinates.
    France is separated into metropolitan and overseas imagery; no global
    thematic raster is displayed. Native z5 (~4.9km/pixel at equator) is
    deliberately coarse and documented; bright pixels are not population.
    """
    import numpy as np
    from PIL import Image
    from rasterio.features import rasterize
    from rasterio.transform import from_bounds
    forward = Transformer.from_crs(4326,3857,always_xy=True).transform
    inverse = Transformer.from_crs(3857,4326,always_xy=True).transform
    z=5
    half=20037508.342789244
    span=half*2/(2**z)
    for cc, country in masks.items():
        # Geographic windows preserve overseas scope without a world-sized mosaic.
        windows = [box(-20,20,40,85)] if cc!='FR' else [box(-10,40,15,55),box(-65,10,-60,20),box(-55,-1,-50,7),box(42,-15,47,-10),box(53,-23,58,-18)]
        images={str(y):[] for y in (2012,2016)}
        for index,window in enumerate(windows):
            part=country.intersection(window)
            if part.is_empty:
                continue
            projected=transform(forward,part)
            xmin,ymin,xmax,ymax=projected.bounds
            x0=max(0,int((xmin+half)//span)); x1=min(31,int((xmax+half)//span))
            y0=max(0,int((half-ymax)//span)); y1=min(31,int((half-ymin)//span))
            bounds=(-half+x0*span,half-(y1+1)*span,-half+(x1+1)*span,half-y0*span)
            width=(x1-x0+1)*256; height=(y1-y0+1)*256
            mask=rasterize([(mapping(projected),255)],out_shape=(height,width),transform=from_bounds(*bounds,width,height),fill=0,dtype='uint8',all_touched=False)
            west,south=inverse(bounds[0],bounds[1]); east,north=inverse(bounds[2],bounds[3])
            for year in (2012,2016):
                mosaic=Image.new('RGBA',(width,height))
                jobs=[]
                for x in range(x0,x1+1):
                    for y in range(y0,y1+1):
                        tilebox=box(-half+x*span,half-(y+1)*span,-half+(x+1)*span,half-y*span)
                        if projected.intersects(tilebox):
                            dest=INPUT/f'gibs/{year}/{z}/{x}/{y}.png'
                            url=f'https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/VIIRS_Black_Marble/default/{year}-01-01/GoogleMapsCompatible_Level8/{z}/{y}/{x}.png'
                            jobs.append((url,dest,x,y))
                def job(args):
                    url,dest,x,y=args
                    fetch(url,dest)
                    return dest,x,y
                with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
                    for dest,x,y in pool.map(job,jobs):
                        with Image.open(dest) as im:
                            mosaic.paste(im.convert('RGBA'),((x-x0)*256,(y-y0)*256))
                original=np.asarray(mosaic)[:,:,3]
                mosaic.putalpha(Image.fromarray(np.minimum(original,mask)))
                file=f'{cc}/night-{year}-{index}.png'
                mosaic.save(OUT/file,optimize=True)
                images[str(year)].append({'url':file,'coordinates':[[west,north],[east,north],[east,south],[west,south]],'width':width,'height':height})
        manifest['nightlights'][cc]=images
        print('Masked NASA imagery:',cc,flush=True)
        write(OUT/'manifest.json',manifest)
    manifest['nightlightMetadata']={'source':'NASA GIBS / VIIRS Black Marble','epochs':[2012,2016],'url':'https://svs.gsfc.nasa.gov/30886/','capabilities':'https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/wmts.cgi?SERVICE=WMTS&REQUEST=GetCapabilities','nativeZoom':5,'resolution':'~4.9 km per pixel at equator (Web Mercator z5); display only, not radiance values','mask':'Alpha clipped to incorporated country regional polygons; mainland and overseas windows; no values outside country masks','rights':'NASA imagery generally freely reusable; NASA attribution retained; no NASA endorsement implied'}
    write(OUT/'manifest.json',manifest)
    write(ROOT/'docs/FEATURE-MAP-DATA.json',manifest)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--download',action='store_true')
    parser.add_argument('--nightlights',action='store_true')
    args=parser.parse_args()
    masks,manifest=build_vectors(args.download)
    if args.nightlights:
        build_nightlights(masks,manifest)
    print(json.dumps({l['id']:l['countries'] for l in manifest['layers']},indent=2))
