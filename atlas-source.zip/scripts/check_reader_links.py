#!/usr/bin/env python3
"""Audit current reader-edition source URLs; blocked/timeouts remain inconclusive."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from collections import Counter
from datetime import datetime,timezone
import json,sys,argparse
from check_links import check
ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser();parser.add_argument('--reuse-current',action='store_true');parser.add_argument('--retry-tls',action='store_true');args=parser.parse_args()
refs={};cache={}
reportfile=ROOT/'docs/READER-SOURCE-LINKS.json'
if args.reuse_current and reportfile.exists():
 previous=json.loads(reportfile.read_text())
 try:current=(datetime.now(timezone.utc)-datetime.fromisoformat(previous['checkedAt'])).total_seconds()<21600
 except(ValueError,KeyError):current=False
 if current:cache={r['url']:r for r in previous['results']if r['result']not in ('broken','invalid-url-syntax')and not(args.retry_tls and 'CERTIFICATE_VERIFY_FAILED'in r.get('detail',''))}
for file in (ROOT/'public/data/editorial').glob('*.json'):
 for city in json.loads(file.read_text())['cities']:
  for source in city['sources']:refs.setdefault(source['url'],[]).append(file.stem+'/'+city['id'])
  if city.get('population'):refs.setdefault(city['population']['sourceUrl'],[]).append(file.stem+'/'+city['id'])
results=[{**cache[url],'cities':cities}for url,cities in refs.items()if url in cache]
with ThreadPoolExecutor(max_workers=12)as pool:
 jobs={pool.submit(check,url,7):url for url in refs if url not in cache}
 for task in as_completed(jobs):
  r=task.result();r['cities']=refs[r['url']];r['checkedAt']=datetime.now(timezone.utc).isoformat();results.append(r)
report={'checkedAt':datetime.now(timezone.utc).isoformat(),'counts':dict(Counter(r['result']for r in results)),'totalURLs':len(refs),'results':sorted(results,key=lambda r:r['url']),'note':'HTTP accessibility is not substantive verification. Blocked and timed-out sources are not treated as confirmed broken.'}
(ROOT/'docs/READER-SOURCE-LINKS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:report[k]for k in ['totalURLs','counts']},indent=2))
