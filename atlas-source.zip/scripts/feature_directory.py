"""Project the preserved geographic inventory into a lightweight shared directory."""
import json
from pathlib import Path

def prepare_directory(root, out, english, spanish, catalog):
    data=root/'public/data';entries=[];seen=set();country_by={c['id']:c for c in catalog['countries']}
    def add(row):
        if row['id'] in seen:raise ValueError('Duplicate directory ID '+row['id'])
        assert -90<=row['lat']<=90 and -180<=row['lon']<=180
        seen.add(row['id']);entries.append(row)
    profiled={str(c.get('municipalityId')):c for c in english['ES']['cities']if c.get('municipalityId')}
    provinces={p['id']:p for p in json.loads((data/'geography/provinces.json').read_text())}
    for cid, doc in english.items():
        local=spanish[cid];sm={c['id']:c for c in local['cities']};regions={r['id']:r for r in doc['regions']};spec=country_by[cid]
        for c in doc['cities']:
            if cid=='ES':continue
            add({'id':f'{cid}:city:{c["id"]}','countryId':cid,'kind':'city','name':c['name'],'nameEs':sm[c['id']]['name'],'aliases':c.get('aliases',[]),'regionId':c['regionId'],'lat':c['lat'],'lon':c['lon'],'profile':f'/{spec["slug"]}/cities/{c["id"]}/','population':c.get('population')})
        geo=json.loads((data/'maps'/f'{spec["slug"]}-regions.geojson').read_text())
        points={str(f['properties']['id']):f['properties'].get('labelPoint')for f in geo['features']}
        for r in doc['regions']:
            point=points.get(r['id'])
            if not point:
                c=next(c for c in doc['cities']if c['regionId']==r['id']);point=[c['lon'],c['lat']]
            add({'id':f'{cid}:region:{r["id"]}','countryId':cid,'kind':'region','name':r['name'],'nameEs':spec['regionNamesEs'].get(r['id'],r['name']),'regionId':r['id'],'lat':point[1],'lon':point[0],'profile':f'/{spec["slug"]}/regions/{r["id"]}/'})
    for m in json.loads((data/'geography/municipalities.json').read_text()):
        c=profiled.get(m['id']);population={'value':m['population'],'year':m['populationYear'],'unit':'municipality'}
        add({'id':'ES:municipality:'+m['id'],'countryId':'ES','kind':'municipality','name':m['name'],'aliases':m.get('aliases',[]),'regionId':m['regionId'],'provinceId':m['provinceId'],'lat':m['lat'],'lon':m['lon'],'profile':f'/spain/cities/{c["id"]}/'if c else None,'population':population,'referenceYear':2026,'geometryYear':2024})
    for p in provinces.values():
        if p['type']!='province':continue
        add({'id':'ES:province:'+p['id'],'countryId':'ES','kind':'province','name':p['name'],'regionId':p['regionId'],'provinceId':p['id'],'lat':p['lat'],'lon':p['lon'],'population':{'value':p['population'],'year':p['populationYear'],'unit':'province'}})
    municipalities={m['id']:m for m in json.loads((data/'geography/municipalities.json').read_text())}
    for f in json.loads((data/'geography/functional-urban-areas.json').read_text()):
        members=[municipalities[mid] for mid in f['municipalityIds'] if mid in municipalities]
        if not members:continue
        anchor=max(members,key=lambda m:m['population'])
        add({'id':'ES:functional-urban-area:'+f['id'],'countryId':'ES','kind':'functional-urban-area','name':f['name'],'regionId':anchor['regionId'],'lat':anchor['lat'],'lon':anchor['lon'],'referenceYear':2024,'memberCount':len(members),'note':{'en':'Functional urban area, 2024. The map point and region filter use its largest indexed municipality. Municipal membership is a computed point-in-polygon relationship, not an official correspondence table.','es':'Área urbana funcional de 2024. El punto del mapa y el filtro regional usan su municipio más poblado del directorio. La relación municipal se calculó por puntos dentro del polígono; no es una tabla oficial de correspondencias.'}})
    payload={'version':1,'entries':entries,'provinces':[{'id':p['id'],'name':p['name'],'regionId':p['regionId']}for p in provinces.values()],'sources':[{'title':'INE · Municipal names and codes, 2026','url':'https://www.ine.es/daco/daco42/codmun/diccionario26.xlsx'},{'title':'INE · Municipal Padrón, 1 January 2025','url':'https://www.ine.es/jaxiT3/Tabla.htm?t=29005'},{'title':'Eurostat GISCO · Urban Audit 2024','url':'https://gisco-services.ec.europa.eu/distribution/v2/urau/urau-2024-files.html'},{'title':'Eurostat GISCO · LAU 2024','url':'https://gisco-services.ec.europa.eu/distribution/v2/lau/lau-2024-files.html'}]}
    target=out/'data/directory.json';target.write_text(json.dumps(payload,ensure_ascii=False,separators=(',',':')))
    return {'entries':len(entries),'spanishMunicipalities':sum(e['countryId']=='ES'and e['kind']=='municipality'for e in entries),'bytes':target.stat().st_size}

def directory_html(t, countries, lang, map_html, country=None):
    from html import escape as e
    es=lang=='es';tr=lambda en,sp:sp if es else en
    options=''.join(f'<option value="{c["id"]}" {"selected"if c["id"]==country else""}>{e(c["name"])}</option>'for c in countries)
    types=[('','Any indexed place','Cualquier lugar del directorio'),('profile','Cities with articles','Ciudades con artículo'),('municipality','Municipalities','Municipios'),('region','Regions','Regiones'),('province','Provinces','Provincias'),('functional-urban-area','Functional urban areas · Spain','Áreas urbanas funcionales · España')]
    return f'''<div class="container explorer-page"><header class="profile-header"><p class="eyebrow">{tr('GEOGRAPHIC EXPLORER','EXPLORADOR GEOGRÁFICO')}</p><h1>{tr('Somewhere new.','Un lugar distinto.')}</h1><p class="lede">{tr('Find a place, or let chance choose the next one.','Busca un lugar o deja que el azar elija el siguiente.')}</p><p>{tr('Spain includes all 8,132 municipalities; elsewhere, the directory covers the indexed cities and regions.','España incluye sus 8.132 municipios; en los demás países figuran las ciudades y regiones del directorio.')}</p></header><form id="explorer-form" class="explorer-form" data-country="{country or''}"><label>{tr('Country','País')}<select name="country"><option value="">{t['allCountries']}</option>{options}</select></label><label>{tr('Kind of place','Tipo de lugar')}<select name="kind">{''.join(f'<option value="{k}">{tr(en,sp)}</option>'for k,en,sp in types)}</select></label><label>{t['region']}<select name="region"><option value="">{t['allRegions']}</option></select></label><label>{tr('Province · Spain','Provincia · España')}<select name="province"><option value="">{tr('All provinces','Todas las provincias')}</option></select></label><label class="explorer-query">{t['search']}<input type="search" name="q" autocomplete="off" placeholder="{tr('A name or alternate spelling','Un nombre u otra forma de escribirlo')}"></label><button class="button" type="submit">{t['search']}</button><button class="button light" id="explore-random" type="button">{tr('Explore somewhere random','Explorar un lugar al azar')} ↝</button></form><p id="explorer-status" role="status"></p><div class="explorer-layout"><div>{map_html(large=True,explorer=True)}<section id="explorer-preview" aria-live="polite" tabindex="-1"><h2>{tr('Choose a place','Elige un lugar')}</h2><p>{tr('Select a result or try the random button.','Selecciona un resultado o prueba el botón de azar.')}</p></section></div><aside><h2>{tr('Places','Lugares')}</h2><div id="explorer-results"></div><button class="button light" id="explorer-more" type="button" hidden>{tr('Show more','Ver más')}</button></aside></div></div>'''
