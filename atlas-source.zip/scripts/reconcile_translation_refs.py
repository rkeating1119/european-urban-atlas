#!/usr/bin/env python3
"""Explicitly reconcile reference-only fixes after country editors have finished."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json
from translation_contract import save_snapshot,reference_only_update
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--country',required=True);args=p.parse_args()
for slug in args.country.split(','):
    ep=ROOT/'public/data/editorial'/f'{slug}.json';sp=ep.parent/'es'/ep.name
    raw=ep.read_bytes();english=json.loads(raw);spanish=json.loads(sp.read_text());current=hashlib.sha256(raw).hexdigest();previous=spanish['translationSourceHash']
    if current==previous:print(slug,'already current');continue
    oldfile=ROOT/'work/translation-sources'/slug/(previous+'.json')
    if not oldfile.exists():raise ValueError(slug+': previous English snapshot missing; cannot certify a reference-only change')
    revised=reference_only_update(json.loads(oldfile.read_text()),english,spanish)
    revised['translationSourceHash']=current
    revised.setdefault('translationReferenceReconciliations',[]).append({'from':previous,'to':current,'checkedAt':datetime.now(timezone.utc).isoformat(),'method':'Compared complete English records with bibliography/date fields removed; prose, identity and factual values identical. Updated references only; preserved Spanish prose and review.'})
    tmp=sp.with_suffix('.tmp');tmp.write_text(json.dumps(revised,ensure_ascii=False,indent=2)+'\n');tmp.replace(sp);save_snapshot(ROOT,slug,raw);print(slug,'references reconciled; Spanish editing preserved')
