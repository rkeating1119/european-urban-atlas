"""Preserve Spanish editing when only bibliography metadata changes in English."""
from pathlib import Path
import copy,hashlib,json

def save_snapshot(root,slug,raw):
    digest=hashlib.sha256(raw).hexdigest()
    p=Path(root)/'work/translation-sources'/slug/(digest+'.json')
    p.parent.mkdir(parents=True,exist_ok=True)
    if not p.exists():p.write_bytes(raw)
    return digest

def without_references(value):
    if isinstance(value,dict):return {k:without_references(v)for k,v in value.items()if k not in {'sources','sourceIds','sourceUrl','accessed','updated'}}
    if isinstance(value,list):return [without_references(v)for v in value]
    return value

def reference_only_update(old,new,spanish):
    if without_references(old)!=without_references(new):
        raise ValueError('English prose, identity or factual values changed; substantive Spanish reconciliation is required')
    result=copy.deepcopy(spanish);by={c['id']:c for c in result['cities']}
    for city in new['cities']:
        target=by[city['id']];target['sources']=copy.deepcopy(city['sources'])
        if 'updated'in city:target['updated']=city['updated']
        if city.get('population')and target.get('population'):
            target['population']['sourceUrl']=city['population']['sourceUrl']
        sections={s['id']:s for s in target['sections']}
        for s in city['sections']:sections[s['id']]['sourceIds']=copy.deepcopy(s['sourceIds'])
    return result
