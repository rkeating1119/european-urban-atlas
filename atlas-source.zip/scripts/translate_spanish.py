#!/usr/bin/env python3
"""Prepare saved Spanish drafts locally; reviewed countries are never overwritten.

Requires CTranslate2 and Transformers, with the credited OPUS-MT model converted
locally. This is a drafting aid: semantic/style review remains a release gate.
"""
from pathlib import Path
import argparse,copy,hashlib,json,re,time
from spanish_editorial import polish,REVISION
from translation_contract import save_snapshot
ROOT=Path(__file__).resolve().parents[1]
TITLES={'character':'La vida cotidiana','geography':'Geografía y estructura urbana','architecture':'Arquitectura y paisaje urbano','history':'Historia y transformaciones','work':'Economía y trabajo','housing':'Vivienda y desigualdad','neighborhoods':'Barrios y contrastes','culture':'Cultura y ocio','food':'Gastronomía y hábitos cotidianos','transport':'Movilidad y conexiones','climate':'Clima y vida al aire libre','education':'Universidades y escuelas','politics':'Política y vida cívica','lgbtq':'Vida y aceptación LGBT','people':'Población y relaciones sociales'}
COUNTRIES={'Spain':'España','France':'Francia','Italy':'Italia','United Kingdom':'Reino Unido','Ireland':'Irlanda','Germany':'Alemania','Switzerland':'Suiza','Greece':'Grecia','Norway':'Noruega','Sweden':'Suecia'}
NAMES={'London':'Londres','Edinburgh':'Edimburgo','Athens':'Atenas','Thessaloniki':'Salónica','Stockholm':'Estocolmo','Gothenburg':'Gotemburgo','Zurich':'Zúrich','Geneva':'Ginebra','Bern':'Berna','Basel':'Basilea','Lucerne':'Lucerna','St Gallen':'San Galo','Munich':'Múnich','Cologne':'Colonia','Frankfurt':'Fráncfort','Nuremberg':'Núremberg','Hanover':'Hanóver','Mainz':'Maguncia','Aachen':'Aquisgrán','Regensburg':'Ratisbona','Berlin':'Berlín','Hamburg':'Hamburgo','Dresden':'Dresde','Paris':'París','Marseille':'Marsella','Lyon':'Lyon','Nice':'Niza','Bordeaux':'Burdeos','Toulouse':'Toulouse','Nantes':'Nantes','Strasbourg':'Estrasburgo','Montpellier':'Montpellier','Rome':'Roma','Milan':'Milán','Naples':'Nápoles','Turin':'Turín','Florence':'Florencia','Venice':'Venecia','Bologna':'Bolonia','Genoa':'Génova','Bergamo':'Bérgamo','Padua':'Padua','Reggio Calabria':'Regio de Calabria','Catania':'Catania'}
REGIONS={'Scotland':'Escocia','Wales':'Gales','Northern Ireland':'Irlanda del Norte','North East England':'Nordeste de Inglaterra','North West England':'Noroeste de Inglaterra','Yorkshire and the Humber':'Yorkshire y Humber','East Midlands':'Midlands Orientales','West Midlands':'Midlands Occidentales','East of England':'Este de Inglaterra','South East England':'Sudeste de Inglaterra','South West England':'Sudoeste de Inglaterra','Northern and Western':'Norte y Oeste','Southern':'Sur','Eastern and Midland':'Este y Centro','Lake Geneva':'Región del Lemán','Northwestern Switzerland':'Noroeste de Suiza','Eastern Switzerland':'Suiza Oriental','Central Switzerland':'Suiza Central','Ticino':'Tesino','Bavaria':'Baviera','Lower Saxony':'Baja Sajonia','North Rhine-Westphalia':'Renania del Norte-Westfalia','Saxony':'Sajonia','Saxony-Anhalt':'Sajonia-Anhalt','Rhineland-Palatinate':'Renania-Palatinado','Hesse':'Hesse','Mecklenburg-Western Pomerania':'Mecklemburgo-Pomerania Occidental','Thuringia':'Turingia','Saarland':'Sarre'}

def text_fields(country):
 yield country,'summary'
 if isinstance(country.get('ratingScale'),str):yield country,'ratingScale'
 elif isinstance(country.get('ratingScale'),dict)and isinstance(country['ratingScale'].get('description'),str):yield country['ratingScale'],'description'
 for r in country['regions']:yield r,'summary'
 for c in country['cities']:
  if c.get('contentVersion')!=3:continue
  yield c,'summary'
  for arr in ['overview','goodFor','tradeoffs']:
   for i in range(len(c.get(arr,[]))):yield c[arr],i
  for s in c['sections']:
   for i in range(len(s['paragraphs'])):yield s['paragraphs'],i
  for r in c['ratings'].values():yield r,'summary'

def segments(source):
 # Translate every sentence independently: long-paragraph MT can silently omit
 # later sentences even when its token limit is not reached.
 points=[0]
 for match in re.finditer(r'(?<=[.!?])\s+(?=[A-ZÀ-Ž0-9])',source):
  if re.search(r'\b(?:St|Dr|Mr|Ms|Mrs|Prof|Mt|No|e\.g|i\.e|U\.S|U\.K)\.$',source[:match.start()]):continue
  points.append(match.end())
 points.append(len(source))
 return [source[a:b].strip()for a,b in zip(points,points[1:])if source[a:b].strip()]

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--watch',action='store_true');parser.add_argument('--country');parser.add_argument('--priority',default='united-kingdom,ireland,greece');args=parser.parse_args()
 from transformers import AutoTokenizer
 import ctranslate2
 model=ROOT.parent/'models/opus-mt-tc-big-en-es';converted=ROOT.parent/'models/opus-en-es-ct2'
 tokenizer=AutoTokenizer.from_pretrained(str(model),local_files_only=True)
 translator=ctranslate2.Translator(str(converted),device='cpu',compute_type='int8',inter_threads=1,intra_threads=4)
 cachefile=ROOT/'work/spanish-sentences-v1.jsonl';cachefile.parent.mkdir(exist_ok=True);cache={}
 if cachefile.exists():
  for line in cachefile.read_text().splitlines():
   try:r=json.loads(line);cache[r['source']]=r['target']
   except ValueError:pass
 targetdir=ROOT/'public/data/editorial/es';targetdir.mkdir(exist_ok=True)
 while True:
  priority=args.priority.split(',')
  for file in sorted((ROOT/'public/data/editorial').glob('*.json'),key=lambda p:(priority.index(p.stem)if p.stem in priority else 99,p.stem)):
   if args.country and file.stem!=args.country:continue
   try:source_bytes=file.read_bytes();country=json.loads(source_bytes)
   except ValueError:continue
   if not country.get('cities'):continue
   source_hash=hashlib.sha256(source_bytes).hexdigest();targetfile=targetdir/file.name
   save_snapshot(ROOT,file.stem,source_bytes)
   if targetfile.exists():
    try:existing=json.loads(targetfile.read_text())
    except ValueError:existing={}
    if existing.get('translationSourceHash')==source_hash and(existing.get('translationStatus')=='reviewed'or existing.get('translationRevision')==REVISION):continue
    if existing.get('translationStatus')=='reviewed'or existing.get('translationEditing'):
     print(file.stem,'PRESERVED edited Spanish; English changed and needs explicit reconciliation',flush=True);continue
   ready=[c for c in country['cities']if c.get('contentVersion')==3]
   if not ready:continue
   strings=list(dict.fromkeys(obj[key]for obj,key in text_fields(country)if isinstance(obj[key],str)))
   units=list(dict.fromkeys(unit for s in strings for unit in segments(s)))
   missing=[s for s in units if s not in cache]
   start=time.time()
   for offset in range(0,len(missing),96):
    batch=missing[offset:offset+96];tokens=[tokenizer.convert_ids_to_tokens(tokenizer.encode(s))for s in batch]
    if any(len(x)>510 for x in tokens):raise ValueError('Long source needs sentence-aware splitting before translation')
    results=translator.translate_batch(tokens,beam_size=4,max_batch_size=96,max_decoding_length=500)
    with cachefile.open('a')as output:
     for source,result in zip(batch,results):
      translated=tokenizer.decode(tokenizer.convert_tokens_to_ids(result.hypotheses[0]),skip_special_tokens=True);cache[source]=polish(source,translated);output.write(json.dumps({'source':source,'target':cache[source]},ensure_ascii=False)+'\n')
    if offset%960==0:print(file.stem,'translated',min(offset+96,len(missing)),'/',len(missing),'sentences',flush=True)
   translated=copy.deepcopy(country);translated['name']=COUNTRIES.get(country['name'],country['name'])
   for obj,key in text_fields(translated):
    if isinstance(obj[key],str):obj[key]=polish(obj[key],' '.join(cache[unit]for unit in segments(obj[key])))
   rnames={}
   catalog=json.loads((ROOT/'public/data/atlas-catalog.json').read_text());region_names=next((c.get('regionNamesEs',{})for c in catalog['countries']if c['id']==country['id']),{})
   for r in translated['regions']:
    r['name']=region_names.get(r['id'],REGIONS.get(r['name'],r['name']));rnames[r['id']]=r['name']
   for c in translated['cities']:
    c['name']=NAMES.get(c['name'],c['name']);c['regionName']=rnames[c['regionId']]
    for s in c['sections']:s['title']=TITLES.get(s['id'],s['title'])
   translated.update(language='es',translationSourceHash=source_hash,translationStatus='draft',translationRevision=REVISION,translationCoverage={'fields':len(strings),'sentences':len(units),'missingSentences':0},translatedCities=len(ready),translationModel='Helsinki-NLP/opus-mt-tc-big-en-es; local CTranslate2 int8; sentence-aware draft; editorial review required')
   temp=targetfile.with_suffix('.tmp');temp.write_text(json.dumps(translated,ensure_ascii=False,indent=2)+'\n');temp.replace(targetfile)
   print(file.stem,'DRAFT saved',len(ready),'cities;',len(missing),'new strings;',round(time.time()-start,1),'seconds',flush=True)
  if not args.watch:break
  time.sleep(12)
if __name__=='__main__':main()
