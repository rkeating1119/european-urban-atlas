"""Optional, researched profile modules. Missing coverage never creates blank UI."""
from pathlib import Path
import json
from html import escape as e

def load_features(root):
    data=root/'public/data/features'
    timelines={}
    for p in (data/'timelines').glob('*.json'):
        doc=json.loads(p.read_text())
        for city,record in doc['cities'].items():
            if record['reviewStatus']!='reviewed':continue
            timelines[f'{doc["countryId"]}:{city}']=record
    def records(name,key='records'):
        p=data/f'{name}.json'
        return json.loads(p.read_text()).get(key,[])if p.exists()else[]
    return {'timelines':timelines,'audio':[r for r in records('audio')if r.get('kind')=='speech'and r.get('speaker',{}).get('originSourceUrl')],'culture':records('culture'),'calendar':records('calendar','events'),'countryNames':{}}


def timeline_html(features,city,lang):
    data=features['timelines'].get(f'{city["countryId"]}:{city["id"]}')
    if not data:return ''
    tr=lambda en,es:es if lang=='es'else en
    events=data['milestones'];sources={s['id']:s for s in data['sources']}
    def links(event):
        return ' · '.join(f'<a href="{e(sources[s]["url"],quote=True)}" target="_blank" rel="noopener noreferrer">{e(sources[s]["publisher"])}</a>'for s in event['sourceIds'])
    buttons=''.join(f'<button type="button" data-event="{i}" aria-pressed="{str(i==0).lower()}">{e(v["dateLabel"][lang])}</button>'for i,v in enumerate(events))
    articles=''.join(f'<article class="timeline-event" data-event-panel="{i}" id="timeline-event-{i}"><p class="eyebrow">{e(v["dateLabel"][lang])}</p><h3>{e(v["title"][lang])}</h3><p>{e(v["text"][lang])}</p><p class="feature-sources">{links(v)}</p></article>'for i,v in enumerate(events))
    return f'''<section id="timeline" class="city-timeline" data-timeline="{e(city['countryId']+':'+city['id'])}"><h2>{tr('How the city changed','Cómo cambió la ciudad')}</h2><div class="timeline-controls" hidden><div><button type="button" data-timeline-previous aria-label="{tr('Previous milestone','Hito anterior')}">←</button><button type="button" data-timeline-play aria-pressed="false">{tr('Play','Reproducir')}</button><button type="button" data-timeline-next aria-label="{tr('Next milestone','Hito siguiente')}">→</button><output class="timeline-position" aria-live="polite"></output></div><label><span class="sr-only">{tr('Choose a historical milestone','Elegir un hito histórico')}</span><input type="range" min="0" max="{len(events)-1}" value="0" step="1" data-timeline-scrub></label><div class="timeline-dates" role="group" aria-label="{tr('Historical milestones','Hitos históricos')}">{buttons}</div></div><div class="timeline-panels">{articles}</div><p class="note">{tr('A selection of turning points. A period label describes a span of time, not an exact day.','Una selección de momentos decisivos. Las fechas de períodos indican una etapa, no un día exacto.')}</p></section>'''

def applies(record,countryId,regionId=None,cityId=None):
    countries=record.get('countryIds',[])
    if countries and countryId not in countries:return False
    cities=record.get('cityIds',[]);regions=record.get('regionIds',[])
    if cities or regions:return bool(cityId and f'{countryId}:{cityId}'in cities or regionId and f'{countryId}:{regionId}'in regions)
    return countryId in countries

def profile_extras(features,country,lang,asset,url,city=None,region=None,only_audio=False):
    tr=lambda en,es:es if lang=='es'else en
    cid=country['id'];rid=city['regionId']if city else region['id']if region else None
    cityid=city['id']if city else None
    result=[];toc=[]
    culture=[r for r in features['culture']if applies(r,cid,rid,cityid)]
    if culture and not only_audio:
        body=''
        for r in culture:
            body+=f'<article><h3>{e(r["title"][lang])}</h3>'+''.join(f'<p>{e(p)}</p>'for p in r['paragraphs'][lang])+f'<p class="feature-sources">'+source_links(r['sources'])+'</p></article>'
        result.append(f'<section id="local-culture"><h2>{tr("Local traditions and cultural life","Tradiciones y vida cultural")}</h2>{body}</section>');toc.append(('local-culture',tr('Traditions','Tradiciones')))
    recordings=[r for r in features['audio']if applies(r,cid,rid,cityid)]
    if recordings:
        cards=''
        for r in recordings:
            duration=int(round(r.get('durationSeconds',0)));duration=f'{duration//60}:{duration%60:02}'
            transcription=f'<details><summary>{tr("Transcript / translation","Transcripción / traducción")}</summary><p>{e(r["transcript"][lang])}</p></details>'if r.get('transcript')else''
            cards+=f'''<article class="recording-card"><p class="eyebrow">{tr('Speech','Voz')if r['kind']=='speech'else tr('Soundscape','Ambiente sonoro')} · {duration}</p><h3>{e(r['title'][lang])}</h3><p>{e(r['description'][lang])}</p><p class="recording-facts">{e(r['speaker']['origin'][lang])}<br>{tr('Recorded:','Grabación:')} {e(r['location'][lang])} · {e(r.get('date',tr('Date not stated','Fecha no indicada')))}{(' · '+e(r['language'][lang]))if r.get('language')else''}</p><button type="button" class="button light recording-play">▶ {tr('Listen','Escuchar')}</button><audio preload="none" controls hidden data-recording-src="{e(asset(r['src']),quote=True)}" data-fallback-src="{e(asset(r['fallbackSrc'])if r.get('fallbackSrc')else'',quote=True)}" aria-label="{e(r['title'][lang],quote=True)}"></audio><p class="recording-status" role="status"></p>{transcription}<details><summary>{tr('About this recording','Sobre esta grabación')}</summary><p>{e(r.get('scopeNote',{}).get(lang,''))}</p><p class="feature-sources"><a href="{e(r['speaker']['originSourceUrl'],quote=True)}">{tr('Speaker background','Datos del hablante')}</a> · {e(r['creator'])} · <a href="{e(r['licenseUrl'],quote=True)}">{e(r['license'])}</a> · <a href="{e(r['sourceUrl'],quote=True)}">{tr('Original and attribution','Original y atribución')}</a></p></details></article>'''
        result.append(f'<section id="sounds"><h2>{tr("Language and accent","Lengua y acento")}</h2><div class="recording-list">{cards}</div></section>');toc.append(('sounds',tr('Language and accent','Lengua y acento')))
    events=[r for r in features['calendar']if applies(r,cid,rid,cityid)]
    if events and not only_audio:
        result.append(f'<section id="yearly-calendar"><h2>{tr("The yearly calendar","El calendario anual")}</h2>'+calendar_cards(events,lang,features['countryNames'])+f'<p class="note"><a href="{e(url("/calendar/"),quote=True)}">{tr("Explore the calendar across countries","Explorar el calendario de los países")} →</a></p></section>');toc.append(('yearly-calendar',tr('The yearly calendar','El calendario anual')))
    return ''.join(result),toc

def source_links(sources):
    return ' · '.join(f'<a href="{e(s["url"],quote=True)}" target="_blank" rel="noopener noreferrer">{e(s.get("publisher",s["title"]))}</a>'for s in sources)

def calendar_cards(events,lang,countryNames):
    tr=lambda en,es:es if lang=='es'else en
    cards=''
    for r in sorted(events,key=lambda r:(r['sortMonth'],r['id'])):
        scope=tr('Local celebration','Celebración local')if r.get('cityIds')or r.get('regionIds')else tr('National date','Fecha nacional')
        countries=' · '.join(countryNames.get(cid,{}).get(lang,cid)for cid in r['countryIds'])
        cards+=f'<article class="calendar-card" data-month="{r["sortMonth"]}" data-countries="{e(" ".join(r["countryIds"]),quote=True)}"><p class="eyebrow">{e(countries)} · {scope}</p><h3>{e(r["title"][lang])}</h3><p class="calendar-date">{e(r["dateLabel"][lang])}</p><p>{e(r["text"][lang])}</p><p class="note">{e(r["publicHoliday"][lang])}</p><p class="feature-sources"><a href="{e(r["sourceUrl"],quote=True)}" target="_blank" rel="noopener noreferrer">{e(r["publisher"])}</a></p></article>'
    return cards

def calendar_page(features,countries,lang):
    tr=lambda en,es:es if lang=='es'else en
    months=['January','February','March','April','May','June','July','August','September','October','November','December']if lang=='en'else['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre']
    return f'''<div class="container"><header class="profile-header"><h1>{tr('A year across Europe','Un año por Europa')}</h1><p class="lede">{tr('National holidays, neighbourhood celebrations, literature, music and seasonal gatherings.','Fiestas nacionales, celebraciones de barrio, literatura, música y encuentros de temporada.')}</p><p>{tr('These are recurring dates and traditions. Local programmes and substitute days off vary by year; each entry links to its source.','Son fechas y tradiciones recurrentes. Los programas locales y los descansos sustitutorios cambian según el año; cada entrada enlaza su fuente.')}</p></header><form id="calendar-filter" class="calendar-filter"><label>{tr('Country','País')}<select name="country"><option value="">{tr('All countries','Todos los países')}</option>{''.join(f'<option value="{c["id"]}">{e(c["name"])}</option>'for c in countries)}</select></label><label>{tr('Month','Mes')}<select name="month"><option value="">{tr('All months','Todos los meses')}</option>{''.join(f'<option value="{i+1}">{m}</option>'for i,m in enumerate(months))}</select></label></form><p id="calendar-status" role="status"></p><div class="calendar-grid">{calendar_cards(features['calendar'],lang,features['countryNames'])}</div></div>'''


def listen_page(features,countries,lang,asset,url):
    tr=lambda en,es:es if lang=='es'else en
    batch={'ES':'madrid','FR':'paris','IT':'rome','GB':'london','IE':'dublin','DE':'berlin','CH':'zurich','GR':'athens','NO':'oslo','SE':'stockholm'}
    cards=[]
    for c in countries:
        city=next((x for x in c['cities']if x['id']==batch[c['id']]),None)
        if not city:continue
        audio,_=profile_extras(features,c,lang,asset,url,city=city,only_audio=True)
        if not audio:continue
        audio=audio.replace('id="sounds"',f'id="sounds-{c["id"]}"').replace('<h2>'+tr('Language and accent','Lengua y acento')+'</h2>','')
        cards.append(f'<article class="listen-city"><header><p class="eyebrow">{e(c["name"])}</p><h2><a href="{e(city["url"],quote=True)}#sounds">{e(city["name"])} ↗</a></h2></header>{audio}</article>')
    empty='<p>'+tr('Native-speaker samples are being prepared.','Se están preparando las muestras de hablantes nativos.')+'</p>'if not cards else''
    return f'<div class="container listen-page"><header class="profile-header"><p class="eyebrow">{tr("NATIVE VOICES","VOCES NATIVAS")}</p><h1>{tr("Languages and accents","Lenguas y acentos")}</h1><p class="lede">{tr("Hear native speakers from Europe’s cities in their own languages. Each sample identifies the speaker’s origins and the language or variety they use.","Escucha a hablantes nativos de las ciudades europeas en sus propias lenguas. Cada muestra indica el origen del hablante y la lengua o variedad que utiliza.")}</p><p>{tr("Open a city’s profile for more about local language and everyday life.","Abre el artículo de una ciudad para conocer mejor su contexto lingüístico y su vida cotidiana.")}</p></header><div class="listen-grid">'+empty+''.join(cards)+'</div></div>'
