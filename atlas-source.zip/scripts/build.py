#!/usr/bin/env python3
"""Render the saved bilingual, ten-country atlas. Draft output is never a release."""
from pathlib import Path
from urllib.parse import quote
import argparse,copy,hashlib,html,json,os,re,shutil,subprocess
from ui_copy import UI,CATEGORIES,ABOUT
from release_contract import source_release
from feature_directory import prepare_directory,directory_html
from feature_content import load_features,timeline_html,profile_extras,calendar_page,listen_page
ROOT=Path(__file__).resolve().parents[1];os.chdir(ROOT)
parser=argparse.ArgumentParser();parser.add_argument('--draft',action='store_true');args=parser.parse_args()
DATA=ROOT/'public/data';OUT=ROOT/'dist/client';catalog=json.loads((DATA/'atlas-catalog.json').read_text());config=json.loads((ROOT/'.openai/github-pages.json').read_text());base=config.get('base_path','').rstrip('/');origin=config.get('expected_url','').rstrip('/')
def read(p):return json.loads(p.read_text())
def e(x):return html.escape(str(x if x is not None else ''),quote=True)
def asset(p):return base+p
english={};spanish={}
for item in catalog['countries']:
 p=DATA/'editorial'/f'{item["slug"]}.json'
 if not p.exists():
  if args.draft:continue
  raise ValueError('Missing country: '+item['slug'])
 c=read(p);english[c['id']]=c
 if not args.draft:
  if len(c['cities'])!=item['expectedCities']:raise ValueError(f'{c["name"]}: expected {item["expectedCities"]} cities')
  if any(x.get('contentVersion')!=3 for x in c['cities']):raise ValueError(c['name']+': unfinished article revision')
 sp=DATA/'editorial/es'/p.name
 if sp.exists():
  sc=read(sp)
  if not args.draft and(sc.get('translationStatus')!='reviewed'or sc.get('translationEditing')or sc.get('translationSourceHash')!=hashlib.sha256(p.read_bytes()).hexdigest()):raise ValueError(c['name']+': Spanish edition needs current completed review')
  spanish[c['id']]=sc
 elif args.draft:spanish[c['id']]=copy.deepcopy(c)
 else:raise ValueError('Missing Spanish edition: '+item['slug'])
features=load_features(ROOT)
features['countryNames']={cid:{'en':c['name'],'es':spanish[cid]['name']}for cid,c in english.items()}
release=source_release(ROOT)
if OUT.exists():shutil.rmtree(OUT)
(OUT/'assets').mkdir(parents=True);(OUT/'data/maps').mkdir(parents=True)
for f in (ROOT/'public/assets').iterdir():
 if f.is_file()and '-v1'not in f.name:shutil.copy2(f,OUT/'assets'/f.name)
shutil.copyfile(ROOT/'node_modules/maplibre-gl/dist/maplibre-gl.css',OUT/'assets/maplibre-gl.css')
if features['audio']:
 (OUT/'assets/audio').mkdir(parents=True,exist_ok=True)
 for recording in features['audio']:
  for key in ['src','fallbackSrc']:
   if recording.get(key):
    source=ROOT/'public'/recording[key].lstrip('/')
    if not source.is_file():raise ValueError('Missing verified speech asset: '+str(source))
    shutil.copy2(source,OUT/recording[key].lstrip('/'))
 (OUT/'assets/audio/ATTRIBUTION.json').write_text(json.dumps({'records':features['audio']},ensure_ascii=False,indent=2)+'\n')
for name in ['audio','calendar','culture']:
 if (DATA/f'features/{name}.json').exists():
  (OUT/'data/features').mkdir(parents=True,exist_ok=True);shutil.copy2(DATA/f'features/{name}.json',OUT/f'data/features/{name}.json')
for folder in ['maps','timelines']:
 if (DATA/f'features/{folder}').exists():shutil.copytree(DATA/f'features/{folder}',OUT/f'data/features/{folder}',dirs_exist_ok=True)
for f in (DATA/'maps').iterdir():
 if f.is_file():shutil.copy2(f,OUT/'data/maps'/f.name)
directory_summary=prepare_directory(ROOT,OUT,english,spanish,catalog)
logo='<svg viewBox="0 0 48 48" fill="none" aria-hidden="true"><circle cx="24" cy="24" r="20" stroke="currentColor" stroke-width=".8"/><path d="M24 1v46M1 24h46M10 10l28 28M10 38l28-28" stroke="currentColor" stroke-width=".6"/><path d="m24 8 5 16-5 16-5-16Z" fill="#275d4e"/><path d="m24 8 5 16h-5Z" fill="#b54a35"/></svg>'
all_routes=[];language_summaries={}
for lang,raw in [('en',english),('es',spanish)]:
 t=UI[lang];prefix='/es'if lang=='es'else''
 def url(p):return base+prefix+p
 def paragraphs(ps):return ''.join(f'<p>{e(p)}</p>'for p in ps)
 countries=[];cities=[]
 for item in catalog['countries']:
  if item['id']not in raw:continue
  c=copy.deepcopy(raw[item['id']]);c['url']=url('/'+c['slug']+'/');c['view']=copy.deepcopy(item['view']);c['color']=item['color']
  if lang=='es':
   for inset in c['view']['insets']:inset['name']=inset.get('nameEs',inset['name'])
  for r in c['regions']:
   if lang=='es':r['name']=item.get('regionNamesEs',{}).get(r['id'],r['name'])
   r['url']=url(f'/{c["slug"]}/regions/{r["id"]}/')
  rby={r['id']:r for r in c['regions']}
  labels=c.get('mapCityIds')or[x['id']for x in sorted(c['cities'],key=lambda x:(x.get('population')or{}).get('value',0),reverse=True)[:10]]
  for city in c['cities']:
   city.setdefault('aliases',[])
   original=next((x for x in english[c['id']]['cities']if x['id']==city['id']),None)
   if original and original['name']!=city['name']:city['aliases']=list(dict.fromkeys(city['aliases']+[original['name']]))
   city['url']=url(f'/{c["slug"]}/cities/{city["id"]}/');city['countryName']=c['name'];city['regionName']=rby[city['regionId']]['name'];city['mapLabel']=city['id']in labels
   city['details']={}
   for sid in ['architecture','geography','neighborhoods','food','education','politics','lgbtq','people']:
    section=next((s for s in city['sections']if s['id']==sid),None)
    if section:city['details'][sid]=' '.join(re.split(r'(?<=[.!?])\s+',' '.join(section['paragraphs']))[:2])
   cities.append(city)
  countries.append(c)
 categories=[{'id':i,'name':n,'description':d}for i,n,d in CATEGORIES[lang]]
 clientkeys={'id','name','aliases','countryId','countryName','regionId','regionName','lat','lon','summary','goodFor','tradeoffs','population','size','ratings','url','mapLabel','details'}
 clientcities=[{k:v for k,v in c.items()if k in clientkeys}for c in cities]
 clientcountrykeys={'id','slug','name','summary','url','regions','color','view'}
 clientcountries=[{**{k:v for k,v in c.items()if k in clientcountrykeys},'cities':[{'id':x['id'],'name':x['name']}for x in c['cities']]}for c in countries]
 (OUT/'data'/f'atlas{"-es"if lang=="es"else""}.json').write_text(json.dumps({'language':lang,'overview':catalog['overview'],'countries':clientcountries,'cities':clientcities,'categories':categories},ensure_ascii=False,separators=(',',':')))
 indexkeys={'id','name','aliases','countryId','countryName','regionId','regionName','lat','lon','summary','population','url','mapLabel'}
 (OUT/'data'/f'atlas-index{"-es"if lang=="es"else""}.json').write_text(json.dumps({'language':lang,'overview':catalog['overview'],'countries':clientcountries,'cities':[{k:v for k,v in c.items()if k in indexkeys}for c in cities]},ensure_ascii=False,separators=(',',':')))
 def header(active,path):
  options=f'<option value="{url("/")}">{t["europe"]}</option>'+''.join(f'<option value="{e(c["url"])}" '+('selected'if c['id']==active else'')+f'>{e(c["name"])}</option>'for c in countries)
  other=asset((''if lang=='es'else'/es')+path)
  return f'''<a class="skip" href="#main">{t['skip']}</a><header class="site-header"><a class="brand" href="{url('/')}">{logo}<span class="brand-title">{t['brand']}<small>{t['tagline']}</small></span></a><nav class="main-nav" aria-label="{'Navegación principal'if lang=='es'else'Main navigation'}"><label class="country-control"><span class="sr-only">{t['chooseCountry']}</span><select class="country-switch" aria-label="{t['chooseCountry']}">{options}</select></label><a class="nav-browse" href="{url('/cities/')}">{t['browse']}</a><a class="nav-compare" href="{url('/compare/')}">{t['compare']}</a><a class="language-toggle" data-language-toggle href="{e(other)}" lang="{'en'if lang=='es'else'es'}" aria-label="{t['languageLabel']}">{t['language']} <span aria-hidden="true">⇄</span></a><button id="sound-toggle" type="button" class="sound-control" aria-label="{t['soundOff']}" aria-pressed="true">♪</button></nav><div class="search-wrap"><span class="search-icon" aria-hidden="true">⌕</span><label class="sr-only" for="global-search">{t['searchLabel']}</label><input id="global-search" type="search" placeholder="{t['searchPlaceholder']}" autocomplete="off" aria-controls="search-results"><div id="search-results" class="search-results" hidden role="region" aria-label="{'Resultados'if lang=='es'else'Search results'}" aria-live="polite"></div></div></header>'''
 def page(path,title,body,description='',active=None,kind='WebPage'):
  path='/'+path.strip('/')+'/'if path!='/'else'/';relative=prefix+path;target=OUT/relative.lstrip('/')/'index.html';target.parent.mkdir(parents=True,exist_ok=True)
  canonical=origin+url(path);schema=json.dumps({'@context':'https://schema.org','@type':kind,'name':title,'description':description,'inLanguage':lang},ensure_ascii=False).replace('</','<\\/')
  alternates=''.join(f'<link rel="alternate" hreflang="{code}" href="{e(origin+asset(("/es"if code=="es"else"")+path))}">'for code in ['en','es'])
  footer=f'<footer class="site-footer"><p>{t["brand"]}</p><nav aria-label="{'Pie de página'if lang=='es'else'Footer'}"><a href="{url('/listen/')}">{'Lenguas y acentos'if lang=='es'else'Languages and accents'}</a><a href="{url('/explore/')}">{'Explorar al azar'if lang=='es'else'Explore somewhere random'}</a><a href="{url('/calendar/')}">{'Calendario'if lang=='es'else'Calendar'}</a><a href="{url('/cities/')}">{t["browse"]}</a><a href="{url('/about/')}">{t["about"]}</a><a href="{url('/credits/')}">{t["credits"]}</a></nav></footer>'
  target.write_text(f'''<!doctype html><html lang="{lang}" data-base="{e(base)}" data-release="{release}" data-draft="{str(args.draft).lower()}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#275d4e"><title>{e(title)} · {t['brand']}</title><meta name="description" content="{e(description[:300])}"><meta property="og:title" content="{e(title)}"><meta property="og:description" content="{e(description[:300])}"><link rel="canonical" href="{e(canonical)}">{alternates}<link rel="icon" href="{asset('/assets/favicon.svg')}" type="image/svg+xml"><link rel="stylesheet" href="{asset('/assets/style.css')}?v={release}"><script type="module" src="{asset('/assets/app.js')}?v={release}"></script><script type="application/ld+json">{schema}</script></head><body>{header(active,path)}<main id="main">{body}</main>{footer}</body></html>''')
  all_routes.append(relative)
 def crumb(parts):return f'<nav class="breadcrumbs" aria-label="{'Ruta de navegación'if lang=='es'else'Breadcrumb'}">'+'<span aria-hidden="true">/</span>'.join(f'<a href="{e(u)}">{e(n)}</a>'for n,u in [(t['europe'],url('/'))]+parts)+'</nav>'
 def heading(title,link=None):return f'<div class="section-heading"><h2>{e(title)}</h2>'+ (f'<a href="{e(link[1])}">{e(link[0])} →</a>'if link else'')+'</div>'
 def card(city):return f'<a class="browse-city" href="{e(city["url"])}"><p class="eyebrow">{e(city["regionName"])} · {e(city["countryName"])}</p><h3>{e(city["name"])} <span aria-hidden="true">↗</span></h3><p>{e(city["summary"])}</p><div class="city-tags">'+''.join(f'<span>{e(x)}</span>'for x in city['goodFor'][:3])+'</div></a>'
 def carousel(cs):return f'<div data-city-carousel><div class="carousel-controls"><span class="carousel-position" aria-live="polite"></span><button class="carousel-previous" type="button" aria-label="{t["previousCities"]}">←</button><button class="carousel-next" type="button" aria-label="{t["nextCities"]}">→</button></div><div class="city-carousel-track">'+''.join(card(c)for c in cs)+'</div></div>'
 def backmap(c):return f'<a class="map-return" aria-label="{t["backMap"]}" href="{e(c["url"])}?map=restore#atlas-map">← {t["backMap"]}</a>'
 def map_html(country=None,region=None,city=None,large=False,explorer=False):
  country_selection=not country and not city and not explorer
  map_label=('Mapa interactivo de países'if lang=='es'else'Interactive country map')if country_selection else t['mapLabel']
  if explorer:map_label='Mapa del explorador'if lang=='es'else'Geographic explorer map'
  map_help=('Elige un país por su nombre o pulsa sobre él en el mapa.'if lang=='es'else'Choose a country by its name or click it on the map.')if country_selection else t['mapHelp']
  attrs=('data-explorer="true" 'if explorer else'')+(f'data-country="{country["id"]}"'if country else'')+(f' data-region="{region["id"]}"'if region else'')+(f' data-city="{city["countryId"]}:{city["id"]}"'if city else'')
  if explorer:map_help='El punto muestra el lugar seleccionado.'if lang=='es'else'The point shows the selected place.'
  controls=f'<button id="map-reset" type="button" aria-label="{t["reset"]}">{t["reset"]}</button>'
  if country and not city:
   controls=f'<label><span class="sr-only">{t["zoomRegion"]}</span><select id="map-region" aria-label="{t["zoomRegion"]}"><option value="">{t["allRegions"]}</option>'+''.join(f'<option value="{r["id"]}">{e(r["name"])}</option>'for r in country['regions'])+'</select></label>'+controls
   if country['view']['insets']:controls+=f'<label><span class="sr-only">{t["insets"]}</span><select id="map-inset" aria-label="{t["insets"]}"><option value="">{t["insets"]}</option>'+''.join(f'<option value="{i}">{e(x["name"])}</option>'for i,x in enumerate(country['view']['insets']))+'</select></label>'
  return f'<div class="map-shell {"large-map"if large else"city-map"}"><div id="atlas-map" class="atlas-map" {attrs} role="region" aria-label="{map_label}"></div><p id="map-status" class="map-status" role="status">{t["mapLoading"]}</p><div class="map-bottom">{controls}</div></div><p class="map-help">{map_help}</p>'
 home=f'<div class="container"><section class="page-intro"><p class="eyebrow">{t["tagline"]}</p><h1>{t["homeTitle"]}</h1><p class="lede">{t["homeIntro"]}</p></section>'+map_html(large=True)+'<section class="editorial-section">'+heading(t['chooseHeading'])+'<div class="country-grid">'+''.join(f'<a class="country-card" href="{e(c["url"])}"><span class="country-number">{i+1:02}</span><h2>{e(c["name"])} ↗</h2><p>{e(c["summary"])}</p><span class="text-link">{len(c["cities"])} {t["cityCount"]} →</span></a>'for i,c in enumerate(countries))+'</div></section><section class="editorial-section">'+heading(t['cityStart'],(t['allCities'],url('/cities/')))+'<div class="city-grid">'+''.join(card(c)for c in cities if(c['countryId'],c['id'])in [('ES','madrid'),('FR','paris'),('IT','rome'),('GB','london'),('DE','berlin'),('SE','stockholm')])+'</div></section><section class="compare-invite"><h2>'+t['comparisonInvite']+'</h2><p>'+t['comparisonText']+'</p><a class="button" href="'+url('/compare/')+'">'+t['compare']+' →</a></section></div>'
 home=home.replace('</section>',f'<a class="button light audio-invite" href="{url("/listen/")}">♪ {"Lenguas y acentos"if lang=="es"else"Hear languages and accents"} →</a></section>',1)
 page('/',t['homeTitle'],home,t['homeIntro'])
 for c in countries:
  cityjump=f'<label class="country-jump">{t["jumpCity"]}<select class="city-switch" aria-label="{t["jumpCity"]}"><option value="">{t["chooseCity"]}</option>'+''.join(f'<option value="{e(x["url"])}">{e(x["name"])}</option>'for x in sorted(c['cities'],key=lambda x:x['name']))+'</select></label>'
  regions='<div class="regions-grid">'+''.join(f'<a class="region-row" href="{e(r["url"])}"><span>{e(r["name"])}</span><span aria-hidden="true">↗</span></a>'for r in c['regions'])+'</div>'
  body='<div class="container">'+crumb([(c['name'],c['url'])])+f'<header class="profile-header"><p class="eyebrow">{t["citiesToKnow"]}</p><h1>{e(c["name"])}</h1><p class="lede">{e(c["summary"])}</p>{cityjump}</header>'+map_html(c,large=True)+'<section class="editorial-section">'+heading(t['regions'])+regions+'</section><section class="editorial-section">'+heading(t['countryCities'],(t['searchFilter'],url('/cities/')+'?country='+c['id']))+carousel(c['cities'])+'</section></div>'
  country_extras,_=profile_extras(features,c,lang,asset,url)
  body=body.removesuffix('</div>')+f'<div class="prose country-extras">{country_extras}</div></div>'
  page('/'+c['slug']+'/',c['name'],body,c['summary'],c['id'])
  for r in c['regions']:
   cs=[x for x in c['cities']if x['regionId']==r['id']]
   body='<div class="container">'+crumb([(c['name'],c['url']),(r['name'],r['url'])])+backmap(c)+f'<header class="profile-header"><p class="eyebrow">{e(c["name"])}</p><h1>{e(r["name"])}</h1><p class="lede">{e(r["summary"])}</p></header>'+map_html(c,r,large=True)+'<section class="editorial-section">'+heading(t['regionCities'])+carousel(cs)+'</section></div>'
   region_extras,_=profile_extras(features,c,lang,asset,url,region=r)
   body=body.removesuffix('</div>')+f'<div class="prose country-extras">{region_extras}</div></div>'
   page(f'/{c["slug"]}/regions/{r["id"]}/',r['name'],body,r['summary'],c['id'])
  for city in c['cities']:
   r=next(r for r in c['regions']if r['id']==city['regionId'])
   summary=f'<div class="quick-read"><div><p>{e(city["summary"])}</p></div><div class="quick-lists"><p><strong>{t["knownFor"]}</strong></p><ul>'+''.join(f'<li>{e(x)}</li>'for x in city['goodFor'])+f'</ul><p><strong>{t["tensions"]}</strong></p><ul>'+''.join(f'<li>{e(x)}</li>'for x in city['tradeoffs'])+'</ul></div></div>'
   overview='<div class="city-overview" aria-label="'+('Panorama general'if lang=='es'else'City overview')+'">'+paragraphs(city.get('overview',[]))+'</div>'
   toc=f'<nav class="toc" aria-label="{t["jumpTo"]}"><p class="eyebrow">{t["jumpTo"]}</p>'+''.join(f'<a href="#{e(s["id"])}">{e(s["title"])}</a>'for s in city['sections'])+'</nav>'
   sections=''.join(f'<section id="{e(s["id"])}"><h2>{e(s["title"])}</h2>{paragraphs(s["paragraphs"])}</section>'for s in city['sections'])
   extras,extra_toc=profile_extras(features,c,lang,asset,url,city=city)
   toc=toc.replace('</nav>',''.join(f'<a href="#{sid}">{title}</a>'for sid,title in extra_toc)+'</nav>')
   timeline=timeline_html(features,city,lang)
   if timeline:toc=toc.replace('</nav>',f'<a href="#timeline">{"Historia en fechas"if lang=="es"else"City timeline"}</a></nav>')
   population=''
   if city.get('population'):
    p=city['population'];unit={'municipality':t['municipality'],'urban area':t['urbanArea']}.get(p.get('unit'),p.get('unit',''))
    population=f'<div><dt>{t["population"]}</dt><dd>{int(p["value"]):,}<small>{p["year"]} · {e(unit)}</small></dd></div>'
   related=[x for x in c['cities']if x['id']!=city['id']and x['regionId']==city['regionId']][:4]
   if len(related)<3:related.extend(x for x in c['cities'][:6]if x['id']!=city['id']and x not in related)
   other='FR:paris'if c['id']!='FR'else'ES:madrid'
   aside=f'<aside class="profile-aside"><div><p class="eyebrow">{t["atGlance"]}</p><dl class="facts"><div><dt>{t["region"]}</dt><dd>{e(city["regionName"])}</dd></div>{population}</dl><a class="button light" href="{url("/compare/")}?cities={c["id"]}:{city["id"]},{other}">{t["compareCity"]} →</a><p class="eyebrow" style="margin-top:30px">{t["related"]}</p>'+''.join(f'<a class="region-row" href="{e(x["url"])}">{e(x["name"])} ↗</a>'for x in related[:5])+'</div></aside>'
   scores=f'<details class="city-scores"><summary>{t["cityScores"]}</summary><p class="note">{t["scoreNote"]} <a href="{url("/about/")}">{t["howRatings"]}</a>.</p><div class="score-list">'+''.join(f'<article><h3>{e(k["name"])}</h3><span class="rating-value"><b>{city["ratings"][k["id"]]["score"]}</b><small>/5</small></span><p>{e(city["ratings"][k["id"]]["summary"])}</p></article>'for k in categories)+'</div></details>'
   sources=f'<details class="city-sources"><summary>{t["sources"]}</summary><ul>'+''.join(f'<li><a href="{e(s["url"])}" target="_blank" rel="noopener noreferrer">{e(s["publisher"])}: {e(s["title"])}</a></li>'for s in city['sources'])+f'</ul><p>{t["updated"]}: {e(city.get("updated","2026-11-07"))}.</p></details>'
   photo=''
   if city['id']in ['madrid','bilbao','barcelona']and c['id']=='ES':photo=f'<figure class="profile-photo"><img src="{asset("/assets/"+city["id"]+".jpg")}" alt="{e(city["name"])}" width="1280" height="850"><figcaption><a href="{url("/credits/")}">{t["credits"]}</a></figcaption></figure>'
   body='<div class="container">'+crumb([(c['name'],c['url']),(r['name'],r['url']),(city['name'],city['url'])])+backmap(c)+f'<header class="profile-header city-header"><p class="eyebrow">{e(city["regionName"])} · {e(c["name"])}</p><h1>{e(city["name"])}</h1></header>'+summary+overview+photo+f'<div class="profile-layout">{toc}<div class="prose">{sections}{timeline}{extras}{scores}{sources}</div>{aside}</div><details class="location-details"><summary>{t["showLocation"]}</summary>'+map_html(c,city=city)+'</details></div>'
   page(f'/{c["slug"]}/cities/{city["id"]}/',city['name'],body,city['summary'],c['id'],'Article')
   if c['id']=='ES'and city.get('municipalityId'):
    old=OUT/prefix.lstrip('/')/'spain/places'/city['municipalityId']/'index.html';old.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(OUT/prefix.lstrip('/')/c['slug']/'cities'/city['id']/'index.html',old)
 options=''.join(f'<option value="{c["id"]}">{e(c["name"])}</option>'for c in countries)
 browse=f'<div class="container"><header class="profile-header"><p class="eyebrow">{t["tagline"]}</p><h1>{t["browseTitle"]}</h1><p class="lede">{t["browseIntro"]}</p></header><form id="browse-form" class="browse-form"><label>{t["search"]}<input id="browse-query" name="q" type="search" placeholder="{t["searchPlaceholder"]}"></label><label>{t["country"]}<select id="browse-country" name="country"><option value="">{t["allCountries"]}</option>{options}</select></label><label>{t["region"]}<select id="browse-region" name="region"><option value="">{t["allRegions"]}</option></select></label><label>{t["theme"]}<select name="theme"><option value="">{t["anything"]}</option>'+''.join(f'<option value="{k["id"]}">{e(k["name"])}</option>'for k in categories)+f'</select></label><label>{t["sort"]}<select name="sort"><option value="name">{t["name"]}</option><option value="population">{t["populationSort"]}</option><option value="affordability">{t["affordableSort"]}</option></select></label><button class="button" type="submit">{t["findCities"]} →</button></form><p id="browse-count" class="browse-count" role="status">{len(cities)} {t["cityCount"]}</p><div id="browse-results" class="city-grid">'+''.join(card(c)for c in cities)+'</div></div>'
 page('/cities/',t['browse'],browse,t['browseIntro'])
 page('/listen/','Lenguas y acentos'if lang=='es'else'Languages and accents',listen_page(features,countries,lang,asset,url),'Muestras de habla nativa'if lang=='es'else'Native speech samples')
 page('/calendar/','Calendario'if lang=='es'else'Calendar',calendar_page(features,countries,lang),'Calendario anual'if lang=='es'else'The yearly calendar')
 explorer_title='Explorador geográfico'if lang=='es'else'Geographic explorer'
 page('/explore/',explorer_title,directory_html(t,countries,lang,map_html),explorer_title)
 compare=f'<div class="container"><header class="profile-header"><p class="eyebrow">{t["compareEyebrow"]}</p><h1>{t["compareTitle"]}</h1><p class="lede">{t["compareIntro"]}</p></header><form id="compare-form" class="compare-form"><label>{t["firstCity"]}<select name="a" required aria-label="{t["firstCity"]}"></select></label><label>{t["secondCity"]}<select name="b" required aria-label="{t["secondCity"]}"></select></label><label>{t["thirdCity"]}<select name="c" aria-label="{t["thirdCity"]}"></select></label><button class="button" type="submit">{t["compare"]} →</button></form><p class="rating-note">{t["scoreNote"]} <a href="{url("/about/")}">{t["howRatings"]}</a>.</p><div id="compare-results" aria-live="polite"><p>{t["comparePrompt"]}</p></div></div>'
 page('/compare/',t['compare'],compare,t['compareIntro'])
 about='<div class="plain-page"><h1>'+t['about']+'</h1>'+''.join(f'<section><h2>{e(title)}</h2><p>{e(text)}</p></section>'for title,text in ABOUT[lang])+''.join(f'<p><strong>{e(k["name"])}:</strong> {e(k["description"])}</p>'for k in categories)+'</div>'
 page('/about/',t['about'],about,ABOUT[lang][0][1])
 images=read(DATA/'images.json')
 creditintro='Cada artículo reúne sus fuentes en una sección desplegable.'if lang=='es'else'Each article lists its sources in an expandable section.'
 credits='<div class="plain-page"><h1>'+t['credits']+'</h1><p>'+creditintro+'</p><h2>'+('Cartografía'if lang=='es'else'Maps')+'</h2><p>© EuroGeographics · Eurostat GISCO. 2024; United Kingdom / Reino Unido: 2016. <a href="https://ec.europa.eu/eurostat/web/gisco/geodata/statistical-units">Eurostat GISCO</a>.</p><h2>'+('Fotografía'if lang=='es'else'Photography')+'</h2>'+''.join(f'<p><a href="{e(x["source"])}">{e(x["title"])}</a> · {e(x["creator"])} · {e(x["date"])} · <a href="{e(x["licenseURL"])}">{e(x["license"])}</a>.</p>'for x in images)+'<h2>'+('Traducción y software'if lang=='es'else'Translation and software')+'</h2><p><a href="https://huggingface.co/Helsinki-NLP/opus-mt-tc-big-en-es">OPUS-MT · Helsinki-NLP</a> · CC BY 4.0. <a href="https://aclanthology.org/2020.eamt-1.61/">Tiedemann & Thottingal, 2020</a>. MapLibre GL JS · BSD 3-Clause.</p></div>'
 page('/credits/',t['credits'],credits,creditintro)
 page('/404/',t['notFound'],'<div class="plain-page"><h1>'+t['notFound']+'</h1><p><a href="'+url('/cities/')+'">'+t['browseReturn']+'</a></p></div>')
 if lang=='en':shutil.copyfile(OUT/'404/index.html',OUT/'404.html')
 for c in countries:
  page('/'+c['slug']+'/directory/',explorer_title,directory_html(t,countries,lang,map_html,c['id']),explorer_title,c['id'])
 language_summaries[lang]={'countries':{c['name']:len(c['cities'])for c in countries},'cities':len(cities)}
(OUT/'.nojekyll').write_text('');(OUT/'robots.txt').write_text('User-agent: *\nAllow: /\nSitemap: '+origin+asset('/sitemap.xml')+'\n')
(OUT/'sitemap.xml').write_text('<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+''.join(f'<url><loc>{e(origin+asset(p))}</loc></url>'for p in all_routes if not p.endswith('/404/'))+'</urlset>')
(ROOT/'dist/server').mkdir(parents=True,exist_ok=True);(ROOT/'dist/.openai').mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/'src/worker.js',ROOT/'dist/server/index.js');shutil.copyfile(ROOT/'.openai/hosting.json',ROOT/'dist/.openai/hosting.json')
node=shutil.which('node')or'/Users/ryankeating/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node';subprocess.run([node,'scripts/bundle.mjs'],check=True)
summary={'release':release,'languages':language_summaries,'routes':len(all_routes),'draft':args.draft};(OUT/'data/release.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False))
