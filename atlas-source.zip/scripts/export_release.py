#!/usr/bin/env python3
"""Package the verified static site or a clean source checkout without work caches."""
from pathlib import Path
import argparse,hashlib,json,subprocess,zipfile
from release_contract import source_release

ROOT=Path(__file__).resolve().parents[1]

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('kind',choices=['site','source'])
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    release=json.loads((ROOT/'dist/client/data/release.json').read_text())
    if release.get('draft') is not False:
        raise ValueError('Draft previews cannot be packaged as releases')
    if release['release']!=source_release(ROOT):
        raise ValueError('Build no longer matches the maintained source')
    if args.kind=='site':
        folder=ROOT/'dist/client'
        files=sorted(f for f in folder.rglob('*') if f.is_file())
        if not (folder/'.nojekyll').exists():
            raise ValueError('GitHub Pages artifact requires .nojekyll')
    else:
        dirty=subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True)
        if dirty.strip():
            raise ValueError('Commit the verified source and reports before exporting source')
        names=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0')
        folder=ROOT
        # Keep the original task attachment and historical screenshots in local Git
        # history; the portable public source contains maintained code/data/reports.
        files=sorted(ROOT/name for name in names if name and (ROOT/name).is_file()
                     and name!='docs/COMMISSION.txt' and not name.startswith('docs/screenshots/'))
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(args.output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as archive:
        for file in files:
            archive.write(file,file.relative_to(folder).as_posix())
    with zipfile.ZipFile(args.output)as archive:
        if archive.testzip() is not None:
            raise ValueError('Archive integrity check failed')
        if any(name.startswith('/')or'..'in Path(name).parts for name in archive.namelist()):
            raise ValueError('Unsafe archive path')
    print(json.dumps({'kind':args.kind,'release':release['release'],'path':str(args.output.resolve()),'files':len(files),'bytes':args.output.stat().st_size,'sha256':hashlib.sha256(args.output.read_bytes()).hexdigest()},indent=2))

if __name__=='__main__':main()
