#!/usr/bin/env python3
"""Package labelled regions from dated official GISCO geometry; no remote map tiles."""
import json,math,ssl,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];MAPS=ROOT/'public/data/maps'
def inside(p,ring):
 x,y=p;v=False
 for (ax,ay),(bx,by)in zip(ring,ring[1:]):
  if (ay>y)!=(by>y)and x<(bx-ax)*(y-ay)/(by-ay)+ax:v=not v
 return v
def distance(p,ring):
 x,y=p;best=1e20
 for a,b in zip(ring,ring[1:]):
  ax,ay=a[:2];bx,by=b[:2];dx=bx-ax;dy=by-ay;t=max(0,min(1,((x-ax)*dx+(y-ay)*dy)/(dx*dx+dy*dy)))if dx or dy else 0
  best=min(best,(x-ax-t*dx)**2+(y-ay-t*dy)**2)
 return best

def label_point(geometry):
 polygons=[geometry['coordinates']]if geometry['type']=='Polygon'else geometry['coordinates']
 def area(poly):
  ring=poly[0];return abs(sum(a[0]*b[1]-b[0]*a[1]for a,b in zip(ring,ring[1:])))
 poly=max(polygons,key=area);ring=poly[0];xs=[a[0]for a in ring];ys=[a[1]for a in ring];left,right=min(xs),max(xs);bottom,top=min(ys),max(ys)
 best=ring[0][:2];score=-1
 for level in range(5):
  dx=(right-left)/12;dy=(top-bottom)/12
  for i in range(13):
   for j in range(13):
    p=[left+i*dx,bottom+j*dy]
    if inside(p,ring)and not any(inside(p,h)for h in poly[1:]):
     d=distance(p,ring)
     if d>score:best=p;score=d
  left,right=best[0]-dx,best[0]+dx;bottom,top=best[1]-dy,best[1]+dy
 return [round(x,5)for x in best]

def source(year):
 fallback=ROOT.parent/'data-downloads'/f'NUTS_RG_03M_{year}_4326.geojson';cache=ROOT/'work/map-sources'/fallback.name
 if fallback.exists():return json.loads(fallback.read_text())
 cache.parent.mkdir(parents=True,exist_ok=True)
 if not cache.exists():
  with urllib.request.urlopen(f'https://gisco-services.ec.europa.eu/distribution/v2/nuts/geojson/{cache.name}',context=ssl.create_default_context(cafile='/etc/ssl/cert.pem'),timeout=60)as r:cache.write_bytes(r.read())
 return json.loads(cache.read_text())

if __name__=='__main__':
 for slug,country,code,level,year in [('united-kingdom','GB','UK',1,2016),('ireland','IE','IE',2,2024),('germany','DE','DE',1,2024),('switzerland','CH','CH',2,2024),('greece','GR','EL',2,2024),('norway','NO','NO',2,2024),('sweden','SE','SE',2,2024)]:
  a=source(year);features=[]
  for f in a['features']:
   p=f['properties']
   if p['CNTR_CODE']==code and p['LEVL_CODE']==level:
    features.append({'type':'Feature','properties':{'id':p['NUTS_ID'],'name':p.get('NAME_LATN')or p['NUTS_NAME'],'countryId':country,'sourceYear':year},'geometry':f['geometry']})
  (MAPS/(slug+'-regions.geojson')).write_text(json.dumps({'type':'FeatureCollection','features':features},ensure_ascii=False,separators=(',',':')))
 for file in MAPS.glob('*-regions.geojson'):
  d=json.loads(file.read_text())
  for f in d['features']:f['properties']['labelPoint']=label_point(f['geometry'])
  file.write_text(json.dumps(d,ensure_ascii=False,separators=(',',':')))
  print(file.name,len(d['features']),flush=True)
 p=MAPS/'world.geojson';d=json.loads(p.read_text())
 for f in d['features']:f['properties']['id']={'UK':'GB','EL':'GR'}.get(f['properties']['id'],f['properties']['id'])
 p.write_text(json.dumps(d,ensure_ascii=False,separators=(',',':')))
 p=MAPS/'provenance.json';d=json.loads(p.read_text());d['additionalRegions']='Germany NUTS1; Ireland, Switzerland, Greece, Norway and Sweden NUTS2, GISCO2024. UK NUTS1 geometry uses GISCO2016, the same12 country/English-region divisions. Region label anchors are interior points of the largest polygon. World UK/EL identifiers normalized to GB/GR.';d['ukSource']='https://gisco-services.ec.europa.eu/distribution/v2/nuts/geojson/NUTS_RG_03M_2016_4326.geojson';p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
