#!/usr/bin/env python3
"""Merge completed paired Spanish edits with exact English and Spanish guards.

This does not mark a translation reviewed: complete scope/coverage is reconciled
separately before the strict builder can publish it. Default mode validates only.
"""
from pathlib import Path
import argparse,copy,hashlib,json
ROOT=Path(__file__).resolve().parents[1]

def field(city,row):
 kind=row['kind']
 if kind=='section':
  section=next(s for s in city['sections'] if s['id']==row['sectionId'])
  return section['paragraphs'],row.get('index',row.get('paragraphIndex'))
 if kind=='overview':return city['overview'],row['index']
 if kind=='array':
  assert row['array']in ['goodFor','tradeoffs'],'Unsupported array field'
  return city[row['array']],row['index']
 if kind=='rating':return city['ratings'][row['ratingId']],'summary'
 raise ValueError('Unsupported prose field '+kind)

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('reviews',nargs='+',type=Path)
 parser.add_argument('--country',action='append')
 parser.add_argument('--apply',action='store_true')
 args=parser.parse_args();entries=[]
 for p in args.reviews:
  rows=json.loads(p.read_text())
  if isinstance(rows,dict):rows=rows['changes']
  entries.extend((p,r)for r in rows if not args.country or r['country']in args.country)
 assert entries,'No review entries selected'
 prepared=[];seen=set();report=[]
 for slug in sorted({r['country']for _,r in entries}):
  ep=ROOT/'public/data/editorial'/f'{slug}.json';sp=ep.parent/'es'/ep.name
  raw=ep.read_bytes();en=json.loads(raw);es=json.loads(sp.read_text())
  assert es['translationSourceHash']==hashlib.sha256(raw).hexdigest(),(slug,'English source changed')
  before=copy.deepcopy(es);em={c['id']:c for c in en['cities']};sm={c['id']:c for c in es['cities']};changed=already=retained=0
  for path,row in [(p,r)for p,r in entries if r['country']==slug]:
   key=(slug,row['cityId'],row['kind'],row.get('sectionId'),row.get('ratingId'),row.get('array'),row.get('index',row.get('paragraphIndex')))
   assert key not in seen,('Duplicate review entry',key);seen.add(key)
   ec,ei=field(em[row['cityId']],row);sc,si=field(sm[row['cityId']],row)
   assert ec[ei]==row['english'],('English guard failed',key)
   assert isinstance(row['spanish'],str)and row['spanish'].strip(),('Empty replacement',key)
   if sc[si]==row['spanish']:
    if row['oldSpanish']==row['spanish']:retained+=1
    else:already+=1
   else:
    assert sc[si]==row['oldSpanish'],('Spanish guard failed',key)
    sc[si]=row['spanish'];changed+=1
  # Only the selected prose fields are writable; identity, figures, scores,
  # sources, coordinates and other metadata remain byte-equivalent as values.
  check=copy.deepcopy(before)
  for _,row in [(p,r)for p,r in entries if r['country']==slug]:
   target=next(c for c in check['cities']if c['id']==row['cityId']);container,index=field(target,row);container[index]=row['spanish']
  assert check==es
  result={'country':slug,'fields':changed+already+retained,'changed':changed,'alreadyApplied':already,'retained':retained,'englishHash':hashlib.sha256(raw).hexdigest()}
  prepared.append((sp,es));report.append(result)
 if args.apply:
  # Validate every file before writing any country.
  for sp,es in prepared:sp.write_text(json.dumps(es,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'applied':args.apply,'countries':report},indent=2))
if __name__=='__main__':main()
