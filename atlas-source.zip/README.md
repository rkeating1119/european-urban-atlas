Current release `7eb1e7c9d96f` is live at https://rkeating1119.github.io/european-urban-atlas/. Native speech recordings are at /listen/ and the covered city pages (London, Dublin, Berlin and Stockholm). Six first-round cities still require verified speech; ambient soundscapes are excluded. Full scope/status and authoritative deployment evidence are in PROJECT-STATUS.md.

# European Urban Atlas · reader edition

Live site: https://rkeating1119.github.io/european-urban-atlas/

A published English/Spanish atlas of 417 cities across Spain 60, France 51, Italy 50, the UK 50, Ireland 25, Germany 50, Switzerland 30, Greece 35, Norway 31 and Sweden 35. Release `33e920cbab96` is live; see PROJECT-STATUS.md and RELEASE-REPORT.md for verification. Each city has a concise opening, a broader everyday-life overview and fifteen substantive sections. Geography and architecture are separate sections; education, dated politics, LGBT life and social relations follow the established topics. Comparisons combine seven explained editorial ratings with qualitative descriptions.

The latest brief supersedes the original all-municipality research commission. Read `docs/EXPANSION-BRIEF.md`, AGENTS.md and `docs/READER-AUDIT.md`. The historical geographical inventory is preserved; it is no longer the public catalog or completion target.

## Build and check

Requires Python 3.13+, Node 22+ and pnpm 11.

```sh
pnpm install --frozen-lockfile
pnpm build
pnpm test
node scripts/test-map-interaction.mjs
python3 scripts/preview.py
SSL_CERT_FILE=/etc/ssl/cert.pem python3 scripts/audit_reader_edition.py --require-public
SSL_CERT_FILE=/etc/ssl/cert.pem python3 scripts/check_reader_links.py
```

The certificate setting is for the current macOS Python trust store; omit on systems with a configured trust store. Do not disable TLS verification. Preview at http://127.0.0.1:4173/european-urban-atlas/. The public site runs independently of this preview.

## Maintained content and code

- `public/data/atlas-catalog.json`: canonical selection counts, country map views and Spanish region names.
- `public/data/editorial/{slug}.json` and `public/data/editorial/es/{slug}.json`: maintained English and Spanish country, regional and city content. Edit these, not generated HTML or historical catalogs.
- Every city carries a short summary, a two-or-more-paragraph general overview, fifteen sections with at least two substantive paragraphs, seven score/description pairs, references, coordinates and dated population where available. Scores are editorial judgments from 1 to 5; there is no overall ranking.
- `scripts/build.py`: shared country-independent city publication templates, compact browser data, route generation and metadata. Every city article is pre-rendered.
- `src/app.ts` and `src/map-hit.ts`: in-page menus, alias search, filters, comparisons, language/sound controls, saved map views and city-only screen-pixel targeting. Region names are separate links; background polygons never navigate.
- `public/data/maps/`: packaged world and regional geometry. `provenance.json` records publisher, transformation and rights. France mainland regions use NUTS1; overseas regions use NUTS2. Italy combines Trento/Bolzano geometry into the corresponding region.
- `scripts/audit_reader_edition.py`: current content, readability, selection, map-label, source, route, asset and public-origin checks. It also writes a reader-interest audit matrix.
- `docs/READER-AUDIT.*`, `docs/READER-SOURCE-LINKS.json`, `docs/BROWSER-QA-READER.json`: actual audit evidence and limitations.
- `.openai/github-pages.json`: public host/repository identity and project base path. `.github/workflows/pages.yml`: permanent deployment pipeline.

The earlier municipality database, adapters and validators remain in source control for reuse. Their disabled country adapters do not describe the current curated publication, which is driven by the catalog, ten English datasets, ten Spanish datasets and common renderer.

Spanish drafts can be generated entirely locally with `scripts/translate_spanish.py`. Its optional OPUS-MT/CTranslate2 environment and model files are not needed to build or read the saved site. Draft output is not publication-ready. The strict renderer requires reviewed Spanish with current English source hashes. `scripts/review_spanish.py` checks every prose pair using a local multilingual semantic model, numeric/date transfer and length/language flags; editorial review must also address idiom, proper names and source-specific meaning. Do not claim complete semantic review from a few samples. A draft preview is available through `python3 scripts/build.py --draft`; never publish it.

## Publishing and durable storage

Repository: https://github.com/rkeating1119/european-urban-atlas

GitHub Pages serves the site. A push of `atlas-site.zip` to main runs the saved workflow: unpack the verified static build, configure Pages, upload the artifact and deploy it. Pages must use GitHub Actions as its source, which is already configured. No custom domain, paid infrastructure or local tunnel is required.

Create the archive from the contents of `dist/client/`, not from its parent folder. Include `.nojekyll`, CSS, JS chunks, data and all routes. Keep the tested GitHub Pages base path `/european-urban-atlas`. Verify the uploaded archive checksum, successful workflow and public URLs before declaring a release live.

The connected GitHub integration can read the new public repository but has no installed write access to it. Initial repository creation, workflow save, Pages settings and archive upload were completed through the already authenticated browser. Future agents can use that authorized browser flow or an appropriate connected write capability; no new account or paid service is needed. Do not confuse a successful local build with a deployment.

The remote repository also preserves a source archive for continuation. The complete local Git history is maintained in this workspace and exported with the saved project. Keep source and content revisions together when publishing.

## Rights

Preserve GISCO/EuroGeographics attribution and noncommercial geographic-data terms. Photo licences are in `public/data/images.json` and the site credits. Dependency licences are in `docs/licenses/`. No current prices, wages or resident quotations are invented to fill gaps. Population periods remain visible beside counts.

## Maps and in-page menus

City dots are drawn once in a MapLibre circle layer with zoom-interpolated radius and stroke. HTML labels contain text only and preserve MapLibre's absolute positioning. Do not override marker positioning or scale the marker transform. Ten principal cities per country receive text labels, chosen explicitly where comparable population metadata is unavailable. Other points have desktop hover cards and direct city taps. Touch layouts suppress hover overlays. Region text links defer to a visible dot when the targets overlap, using the circle's actual zoom-scaled radius. Never restore region-fill click handlers.

Country city lists are horizontal carousels with previous/next-batch buttons. City and region return links restore the originating map page, center, zoom and selected area in the same browsing session. Language switches preserve the article, comparison/filter query and map view. Sounds are optional and have a persistent mute button.

All native selects are progressively enhanced into searchable in-page menus. Hidden native controls retain form values; visible buttons/listboxes handle selection, Escape, arrow keys and focus. Programmatic value changes use the atlas-select-refresh event. Dynamic option changes are observed. Menus fit the available viewport and map controls open upward. Keep these behaviors when adding controls.

The build adds a content release key to CSS/JavaScript URLs and the browser data request so a new release does not mix old cached data with new controls.
