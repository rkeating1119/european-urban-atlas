# European Urban Atlas · reader edition

Live site: https://rkeating1119.github.io/european-urban-atlas/

A readable, curated atlas of 161 cities: Spain 60, France 51 and Italy 50. Each city has a quick summary, good points and compromises, plus character, history, work, housing, neighborhoods, culture, food, transport and weather. Comparisons include seven explained editorial ratings, food and neighborhood summaries. All regions are represented and their principal cities are labelled on the map.

The latest brief supersedes the original all-municipality research commission. Read `docs/USER-EDITORIAL-BRIEF.md` and `docs/READER-AUDIT.md`. The historical geographical inventory and research are preserved; they are no longer the public catalog or completion target.

## Build and check

Requires Python 3.13+, Node 22+ and pnpm 11.

```sh
pnpm install --frozen-lockfile
pnpm build
pnpm test
python3 scripts/preview.py
SSL_CERT_FILE=/etc/ssl/cert.pem python3 scripts/audit_reader_edition.py --require-public
SSL_CERT_FILE=/etc/ssl/cert.pem python3 scripts/check_reader_links.py
```

The certificate setting is for the current macOS Python trust store; omit on systems with a configured trust store. Do not disable TLS verification. Preview at http://127.0.0.1:4173/european-urban-atlas/. The public site runs independently of this preview.

## Maintained content and code

- `public/data/editorial/{spain,france,italy}.json`: canonical current country, regional and city content. Edit these, not the generated site or old editorial JSON.
- Each city carries a short summary, nine sections, seven score/description pairs, source records, geography and dated population where available. Scores are editorial judgments from 1 to 5; there is no overall ranking.
- `scripts/build.py`: shared country-independent city publication templates, compact browser data, route generation and metadata. Every city article is pre-rendered.
- `src/app.ts`: country/city menus, accent/alias search, filters, comparisons and MapLibre maps.
- `public/data/maps/`: packaged world and regional geometry. `provenance.json` records publisher, transformation and rights. France mainland regions use NUTS1; overseas regions use NUTS2. Italy combines Trento/Bolzano geometry into the corresponding region.
- `scripts/audit_reader_edition.py`: current content, readability, selection, map-label, source, route, asset and public-origin checks. It also writes a reader-interest audit matrix.
- `docs/READER-AUDIT.*`, `docs/READER-SOURCE-LINKS.json`, `docs/BROWSER-QA-READER.json`: actual audit evidence and limitations.
- `.openai/github-pages.json`: public host/repository identity and project base path. `.github/workflows/pages.yml`: permanent deployment pipeline.

The earlier full municipality database, graph adapters, evidence ledger and validators remain in source control for reuse. `public/data/countries.json` and `scripts/geographic_contract.py` describe that older complete-inventory pipeline; their disabled France/Italy inventory adapters do not describe the current curated editorial publication. The reader edition is driven by its three editorial files and common renderer.

## Publishing and durable storage

Repository: https://github.com/rkeating1119/european-urban-atlas

GitHub Pages serves the site. A push of `atlas-site.zip` to main runs the saved workflow: unpack the verified static build, configure Pages, upload the artifact and deploy it. Pages must use GitHub Actions as its source, which is already configured. No custom domain, paid infrastructure or local tunnel is required.

Create the archive from the contents of `dist/client/`, not from its parent folder. Include `.nojekyll`, CSS, JS chunks, data and all routes. Keep the tested GitHub Pages base path `/european-urban-atlas`. Verify the uploaded archive checksum, successful workflow and public URLs before declaring a release live.

The connected GitHub integration can read the new public repository but has no installed write access to it. Initial repository creation, workflow save, Pages settings and archive upload were completed through the already authenticated browser. Future agents can use that authorized browser flow or an appropriate connected write capability; no new account or paid service is needed. Do not confuse a successful local build with a deployment.

The remote repository also preserves a source archive for continuation. The complete local Git history is maintained in this workspace and exported with the saved project. Keep source and content revisions together when publishing.

## Rights

Preserve GISCO/EuroGeographics attribution and noncommercial geographic-data terms. Photo licences are in `public/data/images.json` and the site credits. Dependency licences are in `docs/licenses/`. No current prices, wages or resident quotations are invented to fill gaps. Population periods remain visible beside counts.
