# Reader edition maintenance

Read the current brief, README and reader audit. The user prefers a fun, readable city atlas, not an exhaustive administrative publication. Keep public prose concrete and short-paragraphed. A quick visitor should understand the city from the summary; a longer reader should find real neighborhoods, economic activities, food, history, culture and practical differences.

Edit public/data/editorial/*.json. Every city needs summary, goodFor/tradeoffs, all nine substantive topic sections, seven ratings with useful explanations, genuine sources, geography and a research/update date. Keep score meanings consistent across countries: higher means more affordable, broader career options, stronger car-free transport, more cultural choice, livelier social options, better outdoor access or milder everyday weather. Scores are not measured rankings and there is no overall score.

Source URLs and dates remain background data; do not insert research-status caveats into every paragraph. Qualify a specific uncertain fact when necessary, and omit an unsupported number. Population years and municipal units must remain correct. Do not fabricate financial figures or resident testimony.

Build with pnpm build. It generates all country, regional and city HTML and checks the current161-city contract. Update the explicit selection counts if the user authorizes an expanded selection. Use the reader-interest matrix to check usefulness, not merely keys. Check sentence length, repeated paragraphs, named details, actual links, base-path assets and map labels. Browser-test changed menus, search, maps, source disclosures and comparisons at desktop, iPad-sized portrait/landscape and phone widths. Say what hardware was actually tested.

Publishing is already authorized. The existing public repository and Pages workflow are recorded in .openai/github-pages.json. Archive the contents of dist/client/ as atlas-site.zip and upload it to the repository main branch. Its path-triggered workflow publishes the static site. Confirm the successful run, checksum and unauthenticated public URLs. A source-only upload does not trigger deployment. Keep a current source archive with the release for future sessions.

The connected integration did not have write access to the new repository, so the initial publication used GitHub’s authenticated web interface. Do not ask the user to engineer the deployment; use available tools. Do not purchase a domain or paid hosting without authorization. Do not replace the permanent URL with a temporary tunnel.

The original full municipal geography remains available for historical/reference uses. Do not resurface its obsolete coverage-status banners, tier labels or population-only comparison experience.

Follow-up requirements: preserve a geographic overview before the ten labelled sections, including architecture and street appearance. Explain named hills, riverbanks, layouts, materials and specific comparisons. Avoid instruction-echo phrases such as “a vague old hill area.” The opening summary needs no repeated heading. Keep custom menus synchronized after programmatic selections, and verify a direct country/region filter URL. Check label spacing at two zoom levels, hover/tap cards and map reset. Permanent labels now cover the ten largest featured municipalities, replacing the earlier regional-priority rule.
