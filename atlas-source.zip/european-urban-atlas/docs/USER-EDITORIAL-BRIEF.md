# Reader edition: instructions accepted 7 November 2026

The latest user direction supersedes the original exhaustive-country commission. Publish a fun, readable city atlas for exploration: about50–100 important cities and major suburbs per country, Spain/France/Italy in one site, meaningful short summaries and optional longer reading, concrete everyday detail and normal prose.

All city pages cover character/history/work/housing/neighborhoods/culture/food/transport/climate. Remove methodology, research-coverage and arbitrary qualifier text from the main reading flow. Keep real sources unobtrusively available.

Use short comparative descriptions and explained subjective category scores, not population-only comparisons. Ratings are now explicitly authorized; the previous prohibition on scoring is superseded. Make all regional main cities visible on the map without requiring region selection. Country dropdown navigation is required.

Public, durable hosting is mandatory. A local tab, preview, tunnel or archive does not meet this instruction. No paid infrastructure or domain purchase was authorized.

Current selection: Spain60,France51,Italy50. The complete old municipal data is preserved for future geographical use; it is no longer the reader-facing catalog or definition of completion.
