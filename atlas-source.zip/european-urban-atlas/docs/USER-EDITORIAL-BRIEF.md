# Reader edition: instructions accepted 7 November 2026

The latest user direction supersedes the original exhaustive-country commission. Publish a fun, readable city atlas for exploration: about 50–100 important cities and major suburbs per country, Spain/France/Italy in one site, meaningful short summaries and optional longer reading, concrete everyday detail and normal prose.

All city pages cover character/history/work/housing/neighborhoods/culture/food/transport/climate. Remove methodology, research-coverage and arbitrary qualifier text from the main reading flow. Keep real sources unobtrusively available.

Use short comparative descriptions and explained subjective category scores, not population-only comparisons. Ratings are now explicitly authorized; the previous prohibition on scoring is superseded. Make all regional main cities visible on the map without requiring region selection. Country dropdown navigation is required.

Public, durable hosting is mandatory. A local tab, preview, tunnel or archive does not meet this instruction. No paid infrastructure or domain purchase was authorized.

Current selection: Spain 60, France 51, Italy 50. The complete old municipal data is preserved for future geographical use; it is no longer the reader-facing catalog or definition of completion.

## Follow-up: maps, geography and architecture

The opening summary needs no “The short version” heading. Follow it with a general two-paragraph city overview before the labelled sections. Expand every article with concrete geography, urban structure, architecture, materials, street scale and visual atmosphere. Explain named hills and districts rather than assuming the reader knows them. Use specific, fair comparisons to other places; avoid blanket statements about an entire city.

Use one geographic point per city, with radius interpolated by zoom. The ten largest featured municipalities in each country receive permanent labels; remaining cities open hover cards and support taps. This updates the earlier always-labelled regional-priority rule. Keep all regions represented in the curated catalog.

Replace system select popups with accessible in-page menus, including country, city, map, browse and compare controls. Enlarge the physical map and provide fullscreen viewing. Publish the finished update to the existing public URL and preserve source and audit records.
