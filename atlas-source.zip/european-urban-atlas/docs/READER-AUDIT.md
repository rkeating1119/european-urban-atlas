# Reader edition audit

This audit checks the revised city-selection, writing and comparison requirements. The previous all-municipality completion target is superseded by the user’s curated city scope.

Result: **PASS** · 0 material errors · 5 review notes.

Mode: final selection. Built site checked: yes. Generated 2026-11-08T02:50:04.722142+00:00.

## What a reader may look for

The matrix checks actual summaries, named categories or text signals. A mention is not a guarantee of suitability. Family/student/language topics vary by place rather than being filled with invented advice.

| Reader interest | Spain | France | Italy |
|---|---|---|---|
| Quick impression | 60/60 | 51/51 | 50/50 |
| Geography and city layout | 60/60 | 51/51 | 50/50 |
| Architecture and visual character | 60/60 | 51/51 | 50/50 |
| What neighborhoods are like | 60/60 | 51/51 | 50/50 |
| Housing and cost tradeoffs | 60/60 | 51/51 | 50/50 |
| Work and careers | 60/60 | 51/51 | 50/50 |
| Culture and things to do | 60/60 | 51/51 | 50/50 |
| Local food | 60/60 | 51/51 | 50/50 |
| Important history | 60/60 | 51/51 | 50/50 |
| Getting around | 60/60 | 51/51 | 50/50 |
| Weather through the year | 60/60 | 51/51 | 50/50 |
| Nature and outdoor time | 60/60 | 51/51 | 50/50 |
| Student and university life | 32/60 | 35/51 | 42/50 |
| Families, schools and children | 6/60 | 5/51 | 13/50 |
| Nightlife and social opportunities | 52/60 | 50/51 | 44/50 |
| Language and settling in | 11/60 | 18/51 | 17/50 |
| Major suburbs and satellite cities | 4/60 | 3/51 | 1/50 |
| Clear compromises | 60/60 | 51/51 | 50/50 |

## Previous edition review

The first edition overemphasized administrative completeness and audit language. Its abstract thesis statements did not give readers a useful quick impression, and its short notes did not cover the practical categories consistently. The revised checks specifically address those defects.

- The public selection is curated cities and major suburbs; the exhaustive municipality catalog is no longer the browsing experience.
- A concise plain-language summary appears before the detailed reading sections.
- Each city has a geographic overview plus sections on character, architecture, history, work, housing, actual neighborhoods, culture, food, transport and climate.
- Sources and score explanations remain accessible in collapsed disclosures, without evidence classifications interrupting the prose.
- Comparison uses the real city summaries plus seven explained category ratings and clear compromises.
- In-page country selection and top-ten city labels are tested explicitly; deployment requires separate public access verification.

## Writing and selection

| Country | Cities | Regions | Section words | Mean sentence length |
|---|---:|---:|---:|---:|
| ES | 60 | 19 | 30,252 | 16.7 words |
| FR | 51 | 18 | 39,575 | 16.6 words |
| IT | 50 | 20 | 40,394 | 17.1 words |

Exact duplicate reading paragraphs: 0. Similar paragraph pairs flagged: 0.

The content checks require ten real sections, a general overview, a short top summary, named neighborhood signals, actual food discussion, seven explained category scores, sources and clear compromises. Unknown financial or population values are allowed to remain unknown.

## Navigation, maps and comparison

- All built HTML links/assets/anchors, redirects, stylesheet url() imports and JavaScript chunks resolve under the configured GitHub Pages base path.
- Every regional boundary and featured city point is packaged. Exactly the ten largest featured municipalities per country carry permanent labels; others open hover/tap cards. Zoom scaling and marker anchoring require separate browser checks.
- Client data and source inspected for short summaries, seven scored-and-explained categories and compromises; live behavior remains a separate browser check.
- Seven explained 1–5 editorial categories; no arbitrary overall score, missing price or salary figures are not fabricated.

HTML pages: 291. Internal targets: 8205. Section fragments: 2498. Hosting base path: `/european-urban-atlas`.

Country dropdowns, direct city routes, source disclosure controls and image alternatives are checked in the built documents. Browser gestures, layout, keyboard use and the live comparison still require the separate browser audit.

## Material findings

No material structural/content defects were found by this run.

## Review notes

- **city-outside-region**: Map point lies outside its stated regional polygon — spain/city/a-coruna
- **city-outside-region**: Map point lies outside its stated regional polygon — spain/city/ceuta
- **city-outside-region**: Map point lies outside its stated regional polygon — spain/city/melilla
- **city-outside-region**: Map point lies outside its stated regional polygon — france/city/ajaccio
- **population-not-published**: 1 cities omit unknown population rather than inventing it — france

## Public access

Public URL: https://rkeating1119.github.io/european-urban-atlas/. Checked: True. All sampled routes passed: True.

A successful static audit is not evidence of public publication. Use `--require-public` after deploying, and open the actual production URL in an ordinary browser.

## Limits

This is a content and implementation audit, not a statistical certification of subjective ratings or a claim that every linked source was available. It does not invent prices, salaries, quotations, resident opinions or current construction status. Source HTTP checks and substantive fact review remain separate. The complete JSON report contains per-city section lengths, named-detail signals and every finding.
