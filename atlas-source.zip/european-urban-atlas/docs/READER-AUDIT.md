# Reader edition audit

This audit checks the revised city-selection, writing and comparison requirements. The previous all-municipality completion target is superseded by the user’s curated city scope.

Result: **PASS** · 0 material errors · 2 review notes.

Mode: final selection. Built site checked: yes. Generated 2026-11-08T02:03:54.471473+00:00.

## What a reader may look for

The matrix checks actual summaries, named categories or text signals. A mention is not a guarantee of suitability. Family/student/language topics vary by place rather than being filled with invented advice.

| Reader interest | Spain | France | Italy |
|---|---|---|---|
| Quick impression | 60/60 | 51/51 | 50/50 |
| What neighborhoods are like | 60/60 | 51/51 | 50/50 |
| Housing and cost tradeoffs | 60/60 | 51/51 | 50/50 |
| Work and careers | 60/60 | 51/51 | 50/50 |
| Culture and things to do | 60/60 | 51/51 | 50/50 |
| Local food | 60/60 | 51/51 | 50/50 |
| Important history | 60/60 | 51/51 | 50/50 |
| Getting around | 60/60 | 51/51 | 50/50 |
| Weather through the year | 60/60 | 51/51 | 50/50 |
| Nature and outdoor time | 60/60 | 51/51 | 50/50 |
| Student and university life | 30/60 | 34/51 | 41/50 |
| Families, schools and children | 5/60 | 4/51 | 12/50 |
| Nightlife and social opportunities | 52/60 | 50/51 | 43/50 |
| Language and settling in | 9/60 | 15/51 | 12/50 |
| Major suburbs and satellite cities | 4/60 | 3/51 | 1/50 |
| Clear compromises | 60/60 | 51/51 | 50/50 |

## Previous edition review

The first edition overemphasized administrative completeness and audit language. Its abstract thesis statements did not give readers a useful quick impression, and its short notes did not cover the practical categories consistently. The revised checks specifically address those defects.

- The public selection is curated cities and major suburbs; the exhaustive municipality catalog is no longer the browsing experience.
- A concise plain-language summary appears before the detailed reading sections.
- Each city describes character, history, work, housing, actual neighborhoods, culture, food, transport and climate.
- Sources and score explanations remain accessible in collapsed disclosures, without evidence classifications interrupting the prose.
- Comparison uses the real city summaries plus seven explained category ratings and clear compromises.
- Country selection and regional city labels are tested explicitly; deployment requires separate public access verification.

## Writing and selection

| Country | Cities | Regions | Section words | Mean sentence length |
|---|---:|---:|---:|---:|
| ES | 60 | 19 | 20,094 | 15.1 words |
| FR | 51 | 18 | 29,262 | 16.0 words |
| IT | 50 | 20 | 30,455 | 16.2 words |

Exact duplicate reading paragraphs: 0. Similar paragraph pairs flagged: 0.

The content checks require nine real sections, a short top summary, named neighborhood signals, actual food discussion, seven explained category scores, sources and clear compromises. Unknown financial or population values are allowed to remain unknown.

## Navigation, maps and comparison

- All built HTML links/assets/anchors, redirects, stylesheet url() imports and JavaScript chunks resolve under the configured GitHub Pages base path.
- Every regional boundary is packaged; every region has a map-priority city; the largest known-population featured city is included. Regions with unknown populations need an explicit editorial largest-city check.
- Client data and source inspected for short summaries, seven scored-and-explained categories and compromises; live behavior remains a separate browser check.
- Seven explained1–5editorial categories; no arbitrary overall score, missing price or salary figures are not fabricated.

HTML pages: 291. Internal targets: 7984. Section fragments: 2277. Hosting base path: `/european-urban-atlas`.

Country dropdowns, direct city routes, source disclosure controls and image alternatives are checked in the built documents. Browser gestures, layout, keyboard use and the live comparison still require the separate browser audit.

## Material findings

No material structural/content defects were found by this run.

## Review notes

- **city-outside-region**: Map point lies outside its stated regional polygon — france/city/ajaccio
- **population-not-published**: 1 cities omit unknown population rather than inventing it — france

## Public access

{"url": "https://rkeating1119.github.io/european-urban-atlas/", "checked": true, "live": true, "samples": [{"url": "https://rkeating1119.github.io/european-urban-atlas/", "kind": "html", "passed": true, "httpStatus": 200, "finalURL": "https://rkeating1119.github.io/european-urban-atlas/"}, {"url": "https://rkeating1119.github.io/european-urban-atlas/spain/", "kind": "html", "passed": true, "httpStatus": 200, "finalURL": "https://rkeating1119.github.io/european-urban-atlas/spain/"}, {"url": "https://rkeating1119.github.io/european-urban-atlas/france/", "kind": "html", "passed": true, "httpStatus": 200, "finalURL": "https://rkeating1119.github.io/european-urban-atlas/france/"}, {"url": "https://rkeating1119.github.io/european-urban-atlas/italy/", "kind": "html", "passed": true, "httpStatus": 200, "finalURL": "https://rkeating1119.github.io/european-urban-atlas/italy/"}, {"url": "https://rkeating1119.github.io/european-urban-atlas/spain/cities/madrid/", "kind": "html", "passed": true, "httpStatus": 200, "finalURL": "https://rkeating1119.github.io/european-urban-atlas/spain/cities/madrid/"}, {"url": "https://rkeating1119.github.io/european-urban-atlas/france/cities/paris/", "kind": "html", "passed": true, "httpStatus": 200, "finalURL": "https://rkeating1119.github.io/european-urban-atlas/france/cities/paris/"}, {"url": "https://rkeating1119.github.io/european-urban-atlas/italy/cities/rome/", "kind": "html", "passed": true, "httpStatus": 200, "finalURL": "https://rkeating1119.github.io/european-urban-atlas/italy/cities/rome/"}, {"url": "https://rkeating1119.github.io/european-urban-atlas/assets/app.js", "kind": "javascript", "passed": true, "httpStatus": 200, "finalURL": "https://rkeating1119.github.io/european-urban-atlas/assets/app.js"}, {"url": "https://rkeating1119.github.io/european-urban-atlas/assets/style.css", "kind": "css", "passed": true, "httpStatus": 200, "finalURL": "https://rkeating1119.github.io/european-urban-atlas/assets/style.css"}, {"url": "https://rkeating1119.github.io/european-urban-atlas/assets/maplibre-gl.css", "kind": "css", "passed": true, "httpStatus": 200, "finalURL": "https://rkeating1119.github.io/european-urban-atlas/assets/maplibre-gl.css"}, {"url": "https://rkeating1119.github.io/european-urban-atlas/data/atlas.json", "kind": "json", "passed": true, "httpStatus": 200, "finalURL": "https://rkeating1119.github.io/european-urban-atlas/data/atlas.json"}]}

A successful static audit is not evidence of public publication. Use `--require-public` after deploying, and open the actual production URL in an ordinary browser.

## Limits

This is a content and implementation audit, not a statistical certification of subjective ratings or a claim that every linked source was available. It does not invent prices, salaries, quotations, resident opinions or current construction status. Source HTTP checks and substantive fact review remain separate. The complete JSON report contains per-city section lengths, named-detail signals and every finding.
