# Initial artifact audit

The commission referred to `/mnt/data/european-urban-atlas-prototype-0.2.zip` and `/mnt/data/Madrid-initial-evidence-dossier.md`. Neither path exists in this attached macOS environment. A filename search of the available attachments and workspace found no copies. The only supplied attachment was the full project commission, preserved as `docs/COMMISSION.txt`.

No earlier prototype code or Madrid claims were discarded or accepted as verified. The present implementation and evidence collections were built from independently obtained official data and research sources. If the original artifacts later become available, audit their actual contents and preserve useful work without overwriting the verified identifier/provenance conventions.
