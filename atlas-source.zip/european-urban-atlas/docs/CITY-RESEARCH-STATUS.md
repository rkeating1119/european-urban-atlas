# City research state — 7 November 2026

The content collections contain **52 named city records**: 12 longer research foundations and 40 shorter urban notes. All 52 correspond to verified municipality, province and autonomous-community identifiers in the geography inventory. This is **not** a certification of completed Spanish urban research.

The longer entries individually address the commission’s A–N themes, with 14 sections and approximately 930–965 words each. The notes contain approximately 160–176 words and are intentionally labeled **Urban note · shorter research coverage**. They are not substantial secondary-city dossiers. Directory coverage, urban notes and deeper profiles must remain distinguishable in the interface and completion reporting.

The structured outputs are `public/data/cities.json`, `sources-cities.json`, and `claims-cities.json`. Sources record publisher, title, direct URL, access date, known publication date, reference period, scope, extracted findings, verification method and limitations. Unknown exact dates remain null. For the Barcelona pedestrianization paper, the publication date is the verified online date, 1 April 2025, with DOI `10.1016/j.trd.2025.104718`.

Two housing values are published: 2022 mean expenditure on principal-home rent in Madrid and Barcelona municipalities from INE’s 2024 Urban Indicators release. They are historical tax-derived occupied-home expenditures, not 2026 asking rents, new-contract rents, per-square-metre prices or wages. The first INE rental publication’s common-tax-regime scope cannot be treated as a Bilbao series.

Important infrastructure statuses are preserved: the Donostia central Topo opening reported for 21 November 2026 is after the research date; Granada’s March 2026 extension tests are not a passenger opening; Sevilla Line 3 North works and South studies are separate stages; Jaén’s October 2026 traffic preparations do not establish tram operation.

## Material limitations

- Most city entries need more primary statistical extraction, current wage and housing series, local journalism, academic research and directly attributed resident material. No arbitrary livability scores are assigned.
- Some official statistical portals were read at catalogue level. No numerical value is inferred from the existence of a dashboard.
- Three major-entry cultural references had incomplete direct access and use only indexed institutional remit or facility lists: Sevilla ICAS, Azkuna Zentroa and the Ministry of Culture’s Luis Seoane directory. Their verification fields explicitly distinguish this from full direct access.
- The official Alicante university campus PDF opens without extracted text. Its official title and indexed map description establish location in San Vicente del Raspeig; no claim of visual inspection is made.
- Toledo’s full action-plan PDF exceeded the web-reader size limit. Only the indexed diagnostic passage is used, with no current numerical or legal-status inference. Avilés port-history access was intermittent. Both shorter notes record this limitation.
- Granada’s full 2024 urban agenda was not incorporated because the web reader rejected its size. The separate participation-process page was read and used within its narrower scope.
- There are 100 city source records, not 100 independently evaluated socioeconomic studies. Institutional programme descriptions and planning records are classified accordingly.
- All provincial capitals and distinctive smaller towns are **not** yet given substantive editorial dossiers. A complete municipality directory does not close that gap.

## Rebuilding these collections

Run `build_city_profiles.py`, then `add_secondary_profiles.py`, both in this directory. Paths are resolved relative to the scripts, so the working directory is immaterial. Running only the first script regenerates the initial 12 records. The second script idempotently adds the 40 named secondary notes and their source and evidence records.

Future country and city expansion should use the validated geographic inventory, retain stable municipality identifiers and record many-to-many functional relationships independently from administrative parents. Source-access failures are research limitations to resolve, not grounds for inventing facts or marking completion.
