# Local foundation release · 7 November 2026

**Public URL: none. Spain’s research commission is not complete.**

The integrated atlas is available locally at http://localhost:4173/ while the preview server runs. The source, built site, official reference snapshots, research database, tests and continuation documentation are preserved together. A local preview, export or screenshot is not presented as the required public deployment.

## Delivered locally

- Complete dated geographic inventory: 8,132 official municipalities, 17 autonomous communities, 2 autonomous cities, 50 provinces. All municipality IDs and official names match the INE 2026 reference extraction.
- Official Padrón population for all municipalities at 1 January 2025; separate definitions and reference dates. All coordinates lie within their packaged municipal polygons.
- Nineteen regional syntheses; twelve longer city foundations and forty clearly labelled shorter urban notes. These are not certified as completed dossiers.
- 137 annotated editorial sources, 216 evidence records and 72 profile-update records.
- Locally packaged essential maps; country, regional, provincial, municipality, island-institution and 68 FUA pages. FUA municipal associations remain explicitly exploratory and must not be aggregated as an official roster.
- Search, alternate/accent-free names, geographic and research-depth filters, population comparisons, direct URLs, list navigation and source/evidence pages.
- Configurable country graph and generic publication engine. Synthetic France/Italy adapter tests pass. Neither country’s real research has been imported or published.

## Validation results

Production build and TypeScript checks passed. Static validation reports zero errors and four disclosed scope/data warnings. It checked 8,294 HTML files, 299,767 internal targets and 9,561 fragment links. Every official municipality has a direct route.

Official-code/name/region and population equality checks passed against independent preserved INE reference extractions. Municipal point-in-polygon checks, geometry/ring checks, administrative cross-links and population totals passed. The normalized country graph has 8,284 reference entities and 18,491 relationships. Four autonomous-city reference records represent the same two authorities through explicit equivalence links, not four autonomous cities.

Both JSON Schemas passed independent Draft 2020-12 validation. Geographic adapter regression tests preserve French alphanumeric IDs, Italian leading zeroes, variable source columns and overlapping relationships. Generic renderer tests cover transitive administrative/statistical parents, exclusion of FUA links from administrative ancestry, ambiguous/cyclic ancestry rejection, configurable routes/labels, escaped content and generated geometry. Asset-worker tests passed direct routing, actual 404 status, missing assets, method handling and response headers.

The final external audit requested all 160 unique URLs. Of these, 131 were accessible, 20 had inconclusive network errors, 7 were access-blocked and 2 returned transient/server errors. None returned a confirmed missing-page result in the final run. This is not a claim that every source was readable or substantively verified. Earlier stale INE/MACA links were replaced; intermittent museum access is recorded in the source metadata. See `docs/EXTERNAL-LINKS.json` and the sampled `docs/RESEARCH-AUDIT.md`.

## Browser checks

Tested the local site in the Codex in-app Chromium browser at desktop 1440×1000 (and 1440×1200), iPad-sized portrait 768×1024, iPad-sized landscape 1024×768 and phone 390×844. None of the sampled pages had horizontal overflow. The 768-pixel profile prose column measured about 707 pixels; the phone column about 359 pixels. Primary mobile navigation targets were 44 pixels high; search was 46 pixels high.

Verified map rendering, country/region navigation, regional selection, alternate-name search, accent-free Cádiz search, Canary-region filtering, twelve-profile/forty-note filters, combined Benidorm filtering, municipal comparisons using official names and aliases, source navigation, direct city/FUA pages and loaded imagery. A duplicated neighborhood anchor, premature region-selection handling, alias comparison and future-country reset/inset/routing defects were corrected. Captured error logs for the tested FUA page were empty.

No actual iPad hardware, Safari, physical pinch gestures, full screen reader/WCAG conformance test, Lighthouse/Core Web Vitals certification or public production test was performed. MapLibre supplies touch gesture support; this is not a substitute for hardware testing. See `docs/BROWSER-QA.json` and `docs/screenshots/`.

The small interactive entry script is about 14.7 KB uncompressed (5.8 KB gzip); the separately loaded map module about 1.04 MB uncompressed (281 KB gzip). All substantive text is pre-rendered. These are asset-size observations, not performance certification.

## Publication outcome

The Sites creation attempt returned **“Sites is not yet enabled for this workspace.”** No project was created and no hosting identity was persisted. The available-plugin lookup reported Vercel disabled by the workspace administrator. GitHub was offered as a possible alternative but remained unconnected at handoff. No public site, remote source repository, recurring charge or domain purchase was created.

The build has no public canonical origin. Once hosting access exists, publish from the preserved source, set the origin, build/validate the exact release, deploy, set the commissioned public audience, and verify ordinary unauthenticated access and direct URLs. Publishing is already authorized by the commission; the remaining service access is the blocker.

## Remaining editorial work

Deepen the major-city foundations, substantially expand the short secondary-city notes, select and research additional provincial capitals/metropolitan municipalities/distinctive smaller settlements, broaden regional evidence, build comparable current housing/labour series, gather properly contextualized resident perspectives, and make the evidence ledger fully atomic where needed. Photograph licensing and source access should continue to be checked.

The website explicitly labels its research depth and says Spain remains incomplete. The complete directory is not used as a substitute for national editorial completion. `PROJECT-STATUS.md` contains specific continuation work; `MAINTENANCE.md` and `docs/COUNTRY-EXPANSION.md` preserve the operating process without reliance on chat memory.
