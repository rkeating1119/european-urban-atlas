# Geographic foundation

Imported and verified 7 November 2026. The directory contains all **8,132** Spanish municipal codes in INE’s inventory at **1 January 2026**. Administrative geometries are the independently dated **GISCO 2024** snapshot. Exact set equality of municipal identifiers is checked; matching identifiers does not certify that every boundary was unchanged between those dates.

The population attached to each municipality is the official **Padrón municipal at 1 January 2025**, total sexes, in persons. It is not a census population, metropolitan population, or estimate for 2026. The **49,114,494** national sum is validated during import. All 8,132 values are populated. GISCO’s `POP_2024` field is zero for every Spanish record in the downloaded file: those missing-data sentinels are deliberately discarded and replaced with the separately sourced INE series.

## Sources and reproducibility

Run `python3 scripts/import-geography.py` from the repository. Only Python’s standard library and curl are required; the command fetches the actual official sources, caches large downloads in the ignored `work/data-downloads/` directory and preserves independent official reference extractions in `reference/official/`, builds the geographic directory, then builds island and FUA relationships. It fails for missing codes, incompatible population coverage, unexpected national population sum, invalid island counts, or absent source fields. Keep cached source files for an independent provenance audit. To update years, edit explicit filenames/reference periods and reverify validation totals rather than silently changing metadata.

Official sources:

- [INE municipal names and codes, 2026](https://www.ine.es/daco/daco42/codmun/diccionario26.xlsx): 8,132 rows, stable province-plus-municipality code, community affiliation and official names. Current names replace GISCO’s earlier labels; alternate and former labels are retained for search.
- [INE official municipal populations, table 29005](https://www.ine.es/jaxiT3/Tabla.htm?t=29005): municipal Padrón population, total sexes, reference date 1 January 2025; the input records retain the series code for each municipality.
- [GISCO LAU 2024](https://gisco-services.ec.europa.eu/distribution/v2/lau/lau-2024-files.html): municipal polygons, 1:1 million, EPSG:4326. Source hashes are in `provenance.json`.
- [GISCO NUTS 2024](https://gisco-services.ec.europa.eu/distribution/v2/nuts/nuts-2024-files.html): country and regional geometries, 1:3 million. Explicit NUTS-to-province crosswalk preserves insular differences.
- [GISCO Urban Audit 2024](https://gisco-services.ec.europa.eu/distribution/v2/urau/urau-2024-files.html): **68 Spanish functional urban area polygons**, 1:100,000. This is a specified 2024 statistical definition, not a declaration that Spain has only 68 real urban systems.
- [GISCO Countries 2024](https://gisco-services.ec.europa.eu/distribution/v2/countries/): world country geometry, 1:20 million, packaged as an optional map base.
- [Balearic government: institutions](https://www.illesbalears.cat/sites/processoselectorals/ca/institucions-64178/): four island councils.
- [Canary government: Law 3/2026 on island cabildos](https://www.gobiernodecanarias.org/boc/2026/129/2242.html): island governance; the shared Lanzarote and La Graciosa institution is represented explicitly. The historical geography source is independently dated from this governance update.

## Files and meanings

All public data live in `public/data/geography/`.

| File | Purpose |
|---|---|
| `municipalities.json` | Complete searchable directory with official code, names/aliases, province/community, population/year, source series, map point, computed FUA links and insular administrative link where relevant. |
| `regions.json` | 19 first-level entities: **17 autonomous communities + Ceuta and Melilla, whose type is `autonomous-city`**. |
| `provinces.json` | 52 second-level geographic references: **50 provinces + two autonomous cities**. Filter `type === 'province'` when counting provinces. Ceuta and Melilla are never classified as provinces. Their presence at both navigation levels represents Spain’s statistical correspondence rather than inventing another authority. |
| `regions.geojson` | All 19 NUTS2/first-level Spanish polygons with `regionId` / `id` crosswalk. |
| `provinces.geojson` | MultiPolygons assembled from the explicit NUTS3 crosswalk to all 50 provinces plus autonomous cities. Several island NUTS3 units combine into one provincial geometry. |
| `nuts3.geojson` | Original Spanish NUTS3 statistical units, retained without pretending each one is a province. |
| `municipalities-NN.geojson` | All municipal polygons in a provincial-level entity; load on demand rather than shipping a national polygon bundle on every page. |
| `spain.geojson` | Spain’s country polygon including Canaries and autonomous cities. |
| `europe.geojson` | NUTS0 country polygons for the statistical atlas’s wider regional map; coverage is the NUTS area, not every country in geographical Europe. |
| `countries.geojson` | Optional complete world country map base from GISCO Countries 2024. Country properties use `CNTR_ID`, unlike NUTS geography’s `CNTR_CODE` / `NUTS_ID`. |
| `functional-urban-areas.geojson` | All 68 Spanish GISCO 2024 FUA boundaries; FUA code/name available as `id` / `name` as well as original source properties. |
| `functional-urban-areas.json` | FUA records and **computed exploratory municipal relationships**. |
| `islands.json` | Four Balearic council areas, seven Canary cabildo areas, plus the island of La Graciosa and its shared-governance relationship. |
| `provenance.json` | Publishers, exact download URLs, coordinate system, scales, periods, hashes, reuse conditions and limitations. |

## IDs and relationships

Municipal `id` is the five-character official code, including leading zeroes: for example `01001`, never an integer. `provinceId` is its first two digits. `regionId` is INE’s two-character autonomous-community/autonomous-city code. Each record also has `countryId: 'ES'`; these IDs are national namespaces and must be combined with country when stored across Europe. Names do not determine IDs or routes.

The administrative hierarchy coexists with island administrations and statistical functional urban geography. It is not a single flattened tree. Municipal population is never attributed to a FUA as though the units were interchangeable.

FUA memberships are computed by testing a municipality’s representative point in official FUA polygons: **1,997 municipal points match at least one FUA**. The method is explicitly identified in the records. It is not an official LAU–FUA correspondence and must not be used for aggregating metropolitan statistics without validating a direct official roster. Generalized geometry, enclaves, and temporal alignment can affect this exploratory join. A municipality without a computed FUA link can still have strong urban/metropolitan relationships.

Island assignments are computed against NUTS3 island geography with the separate Formentera municipality handled explicitly and all island municipal counts checked: Mallorca 53, Menorca 8, Eivissa 5, Formentera 1; Gran Canaria 21, Fuerteventura 6, Lanzarote/La Graciosa 7, Tenerife 31, La Palma 14, La Gomera 6, El Hierro 3. La Graciosa lies in Teguise municipality (`35024`) and shares the Lanzarote and La Graciosa cabildo. It is not a ninth cabildo or a separate municipality. Small uninhabited islands are not separate municipal records.

## Coordinate meaning

`lat` / `lon` is a **representative point of the largest municipal polygon**, not the town hall, the built-up centre, a neighborhood, or a claim about where residents live. A polygon centroid is used if inside the polygon; otherwise a deterministic interior grid point nearest that centroid is selected. Use this to locate the municipality at national map scale. On detailed maps, show the municipal polygon and obtain an authoritative settlement centroid before giving directions or doing accessibility analysis.

## Reuse and cartographic limitations

GISCO’s applicable [specific reuse conditions](https://ec.europa.eu/eurostat/web/gisco/geodata/statistical-units) permit this personal, noncommercial publication with acknowledgment. The map legend **and introductory page** must display:

> © EuroGeographics for the administrative boundaries

Do not relabel this dataset as unrestricted commercial open data. Every geometry is packaged locally; essential geography does not depend on live map-feature services. Geometry is generalized for its published scale and is unsuitable for cadastral or jurisdictional decisions. Province MultiPolygons preserve island constituent geometries; source geometry does not provide a single dissolved province edge for every island system. Country borders reflect the cited source’s cartographic representation and reference period.

## Release limitations

The national geographic directory is complete against INE’s 2026 municipal code inventory. That is **not** completion of the editorial Spanish atlas. Tier 4 entries remain directory records until their research is expanded. The directory contains municipal boundaries, not every hamlet or settlement nucleus in the INE Nomenclátor. Neighborhood, cultural-region and legal metropolitan-authority boundaries require separate sourced datasets and must not be invented from municipal proximity.
