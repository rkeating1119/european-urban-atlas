# National adapter template

These files are templates for the next country import, outside published atlas content. They are not researched place records. Replace all `SOURCE_NAME`, `*_CODE_STRING`, `REPLACE_WITH_*` and example values with an actual primary-source acquisition before enabling the country.

`country-config.template.json` is a disabled France configuration with three mapped source collections. The complete model supports additional collections and namespaces for EPCI, métropoles, arrondissements, islands, cultural areas and other exceptions. The rows in `regions.template.json`, `divisions.template.json` and `municipalities.template.json` demonstrate the accepted source layout, while the mapping can be changed to match actual national columns.

1. Acquire real geography in a work area; preserve native identifiers as strings.
2. Save complete source arrays under the country’s chosen public data paths, such as `/data/countries/fr/municipalities.json`.
3. Map columns through the configuration. Add coordinates, geometry and population mappings only after their definitions and periods are known.
4. Replace source placeholders with actual source records. Add relationship mappings from `relationships.template.json` to the shared manifest, including country-specific exceptions.
5. Set `datasets` to actual existing paths and update expected official inventory counts. Only then enable the country and run the shared validation CLI.

The generic normalized output is defined in `public/data/geographic-entities.schema.json`; country/collection settings are defined in `public/data/country-config.schema.json`. See `docs/COUNTRY-EXPANSION.md` for the full acquisition, research, verification and publication process. Do not generate French pages from these example rows.
