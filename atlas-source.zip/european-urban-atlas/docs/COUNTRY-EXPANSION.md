# Country expansion contract

The atlas uses a country registry, national source adapters and a country-independent geographic graph. These are executable components, not a promise to design another model later.

- `public/data/countries.json` registers each country’s route, geographic terminology, source collections, exceptions, validation counts and adapter mappings.
- `public/data/country-config.schema.json` is the JSON Schema for registry entries and national collection mappings.
- `public/data/geographic-entities.schema.json` is the JSON Schema for normalized entities, statistics, geometry references and relationships.
- `public/data/relationships.json` describes compact relationship mappings. It references existing source fields instead of duplicating 8,132 municipal records into another hand-maintained directory.
- `scripts/geographic_contract.py` loads any enabled country, maps its native columns into the common graph and rejects broken references, duplicate identifiers, administrative cycles, invalid coordinates/statistics, missing configured parents and unexpected coverage counts.
- `docs/country-adapter-template/` contains exact accepted configuration and source-row shapes for the next import. Templates are outside public atlas content and are not published as researched places.

Spain’s geographic inventory is loaded. French and Italian geography are **configured, disabled and not imported**. Their configuration does not claim country research, municipal coverage, publication or editorial completion. Spain remains `in-progress` because geography completeness and editorial completeness are separate decisions.

## Loading and validation

From the repository root:

```sh
python3 scripts/geographic_contract.py --check-config
python3 scripts/geographic_contract.py --country ES --validate --summary
python3 scripts/test_geographic_contract.py
```

For a normalized graph export, specify a destination such as:

```sh
python3 scripts/geographic_contract.py --country ES --validate --output work/es-geographic-graph.json
```

The source record layout is not tied to Python column names. The adapter explicitly maps a country’s `idField`, `nameField`, optional alternate names, entity classification, coordinate fields, population fields and geometry identifiers. For example, France can retain an alphanumeric COG identifier while Italy can retain a zero-padded six-character comune code. The generic loader does not look for `provinceId` or impose Spain’s hierarchy; those are Spanish mapping settings in the registry.

A renderer can import `load_country(country_id)` and consume:

```text
{
  country: <selected registry entry>,
  collections: <country source arrays keyed by adapter collection key>,
  graph: {schemaVersion, countryId, entities, relationships}
}
```

`datasets` stores active public paths. `sources` and `evidence` may each be arrays of paths because the research database is split into independently maintained regional and city collections. A disabled country has no active inventory paths. All enabled dataset paths must resolve to real local files beneath `public/data/`.

## Stable geographic identities

The canonical ID is `COUNTRY:namespace:nativeId`. `nativeId` is always a string. Namespace names are adapter settings, not a fixed global assumption that every country has provinces. Examples:

```text
ES:municipality:01001
FR:commune:2A001   (identifier example, not a claim of imported French coverage)
IT:comune:001001   (identifier example, not a claim of imported Italian coverage)
```

Preserve the actual national identifier scheme separately in `nativeIdentifiers`. Do not derive identity from a display name, translate codes, strip leading zeroes, cast Corsican identifiers to integers, or discard historical identifiers after a reorganization. New legal units require dated crosswalks; a renamed municipality should keep its stable link and retain previous names for search.

An entity can have administrative parents, island governance, FUA links, cultural associations and overlapping urban authorities at the same time. Only `administrative-parent` edges are checked as an acyclic hierarchy. FUA membership, institutional competence and cultural geography are not collapsed into that hierarchy.

Ceuta and Melilla illustrate why record namespaces matter. There are two first-level records and two provincial-level statistical/navigation references for the **same two autonomous cities**. The graph links each pair with `same-geographic-entity`. Four reference records do not mean four autonomous-city authorities. Neither city is called a province or an autonomous community.

## Geographic and statistical precision

Each statistic names its exact geographic entity, reference date, definition, units, source IDs and aggregation treatment. A municipal figure must not acquire the name of a commuting region merely because both appear on a city page. Registry adapters can map different national population definitions; the generic entity contract does not assume that all population series are Padrón figures.

Geometries reference locally packaged GeoJSON, source feature identifier, CRS and boundary period. Dates are separate: an administrative inventory, boundary file, population measure, source publication and editorial revision can refer to different years. Do not overwrite them with the date the website was rebuilt.

Relationship evidence is explicit:

| Evidence type | Permitted meaning |
|---|---|
| `official-correspondence` | An actual code or parent relationship from the cited official source. |
| `documented-administrative` | A geographic/institutional relationship documented by the cited institution. |
| `derived-spatial` | A computed geometry relationship, accompanied by the exact method and limitations. |
| `editorial-association` | A researched interpretive relationship; it is not an administrative boundary or measured commuting membership. |

Spain’s FUA links use the third category. They are representative-point tests against official 2024 FUA polygons, **not** an official membership roster and **not** permission to sum metropolitan statistics from those links.

## France adapter requirements

The configuration expects **18 regional statistical territories**, including **13 in metropolitan France and five overseas regions**: Guadeloupe, Martinique, Guyane, La Réunion and Mayotte. [Insee’s national statistical scope](https://www.insee.fr/fr/metadonnees/definition/c1696) and [overseas definitions](https://www.insee.fr/fr/metadonnees/definition/c2316) are the starting sources; obtain the current Code officiel géographique at import time.

Keep geographic/statistical territories distinct from their legal institutions. Corsica’s special territorial authority is part of the 18-region coverage and is not an ordinary regional council. Single authorities exercising regional and departmental responsibilities must not become duplicate governments. Verify reference-date arrangements, including overseas changes, against the current COG and institutional publications.

The adapter must support departments, communes, departmental arrondissements, the different municipal arrondissements used in relevant cities, EPCI, métropoles and FUAs. Alphanumeric department codes such as `2A` and `2B`, three-character overseas identifiers and five-character commune codes remain strings. Intercommunal geography can cross ordinary administrative divisions. Overseas collectivities and New Caledonia require their own legal/statistical classifications and map extents; do not force all French overseas geography into the five overseas-region records.

No French municipalities or profiles are present merely because these conventions are registered.

## Italy adapter requirements

The configuration expects **20 regions**. It accommodates **five special-statute regions**, the autonomous provinces of **Trento and Bolzano/Bozen**, metropolitan cities and provincial/equivalent territorial units. [ISTAT’s territorial code publication](https://www.istat.it/classificazione/codici-dei-comuni-delle-province-e-delle-regioni/) supplies the dated source inventory; [Article 116 of the Constitution](https://www.senato.it/istituzione/la-costituzione/parte-ii/titolo-v/articolo-116) establishes the special-autonomy distinction.

Do not hard-code an old province total. The current ISTAT classification must determine the import count, legal entity type and effective date. Sardinian provincial/metropolitan restructuring demonstrates why a historical NUTS boundary file and a newer municipal/UTS inventory require an explicit crosswalk. Special arrangements in Valle d’Aosta, Friuli-Venezia Giulia and Sicily must preserve the distinction between statistical territorial units and actual governing institutions. Legal metropolitan cities and statistical functional urban areas are different entities.

Retain six-character comune codes and current provincial/UTS codes as strings. Build a full municipality inventory, rather than treating the twenty regional records as country completion.

## Execution when instructed to add a country

1. Read the selected registry entry, current project status and editorial standards. Reuse this system; do not ask the commissioning editor to repeat the commission or do technical setup.
2. Acquire the current official national inventory, administrative relationships, population series and authoritative boundaries. Record publishers, direct URLs, effective/publication/reference dates, native CRS, licenses, source hashes and limitations. Establish the complete expected municipal code set from the official inventory.
3. Copy the adapter template into a country import work area. Replace every example value with real sourced data. Native source columns can differ: map them explicitly in `adapter.collections` and retain national identifier schemes.
4. Package geometry locally in EPSG:4326 for web use while recording its original source CRS and transformations. Reconcile different administrative vintages. Add official metro/intercommunal crosswalks where available; label exploratory spatial joins separately.
5. Add region, division, municipality and overlapping-entity collections. Set actual dataset paths and expected counts. Append country-specific edge mappings to `relationships.json`; preserve other countries. Add exceptions as explicit entity types and relations rather than unsupported parent shortcuts.
6. Research and write country, regional, urban and smaller-place coverage with the existing source database, claim ledger and profile framework. Every municipality gets a reliable directory record; research tiers label depth and never substitute for geographic coverage.
7. Enable the country only after the real imported inventory exists. Initially retain `status: in-progress` and honest coverage labels. Configuration alone must never create empty public profiles or pretend the country is complete.
8. Run the country contract checks, formal JSON Schema validation, national hierarchy and code-set comparisons, research/source validation, route/build/link checks and responsive map/search testing. Test overseas/island extents and direct profile URLs. Validate equivalent statistical units before enabling comparisons.
9. Publish using the existing site’s deployment process, verify the actual public URL and update source/research dates, status, release notes and maintenance records. Mark `complete-validated` only after the commission’s geographic **and editorial** completion criteria pass.

Adding Portugal or another country follows the same process: register its vocabulary and identifiers, supply new source mappings and data, and run the shared loader and validation. A new national administrative arrangement can be represented through namespace, legal type, metadata and relationship settings without adding a country-specific branch to the graph loader.

## Verification performed

The Spain projection currently validates **8,284 geographic reference records** and **18,491 relationships**. The regression test separately exercises French alphanumeric codes, Italian leading zeroes, different source column names, overlapping FUA links, disabled-country protection and rejection of broken parents/invalid coordinates. Those synthetic fixtures validate the adapter behavior and do not constitute French or Italian data acquisition.

## Generic publication renderer

`scripts/render_country.py` supplies the actual rendering path for future countries. The existing curated Spanish renderer remains in place. The build integrates the generic renderer before writing its sitemap:

```python
from render_country import render_configured_countries
additional = render_configured_countries(OUT, page)
```

`page` is the document-shell callback with `(path, title, body, description='', kind='WebPage')`. The renderer calls it for country, regional, intermediate-division, municipality, directory, sources and evidence routes. Additional island, FUA, institutional or other geographic entity records use `/COUNTRY/geography/NAMESPACE/NATIVE-ID/`. It skips disabled countries and Spain, so a registered French or Italian configuration alone produces no new public pages.

For enabled imports, the renderer consumes the same `sections` / `sourceIds` editorial structure as the existing atlas. It resolves profiles through stable geographic references, checks bibliography references, escapes content, displays native geographic units and source/statistical periods, and labels directory records honestly where editorial research is absent. It never fills missing city profiles with generic invented descriptions. Primary and overlapping geographic relationships remain visible with their evidence class and method.

The renderer writes `/data/runtime/COUNTRY.json` for the shared frontend. Its shape is:

```text
{
  country: <registry configuration>,
  places: [{id, name, aliases, entityId, regionId, divisionId, provinceId,
            lat, lon, population, populationYear, populationDefinition,
            populationSourceIds, geometryRef}],
  regions: [<normalized display records>],
  provinces: [<normalized intermediate-division display records>],
  profiles: [<city sections records with municipalityId>],
  entities: [<normalized display records including overlapping geographies>],
  boundaries: {countries, country, regions, provinces},
  view: {center: [longitude, latitude], zoom, attribution,
         insets: [{label, center: [longitude, latitude], zoom}]}
}
```

The `provinceId` / `provinces` names are compatibility keys used by the shared UI and do **not** rename French departments or Italian territorial units. Display vocabulary and route segments come from the registry. Every runtime map feature has standardized `properties.id`, `properties.name` and `properties.CNTR_CODE`; native source features and identifiers are preserved separately through `geometryRef`.

Every generated page carries `data-country` and `data-country-config`. Maps carry the existing level/region/province/place hooks plus `data-geometry-path`, `data-geometry-id-property` and `data-geometry-id`, allowing selected municipal or overlapping geographic boundaries to load without knowing the national source layout. The directory uses the existing responsive form controls and provides complete intermediate-division lists for browsing without JavaScript or the map.

Boundary attribution is mandatory for generic publication: supply `mapAttribution`, `mapView.attribution` or the source provenance’s `attribution`. It appears in the country introduction and runtime map configuration. Optional `mapView` settings support the primary geographic extent and named island/overseas insets; the region selector also reaches every packaged regional boundary. Region/division source geometry can be a shared file or separate files referenced by mapped entities.

Run the renderer regression check with:

```sh
python3 scripts/test_render_country.py
```

The test publishes **temporary synthetic fixtures only**, exercising French and Italian routes, native identifier preservation, country-specific labels, section/bibliography handling, content escaping and normalized map data. No fixture enters the real atlas dataset. The real registry currently emits zero additional country routes because France and Italy remain disabled and unimported.
