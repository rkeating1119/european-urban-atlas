# Reader edition status · 7 November 2026

Live: https://rkeating1119.github.io/european-urban-atlas/

The revised reader-edition scope is implemented and published: Spain 60, France 51, Italy 50; all 57 regional jurisdictions represented, including Spanish autonomous cities and French overseas regions. This completion statement applies to the latest curated-city request, not the superseded requirement to deeply research every national municipality.

Completed: rewritten summaries and nine concrete sections for every city; named neighborhoods and foods; country and city dropdowns; map labels for principal regional cities; search and filters over the curated selection; useful cross-country comparisons with seven explained ratings, food and neighborhoods; unobtrusive sources; responsive reading and comparison layouts; a permanent public host.

Deployment: GitHub Pages, public repository rkeating1119/european-urban-atlas. Workflow 42436817375 succeeded for publication commit 92c3a0f1dc762e8ca41c6f03f67525eee83f7dc8. The uploaded site archive matches the tested build SHA-256 3289f5b708f61e208409eaddcf1dad3cfd124a4b704e5ddfd787c6d5919503a9. It remains online without a local browser tab or server.

Audits: zero material errors in the reader/content/routes audit; no exact/near-duplicate paragraphs; mean sentence lengths of 15–16 words. The reader-interest matrix is in docs/READER-AUDIT.md. Current-source HTTP audit checked 414 URLs: 349 accessible, 46 inconclusive network errors, 15 blocked, four transient/server errors, no confirmed 404/410. Those outcomes do not certify that every source was substantively readable.

Two retained review notes are intentional: Mamoudzou has no displayed population because the available figure was from an older census; Ajaccio’s accurate coastal center falls slightly outside the simplified regional shoreline. Ratings remain editorial preferences with explanations. Actual iPad hardware, Safari and a full screen-reader audit are not claimed.

Future work is ordinary maintenance or user-directed expansion: update dated facts and sources, refine ratings in response to editorial feedback, add cities or countries using the existing shared templates, and keep the public release and source archive synchronized. No user action is required to keep the current site alive.
