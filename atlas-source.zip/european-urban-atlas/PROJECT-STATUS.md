# Reader edition status · geography and architecture update

Live: https://rkeating1119.github.io/european-urban-atlas/

Published selection: Spain 60, France 51, Italy 50; all 57 regional jurisdictions represented. The latest follow-up is complete: larger maps, one zoom-scaled dot per city, top-ten country labels, hover/tap cards, central Spanish display pins, searchable in-page dropdowns and expanded city writing. Every article has its concise opening, two-paragraph geographic overview and ten sections including architecture and street appearance. Comparisons now include architecture descriptions.

The overview and section prose contains 135,102 words, up 55,291 from the previous edition. The current audit passed for all 161 city profiles, 291 HTML pages, 8,205 internal targets and 2,498 section links. No exact/near-duplicate paragraphs were found. All 538 source URLs were requested; stale Girona and Brest links were replaced, with no confirmed 404/410 remaining. Network failures and blocked pages remain inconclusive.

GitHub Pages run 42439979170 succeeded for publication commit 67acb64847d52960c08df3d80613a37118b8765e. Public release key: 9d006fb6e621. Site archive SHA-256: 827ae67901e4f6b05b808789a8a588de53741270de5c026f0c8f9a892f9610ff. The site remains online independently of local tabs, this chat or a preview server.

The audit retains five data notes: A Coruña, Ceuta, Melilla and Ajaccio have accurate coastal centers slightly outside the simplified regional shoreline; Mamoudzou omits an unknown current population. Spanish display points pass the preserved, more detailed municipal polygons. Responsive layouts were checked; actual iPad hardware, Safari and full screen-reader certification are not claimed.

Current source, static build, audit records and recovery history are saved locally. The public repository preserves the deployable website and current source archive. Future work is ordinary maintenance or user-directed additions. No user action is needed to keep this release online.
