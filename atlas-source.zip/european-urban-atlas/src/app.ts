import type { Map as LibreMap, Marker } from "maplibre-gl";

type Rating = { score: number; summary: string };
type City = {
  id: string;
  name: string;
  aliases: string[];
  countryId: string;
  regionId: string;
  regionName: string;
  lat: number;
  lon: number;
  summary: string;
  goodFor: string[];
  tradeoffs: string[];
  population: { value: number; year: number; unit: string } | null;
  size: string;
  ratings: Record<string, Rating>;
  details: { food: string; neighborhoods: string; architecture: string };
  url: string;
  mapLabel: boolean;
};
type Country = {
  id: string;
  slug: string;
  name: string;
  summary: string;
  url: string;
  regions: {
    id: string;
    name: string;
    summary: string;
    url: string;
    cityIds: string[];
  }[];
  cities: City[];
  view: {
    center: [number, number];
    zoom: number;
    insets: { name: string; center: [number, number]; zoom: number }[];
  };
};
type Atlas = {
  countries: Country[];
  cities: City[];
  categories: { id: string; name: string; description: string }[];
};
const base = document.documentElement.dataset.base ?? "";
const release = document.documentElement.dataset.release ?? "current";
const asset = (path: string) => base + path;
const $ = <T extends HTMLElement>(selector: string) =>
  document.querySelector<T>(selector);
const esc = (v: unknown) =>
  String(v ?? "").replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ]!,
  );
const norm = (v: string) =>
  v
    .normalize("NFD")
    .replace(/\p{Diacritic}/gu, "")
    .toLowerCase()
    .replace(/[’'.,/-]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
let dataPromise: Promise<Atlas> | undefined;
const data = (): Promise<Atlas> =>
  (dataPromise ??= fetch(asset(`/data/atlas.json?v=${release}`)).then((r) => {
    if (!r.ok) throw Error("City data could not load");
    return r.json();
  }));
function cityMatches(c: City, q: string) {
  return norm([c.name, ...c.aliases, c.regionName].join(" ")).includes(q);
}
function stars(score: number) {
  return `<span class="rating-value" aria-label="${score} out of 5"><b>${score}</b><small>/5</small><span class="rating-dots" aria-hidden="true">${"●".repeat(score)}${"○".repeat(5 - score)}</span></span>`;
}
function card(c: City) {
  return `<a class="browse-city" href="${esc(c.url)}"><span class="eyebrow">${esc(c.regionName)} · ${esc(c.countryId === "ES" ? "Spain" : c.countryId === "FR" ? "France" : "Italy")}</span><h3>${esc(c.name)} <span aria-hidden="true">↗</span></h3><p>${esc(c.summary)}</p><div class="city-tags">${c.goodFor
    .slice(0, 3)
    .map((x) => `<span>${esc(x)}</span>`)
    .join("")}</div></a>`;
}
async function search() {
  const input = $<HTMLInputElement>("#global-search"),
    out = $("#search-results");
  if (!input || !out) return;
  let sequence = 0;
  input.addEventListener("input", async () => {
    const s = ++sequence,
      q = norm(input.value);
    if (!q) {
      out.hidden = true;
      return;
    }
    out.hidden = false;
    try {
      const atlas = await data();
      if (s !== sequence) return;
      const cs = atlas.cities
        .filter((c) => cityMatches(c, q))
        .sort(
          (a, b) =>
            Number(norm(b.name) === q) - Number(norm(a.name) === q) ||
            (b.population?.value ?? 0) - (a.population?.value ?? 0),
        );
      const countries = atlas.countries.filter((c) => norm(c.name).includes(q));
      const regions = atlas.countries
        .flatMap((c) => c.regions.map((r) => ({ ...r, country: c.name })))
        .filter((r) => norm(r.name).includes(q));
      out.innerHTML =
        countries
          .map(
            (c) =>
              `<a href="${esc(c.url)}"><strong>${esc(c.name)}</strong><small>Country</small></a>`,
          )
          .join("") +
        regions
          .slice(0, 3)
          .map(
            (r) =>
              `<a href="${esc(r.url)}"><strong>${esc(r.name)}</strong><small>${esc(r.country)}</small></a>`,
          )
          .join("") +
        cs
          .slice(0, 8)
          .map(
            (c) =>
              `<a href="${esc(c.url)}"><strong>${esc(c.name)}</strong><small>${esc(c.regionName)} · ${esc(c.countryId)}</small></a>`,
          )
          .join("") +
        `<a href="${asset("/cities/")}?q=${encodeURIComponent(input.value)}">${cs.length ? `See ${cs.length} matching cities` : "Browse all cities"} →</a>`;
    } catch {
      out.innerHTML = `<a href="${asset("/cities/")}">Browse cities →</a>`;
    }
  });
  input.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      out.hidden = true;
      input.blur();
    }
    if (e.key === "ArrowDown") {
      e.preventDefault();
      out.querySelector<HTMLAnchorElement>("a")?.focus();
    }
  });
  document.addEventListener("click", (e) => {
    if (!(e.target as Element).closest(".search-wrap")) out.hidden = true;
  });
}
function navigation() {
  document.querySelectorAll<HTMLSelectElement>(".country-switch").forEach((s) =>
    s.addEventListener("change", () => {
      location.href = s.value;
    }),
  );
  document.querySelectorAll<HTMLSelectElement>(".city-switch").forEach((s) =>
    s.addEventListener("change", () => {
      if (s.value) location.href = s.value;
    }),
  );
}
// Keep form values in the native controls, but render and operate menus in-page.
// This also covers dynamically populated region and comparison choices.
function dropdowns() {
  let closeCurrent: (() => void) | undefined;
  document
    .querySelectorAll<HTMLSelectElement>("select")
    .forEach((select, index) => {
      const label = select.closest("label");
      const name =
        select.getAttribute("aria-label") ||
        (label
          ? [...label.childNodes]
              .filter((n) => n.nodeType === Node.TEXT_NODE)
              .map((n) => n.textContent)
              .join(" ")
              .trim() || label.querySelector(".sr-only")?.textContent
          : "") ||
        "Choose an option";
      const root = document.createElement("div");
      root.className = "site-select";
      const trigger = document.createElement("button");
      trigger.type = "button";
      trigger.className = "select-trigger";
      trigger.id = `select-trigger-${index}`;
      trigger.setAttribute("aria-label", name);
      trigger.setAttribute("aria-haspopup", "listbox");
      trigger.setAttribute("aria-expanded", "false");
      trigger.setAttribute("aria-controls", `select-options-${index}`);
      const panel = document.createElement("div");
      panel.className = "select-panel";
      panel.hidden = true;
      const filter = document.createElement("input");
      filter.type = "search";
      filter.className = "select-search";
      filter.placeholder = "Type to find…";
      filter.setAttribute("aria-label", `Search ${name.toLowerCase()}`);
      filter.autocomplete = "off";
      const list = document.createElement("div");
      list.id = `select-options-${index}`;
      list.className = "select-options";
      list.setAttribute("role", "listbox");
      list.setAttribute("aria-label", name);
      panel.append(filter, list);
      select.before(root);
      root.append(select, trigger, panel);
      select.hidden = true;
      select.dataset.customized = "true";
      select.tabIndex = -1;
      select.setAttribute("aria-hidden", "true");
      if (label) label.htmlFor = trigger.id;
      function sync() {
        const option = select.selectedOptions[0];
        trigger.innerHTML = `<span>${esc(option?.textContent || "Choose…")}</span><span class="select-chevron" aria-hidden="true">⌄</span>`;
        trigger.disabled = select.disabled;
        filter.hidden = select.options.length < 9;
        renderOptions();
      }
      function renderOptions() {
        const query = norm(filter.value);
        let group = "";
        list.innerHTML = "";
        for (const option of select.options) {
          const parent = option.parentElement;
          const heading =
            parent instanceof HTMLOptGroupElement ? parent.label : "";
          if (
            query &&
            !norm(`${option.textContent} ${heading}`).includes(query)
          )
            continue;
          if (heading && heading !== group) {
            const title = document.createElement("p");
            title.className = "select-group";
            title.textContent = heading;
            title.setAttribute("role", "presentation");
            list.append(title);
          }
          group = heading;
          const choice = document.createElement("button");
          choice.type = "button";
          choice.className = "select-option";
          choice.setAttribute("role", "option");
          choice.setAttribute("aria-selected", String(option.selected));
          choice.tabIndex = -1;
          choice.disabled = option.disabled;
          choice.textContent = option.textContent;
          choice.addEventListener("click", () => {
            select.value = option.value;
            close(true);
            select.dispatchEvent(new Event("change", { bubbles: true }));
            sync();
          });
          list.append(choice);
        }
        if (!list.querySelector("button"))
          list.innerHTML = '<p class="select-empty">No matching places.</p>';
      }
      function close(focus = false) {
        panel.hidden = true;
        root.classList.remove("is-open");
        trigger.setAttribute("aria-expanded", "false");
        if (focus) trigger.focus();
        if (closeCurrent === dismiss) closeCurrent = undefined;
      }
      const dismiss = () => close();
      function open() {
        closeCurrent?.();
        closeCurrent = dismiss;
        filter.value = "";
        sync();
        panel.hidden = false;
        root.classList.add("is-open");
        trigger.setAttribute("aria-expanded", "true");
        const rect = trigger.getBoundingClientRect();
        const mapBox = root.closest(".map-shell")?.getBoundingClientRect();
        const above = rect.top - Math.max(12, mapBox ? mapBox.top + 12 : 12);
        const below =
          Math.min(
            innerHeight - 12,
            mapBox ? mapBox.bottom - 12 : innerHeight - 12,
          ) - rect.bottom;
        const opensUp = !!mapBox || (below < 230 && above > below);
        root.classList.toggle("opens-up", opensUp);
        list.style.maxHeight = `${Math.max(85, Math.min(340, (opensUp ? above : below) - (filter.hidden ? 20 : 67)))}px`;
        panel.style.left = "0";
        panel.style.right = "auto";
        if (panel.getBoundingClientRect().right > innerWidth - 12) {
          panel.style.left = "auto";
          panel.style.right = "0";
        }
        if (!filter.hidden) filter.focus();
        else
          list
            .querySelector<HTMLButtonElement>('[aria-selected="true"]')
            ?.focus();
      }
      trigger.addEventListener("click", () =>
        panel.hidden ? open() : close(),
      );
      trigger.addEventListener("keydown", (event) => {
        if (["ArrowDown", "ArrowUp"].includes(event.key)) {
          event.preventDefault();
          open();
          if (filter.hidden)
            list.querySelector<HTMLButtonElement>("button")?.focus();
        }
      });
      panel.addEventListener("keydown", (event) => {
        const options = [
          ...list.querySelectorAll<HTMLButtonElement>("button:not(:disabled)"),
        ];
        const current = options.indexOf(
          document.activeElement as HTMLButtonElement,
        );
        if (event.key === "Escape") {
          event.preventDefault();
          event.stopPropagation();
          close(true);
        } else if (
          ["ArrowDown", "ArrowUp", "Home", "End"].includes(event.key)
        ) {
          if (event.target === filter && ["Home", "End"].includes(event.key))
            return;
          event.preventDefault();
          const next =
            event.key === "Home"
              ? 0
              : event.key === "End"
                ? options.length - 1
                : event.key === "ArrowDown"
                  ? Math.min(current + 1, options.length - 1)
                  : Math.max(current - 1, 0);
          options[next]?.focus();
        } else if (event.key === "Tab") close();
      });
      filter.addEventListener("input", (event) => {
        event.stopPropagation();
        renderOptions();
      });
      filter.addEventListener("keydown", (event) => {
        if (event.key === "Enter") {
          event.preventDefault();
          list.querySelector<HTMLButtonElement>("button")?.click();
        }
      });
      root.addEventListener("focusout", (event) => {
        if (!root.contains(event.relatedTarget as Node)) close();
      });
      document.addEventListener("pointerdown", (event) => {
        if (!root.contains(event.target as Node)) close();
      });
      select.addEventListener("change", sync);
      select.addEventListener("atlas-select-refresh", sync);
      new MutationObserver(sync).observe(select, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ["disabled", "selected", "label"],
      });
      sync();
    });
}
async function browse() {
  const form = $<HTMLFormElement>("#browse-form");
  if (!form) return;
  const atlas = await data(),
    out = $("#browse-results")!,
    count = $("#browse-count")!,
    country = $<HTMLSelectElement>("#browse-country")!,
    region = $<HTMLSelectElement>("#browse-region")!;
  const q = $<HTMLInputElement>("#browse-query")!,
    params = new URLSearchParams(location.search);
  q.value = params.get("q") ?? "";
  country.value = params.get("country") ?? form.dataset.country ?? "";
  country.dispatchEvent(new Event("atlas-select-refresh"));
  let initialRegion = params.get("region") ?? form.dataset.region ?? "";
  function regions() {
    const keep = region.value || initialRegion;
    initialRegion = "";
    region.innerHTML =
      '<option value="">All regions</option>' +
      atlas.countries
        .filter((c) => !country.value || c.id === country.value)
        .flatMap((c) =>
          c.regions.map(
            (r) =>
              `<option value="${c.id}:${esc(r.id)}">${esc(r.name)}${!country.value ? " · " + c.name : ""}</option>`,
          ),
        )
        .join("");
    region.value = keep;
  }
  function render() {
    const fd = new FormData(form!),
      query = norm(q.value),
      r = String(fd.get("region") ?? ""),
      theme = String(fd.get("theme") ?? ""),
      order = String(fd.get("sort") ?? "name");
    const cities = atlas.cities.filter(
      (c) =>
        (!country.value || c.countryId === country.value) &&
        (!r || `${c.countryId}:${c.regionId}` === r) &&
        (!query || cityMatches(c, query)) &&
        (!theme || (c.ratings[theme]?.score ?? 0) >= 4),
    );
    if (order === "population")
      cities.sort(
        (a, b) => (b.population?.value ?? 0) - (a.population?.value ?? 0),
      );
    else if (order === "affordability")
      cities.sort(
        (a, b) => b.ratings.affordability.score - a.ratings.affordability.score,
      );
    else cities.sort((a, b) => a.name.localeCompare(b.name));
    out.innerHTML =
      cities.map(card).join("") ||
      '<p class="empty">No cities match. Try a different filter or spelling.</p>';
    count.textContent = `${cities.length} ${cities.length === 1 ? "city" : "cities"}`;
  }
  regions();
  country.addEventListener("change", () => {
    region.value = "";
    regions();
    render();
  });
  form.addEventListener("input", render);
  form.addEventListener("change", render);
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    render();
  });
  render();
}
function compareMarkup(cities: City[], atlas: Atlas) {
  return `<div class="comparison-leads" style="--columns:${cities.length}">${cities.map((c) => `<article><p class="eyebrow">${esc(c.regionName)} · ${esc(atlas.countries.find((k) => k.id === c.countryId)?.name)}</p><h2><a href="${esc(c.url)}">${esc(c.name)} ↗</a></h2><p>${esc(c.summary)}</p><p class="compare-fit"><strong>Good for:</strong> ${c.goodFor.map(esc).join(", ")}.</p></article>`).join("")}</div>${atlas.categories.map((category) => `<section class="compare-category"><div class="compare-category-title"><h3>${esc(category.name)}</h3><p>${esc(category.description)}</p></div><div class="comparison-values" style="--columns:${cities.length}">${cities.map((c) => `<article><p class="compare-city-label">${esc(c.name)}</p>${stars(c.ratings[category.id].score)}<p>${esc(c.ratings[category.id].summary)}</p></article>`).join("")}</div></section>`).join("")}${[
    { id: "food", name: "Food & local flavor" },
    { id: "neighborhoods", name: "Neighborhoods to know" },
    { id: "architecture", name: "Architecture & street life" },
  ]
    .map(
      (category) =>
        `<section class="compare-category"><div class="compare-category-title"><h3>${category.name}</h3></div><div class="comparison-values" style="--columns:${cities.length}">${cities.map((c) => `<article><p class="compare-city-label">${esc(c.name)}</p><p>${esc(c.details[category.id as keyof City["details"]])}</p></article>`).join("")}</div></section>`,
    )
    .join(
      "",
    )}<section class="compare-category"><div class="compare-category-title"><h3>The compromise</h3></div><div class="comparison-values" style="--columns:${cities.length}">${cities.map((c) => `<article><p class="compare-city-label">${esc(c.name)}</p><p>${c.tradeoffs.map(esc).join("; ")}</p><a class="text-link" href="${esc(c.url)}">Read about ${esc(c.name)} →</a></article>`).join("")}</div></section>`;
}
async function compare() {
  const form = $<HTMLFormElement>("#compare-form");
  if (!form) return;
  const atlas = await data(),
    out = $("#compare-results")!,
    selects = [...form.querySelectorAll<HTMLSelectElement>("select")];
  const options = (empty = false) =>
    (empty ? '<option value="">No third city</option>' : "") +
    atlas.countries
      .map(
        (c) =>
          `<optgroup label="${esc(c.name)}">${c.cities.map((city) => `<option value="${c.id}:${city.id}">${esc(city.name)}</option>`).join("")}</optgroup>`,
      )
      .join("");
  const params = new URLSearchParams(location.search),
    initial = params.get("cities")?.split(",") ?? [
      "ES:madrid",
      "FR:paris",
      "IT:rome",
    ];
  selects.forEach((s, i) => {
    s.innerHTML = options(i === 2);
    s.value = initial[i] ?? "";
  });
  function render() {
    const selected = selects
      .map((s) =>
        atlas.cities.find((c) => `${c.countryId}:${c.id}` === s.value),
      )
      .filter(Boolean) as City[];
    const distinct = [
      ...new Map(selected.map((c) => [`${c.countryId}:${c.id}`, c])).values(),
    ];
    if (distinct.length < 2) {
      out.innerHTML =
        '<p role="status">Choose at least two different cities.</p>';
      return;
    }
    out.innerHTML = compareMarkup(distinct, atlas);
    const url = new URL(location.href);
    url.searchParams.set(
      "cities",
      distinct.map((c) => `${c.countryId}:${c.id}`).join(","),
    );
    history.replaceState(null, "", url);
  }
  form.addEventListener("change", render);
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    render();
  });
  render();
}
async function map() {
  const node = $("#atlas-map");
  if (!node) return;
  const disclosure = node.closest("details");
  if (disclosure && !disclosure.open)
    await new Promise<void>((resolve) => {
      const onToggle = () => {
        if (disclosure.open) {
          disclosure.removeEventListener("toggle", onToggle);
          resolve();
        }
      };
      disclosure.addEventListener("toggle", onToggle);
    });
  const status = $("#map-status");
  try {
    const atlas = await data(),
      { default: libre } = await import("maplibre-gl");
    const cc = node.dataset.country,
      regionId = node.dataset.region,
      selectedCity = node.dataset.city;
    const country = atlas.countries.find((c) => c.id === cc),
      city = atlas.cities.find(
        (c) => `${c.countryId}:${c.id}` === selectedCity,
      );
    const countries = await fetch(asset("/data/maps/world.geojson")).then((r) =>
      r.json(),
    );
    const layers = await Promise.all(
      atlas.countries.map((c) =>
        fetch(asset(`/data/maps/${c.slug}-regions.geojson`))
          .then((r) => r.json())
          .then((d) => ({ country: c, geo: d })),
      ),
    );
    const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
    const m = new libre.Map({
      container: node,
      style: {
        version: 8,
        sources: { countries: { type: "geojson", data: countries } },
        layers: [
          {
            id: "water",
            type: "background",
            paint: { "background-color": "#dfe9e7" },
          },
          {
            id: "land",
            type: "fill",
            source: "countries",
            paint: {
              "fill-color": [
                "match",
                ["get", "id"],
                "ES",
                "#dfdcc4",
                "FR",
                "#d2dfd1",
                "IT",
                "#e7d5c5",
                "#eeece4",
              ],
            },
          },
          {
            id: "borders",
            type: "line",
            source: "countries",
            paint: { "line-color": "#a0afa4", "line-width": 0.8 },
          },
        ],
      },
      center: city
        ? [city.lon, city.lat]
        : country
          ? country.view.center
          : [5, 45],
      zoom: city ? 9 : country ? country.view.zoom : 3.7,
      attributionControl: false,
      maxZoom: 14,
      minZoom: 2,
      cooperativeGestures: !!city,
      renderWorldCopies: false,
    });
    m.dragRotate.disable();
    m.touchZoomRotate.disableRotation();
    m.addControl(
      new libre.NavigationControl({ showCompass: false }),
      "top-right",
    );
    m.addControl(
      new libre.FullscreenControl({ container: node.parentElement! }),
      "top-right",
    );
    m.addControl(
      new libre.AttributionControl({
        compact: false,
        customAttribution:
          "© EuroGeographics for the administrative boundaries · Eurostat GISCO",
      }),
    );
    const fit = (f: any) => {
      const points = (a: any): number[][] =>
        typeof a[0] === "number" ? [a] : a.flatMap(points);
      const b = new libre.LngLatBounds();
      points(f.geometry.coordinates).forEach((p) =>
        b.extend(p as [number, number]),
      );
      m.fitBounds(b, { padding: 45, maxZoom: 8, duration: reduced ? 0 : 500 });
    };
    const popup = new libre.Popup({ closeButton: true, maxWidth: "310px" }),
      markers: {
        marker: Marker;
        city?: City;
        kind: "city" | "country";
        element: HTMLElement;
      }[] = [];
    m.on("load", () => {
      if (status) status.hidden = true;
      for (const layer of layers) {
        m.addSource("regions-" + layer.country.id, {
          type: "geojson",
          data: layer.geo,
        });
        m.addLayer({
          id: "region-fill-" + layer.country.id,
          type: "fill",
          source: "regions-" + layer.country.id,
          paint: {
            "fill-color": "#628272",
            "fill-opacity": cc === layer.country.id ? 0.07 : 0,
          },
          minzoom: 4.3,
        });
        m.addLayer({
          id: "region-lines-" + layer.country.id,
          type: "line",
          source: "regions-" + layer.country.id,
          minzoom: 4.3,
          paint: { "line-color": "#789082", "line-width": 0.9 },
        });
        m.on("click", "region-fill-" + layer.country.id, (e) => {
          if (
            m.queryRenderedFeatures(e.point, { layers: ["city-points"] }).length
          )
            return;
          const f = e.features?.[0],
            r = layer.country.regions.find((r) => r.id === f?.properties.id);
          if (!r) return;
          popup
            .setLngLat(e.lngLat)
            .setHTML(
              `<p class="eyebrow">${esc(layer.country.name)}</p><h3>${esc(r.name)}</h3><p>${esc(
                r.summary
                  .split(/(?<=[.!?])\s/)
                  .slice(0, 2)
                  .join(" "),
              )}</p><a class="map-link" href="${esc(r.url)}">Explore cities →</a>`,
            )
            .addTo(m);
        });
      }
      const mapCities = atlas.cities.filter(
        (c) => !country || c.countryId === country.id,
      );
      const points = {
        type: "FeatureCollection",
        features: mapCities.map((c) => ({
          type: "Feature",
          properties: { key: `${c.countryId}:${c.id}` },
          geometry: { type: "Point", coordinates: [c.lon, c.lat] },
        })),
      };
      m.addSource("city-points", { type: "geojson", data: points as any });
      m.addLayer({
        id: "city-points",
        type: "circle",
        source: "city-points",
        paint: {
          "circle-color": "#a64e39",
          "circle-radius": [
            "interpolate",
            ["linear"],
            ["zoom"],
            2,
            0.8,
            4,
            2,
            5,
            3,
            7,
            5,
            10,
            7,
            14,
            9,
          ],
          "circle-stroke-color": "#fffef9",
          "circle-stroke-width": [
            "interpolate",
            ["linear"],
            ["zoom"],
            2,
            0.3,
            5,
            1,
            10,
            1.8,
          ],
        },
      });
      // A transparent hit area makes small dots usable without drawing larger dots.
      m.addLayer({
        id: "city-hit",
        type: "circle",
        source: "city-points",
        paint: {
          "circle-radius": [
            "interpolate",
            ["linear"],
            ["zoom"],
            2,
            4,
            5,
            7,
            10,
            11,
          ],
          "circle-opacity": 0,
        },
      });
      const hover = new libre.Popup({
        closeButton: false,
        maxWidth: "310px",
        closeOnMove: true,
      });
      let hovered: string | undefined;
      let closeHover: ReturnType<typeof setTimeout> | undefined;
      const cityCard = (c: City) =>
        `<p class="eyebrow">${esc(c.regionName)}</p><h3>${esc(c.name)}</h3><p>${esc(c.summary)}</p><a class="map-link" href="${esc(c.url)}">Read about ${esc(c.name)} →</a>`;
      function cancelHoverClose() {
        if (closeHover) clearTimeout(closeHover);
      }
      function showHover(c: City) {
        cancelHoverClose();
        if (hovered === `${c.countryId}:${c.id}` && hover.isOpen()) return;
        hovered = `${c.countryId}:${c.id}`;
        hover.setLngLat([c.lon, c.lat]).setHTML(cityCard(c)).addTo(m);
        hover.getElement().addEventListener("mouseenter", cancelHoverClose);
        hover.getElement().addEventListener("mouseleave", hideHover);
      }
      function hideHover() {
        cancelHoverClose();
        closeHover = setTimeout(() => {
          hover.remove();
          hovered = undefined;
        }, 180);
      }
      m.on("mousemove", "city-hit", (e) => {
        m.getCanvas().style.cursor = "pointer";
        const c = mapCities.find(
          (c) => `${c.countryId}:${c.id}` === e.features?.[0]?.properties.key,
        );
        if (c) showHover(c);
      });
      m.on("mouseleave", "city-hit", () => {
        m.getCanvas().style.cursor = "";
        hideHover();
      });
      m.on("zoomstart", () => {
        hover.remove();
        hovered = undefined;
      });
      m.on("click", "city-hit", (e) => {
        const c = atlas.cities.find(
          (c) => `${c.countryId}:${c.id}` === e.features?.[0]?.properties.key,
        );
        if (c) openCity(c);
      });
      function openCity(c: City) {
        hover.remove();
        popup.setLngLat([c.lon, c.lat]).setHTML(cityCard(c)).addTo(m);
      }
      const shown = city ? [city] : mapCities.filter((c) => c.mapLabel);
      for (const c of shown) {
        const b = document.createElement("button");
        b.className = "city-pin";
        b.ariaLabel = `Explore ${c.name}`;
        b.innerHTML = `<span class="pin-name">${esc(c.name)}</span>`;
        b.addEventListener("mouseenter", () => showHover(c));
        b.addEventListener("mouseleave", hideHover);
        b.addEventListener("click", (e) => {
          e.stopPropagation();
          openCity(c);
        });
        markers.push({
          marker: new libre.Marker({
            element: b,
            anchor: "left",
            offset: [8, 0],
          })
            .setLngLat([c.lon, c.lat])
            .addTo(m),
          city: c,
          kind: "city",
          element: b,
        });
      }
      if (!country && !city)
        for (const c of atlas.countries) {
          const a = document.createElement("a");
          a.className = "country-label";
          a.href = c.url;
          a.textContent = c.name;
          markers.push({
            marker: new libre.Marker({ element: a })
              .setLngLat(c.view.center)
              .addTo(m),
            kind: "country",
            element: a,
          });
        }
      function labels() {
        const z = m.getZoom();
        node!.style.setProperty(
          "--map-label-size",
          `${Math.max(9, Math.min(13, 9 + (z - 3) * 0.8))}px`,
        );
        node!.dataset.zoom = z.toFixed(2);
        for (const x of markers) {
          const visible = x.kind === "country" ? z < 4.3 : !!city || z >= 4.3;
          x.element.style.display = visible ? "flex" : "none";
        }
      }
      labels();
      m.on("zoom", labels);
      if (regionId && country) {
        const f = layers
          .find((x) => x.country.id === country.id)
          ?.geo.features.find((f: any) => f.properties.id === regionId);
        if (f) fit(f);
      }
      $<HTMLSelectElement>("#map-region")?.addEventListener("change", (e) => {
        const id = (e.target as HTMLSelectElement).value;
        const insetSelect = $<HTMLSelectElement>("#map-inset");
        if (insetSelect) {
          insetSelect.value = "";
          insetSelect.dispatchEvent(new Event("atlas-select-refresh"));
        }
        const f = layers
          .find((x) => x.country.id === country?.id)
          ?.geo.features.find((f: any) => f.properties.id === id);
        if (f) fit(f);
        else reset();
      });
      function reset() {
        for (const selector of ["#map-region", "#map-inset"]) {
          const select = $<HTMLSelectElement>(selector);
          if (select) {
            select.value = "";
            select.dispatchEvent(new Event("atlas-select-refresh"));
          }
        }
        popup.remove();
        hover.remove();
        m.flyTo({
          center: country ? country.view.center : [5, 45],
          zoom: country ? country.view.zoom : 3.7,
          duration: reduced ? 0 : 500,
        });
      }
      $<HTMLButtonElement>("#map-reset")?.addEventListener("click", reset);
      $<HTMLSelectElement>("#map-inset")?.addEventListener("change", (e) => {
        const value = (e.target as HTMLSelectElement).value;
        const inset = country?.view.insets[Number(value)];
        if (value !== "" && inset) {
          const regionSelect = $<HTMLSelectElement>("#map-region");
          if (regionSelect) {
            regionSelect.value = "";
            regionSelect.dispatchEvent(new Event("atlas-select-refresh"));
          }
          m.flyTo({
            center: inset.center,
            zoom: inset.zoom,
            duration: reduced ? 0 : 500,
          });
        }
      });
    });
    m.on("error", () => {
      if (status) {
        status.hidden = false;
        status.textContent =
          "The map could not load. You can browse every featured city below.";
      }
    });
    new ResizeObserver(() => m.resize()).observe(node);
  } catch {
    if (status) {
      status.hidden = false;
      status.innerHTML = `Map unavailable. <a href="${asset("/cities/")}">Browse cities →</a>`;
    }
  }
}
navigation();
dropdowns();
void search();
void browse();
void compare();
void map();
