import type { Map as LibreMap, Marker } from "maplibre-gl";

type Rating = { score: number; summary: string };
type City = {
  id: string;
  name: string;
  aliases: string[];
  countryId: string;
  regionId: string;
  regionName: string;
  lat: number;
  lon: number;
  summary: string;
  goodFor: string[];
  tradeoffs: string[];
  population: { value: number; year: number; unit: string } | null;
  size: string;
  ratings: Record<string, Rating>;
  details: { food: string; neighborhoods: string };
  url: string;
  mapLabel: boolean;
};
type Country = {
  id: string;
  slug: string;
  name: string;
  summary: string;
  url: string;
  regions: {
    id: string;
    name: string;
    summary: string;
    url: string;
    cityIds: string[];
  }[];
  cities: City[];
  view: {
    center: [number, number];
    zoom: number;
    insets: { name: string; center: [number, number]; zoom: number }[];
  };
};
type Atlas = {
  countries: Country[];
  cities: City[];
  categories: { id: string; name: string; description: string }[];
};
const base = document.documentElement.dataset.base ?? "";
const asset = (path: string) => base + path;
const $ = <T extends HTMLElement>(selector: string) =>
  document.querySelector<T>(selector);
const esc = (v: unknown) =>
  String(v ?? "").replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ]!,
  );
const norm = (v: string) =>
  v
    .normalize("NFD")
    .replace(/\p{Diacritic}/gu, "")
    .toLowerCase()
    .replace(/[’'.,/-]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
let dataPromise: Promise<Atlas> | undefined;
const data = (): Promise<Atlas> =>
  (dataPromise ??= fetch(asset("/data/atlas.json")).then((r) => {
    if (!r.ok) throw Error("City data could not load");
    return r.json();
  }));
function cityMatches(c: City, q: string) {
  return norm([c.name, ...c.aliases, c.regionName].join(" ")).includes(q);
}
function stars(score: number) {
  return `<span class="rating-value" aria-label="${score} out of 5"><b>${score}</b><small>/5</small><span class="rating-dots" aria-hidden="true">${"●".repeat(score)}${"○".repeat(5 - score)}</span></span>`;
}
function card(c: City) {
  return `<a class="browse-city" href="${esc(c.url)}"><span class="eyebrow">${esc(c.regionName)} · ${esc(c.countryId === "ES" ? "Spain" : c.countryId === "FR" ? "France" : "Italy")}</span><h3>${esc(c.name)} <span aria-hidden="true">↗</span></h3><p>${esc(c.summary)}</p><div class="city-tags">${c.goodFor
    .slice(0, 3)
    .map((x) => `<span>${esc(x)}</span>`)
    .join("")}</div></a>`;
}
async function search() {
  const input = $<HTMLInputElement>("#global-search"),
    out = $("#search-results");
  if (!input || !out) return;
  let sequence = 0;
  input.addEventListener("input", async () => {
    const s = ++sequence,
      q = norm(input.value);
    if (!q) {
      out.hidden = true;
      return;
    }
    out.hidden = false;
    try {
      const atlas = await data();
      if (s !== sequence) return;
      const cs = atlas.cities
        .filter((c) => cityMatches(c, q))
        .sort(
          (a, b) =>
            Number(norm(b.name) === q) - Number(norm(a.name) === q) ||
            (b.population?.value ?? 0) - (a.population?.value ?? 0),
        );
      const countries = atlas.countries.filter((c) => norm(c.name).includes(q));
      const regions = atlas.countries
        .flatMap((c) => c.regions.map((r) => ({ ...r, country: c.name })))
        .filter((r) => norm(r.name).includes(q));
      out.innerHTML =
        countries
          .map(
            (c) =>
              `<a href="${esc(c.url)}"><strong>${esc(c.name)}</strong><small>Country</small></a>`,
          )
          .join("") +
        regions
          .slice(0, 3)
          .map(
            (r) =>
              `<a href="${esc(r.url)}"><strong>${esc(r.name)}</strong><small>${esc(r.country)}</small></a>`,
          )
          .join("") +
        cs
          .slice(0, 8)
          .map(
            (c) =>
              `<a href="${esc(c.url)}"><strong>${esc(c.name)}</strong><small>${esc(c.regionName)} · ${esc(c.countryId)}</small></a>`,
          )
          .join("") +
        `<a href="${asset("/cities/")}?q=${encodeURIComponent(input.value)}">${cs.length ? `See ${cs.length} matching cities` : "Browse all cities"} →</a>`;
    } catch {
      out.innerHTML = `<a href="${asset("/cities/")}">Browse cities →</a>`;
    }
  });
  input.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      out.hidden = true;
      input.blur();
    }
    if (e.key === "ArrowDown") {
      e.preventDefault();
      out.querySelector<HTMLAnchorElement>("a")?.focus();
    }
  });
  document.addEventListener("click", (e) => {
    if (!(e.target as Element).closest(".search-wrap")) out.hidden = true;
  });
}
function navigation() {
  document.querySelectorAll<HTMLSelectElement>(".country-switch").forEach((s) =>
    s.addEventListener("change", () => {
      location.href = s.value;
    }),
  );
  document.querySelectorAll<HTMLSelectElement>(".city-switch").forEach((s) =>
    s.addEventListener("change", () => {
      if (s.value) location.href = s.value;
    }),
  );
}
async function browse() {
  const form = $<HTMLFormElement>("#browse-form");
  if (!form) return;
  const atlas = await data(),
    out = $("#browse-results")!,
    count = $("#browse-count")!,
    country = $<HTMLSelectElement>("#browse-country")!,
    region = $<HTMLSelectElement>("#browse-region")!;
  const q = $<HTMLInputElement>("#browse-query")!,
    params = new URLSearchParams(location.search);
  q.value = params.get("q") ?? "";
  country.value = params.get("country") ?? form.dataset.country ?? "";
  let initialRegion = params.get("region") ?? form.dataset.region ?? "";
  function regions() {
    const keep = region.value || initialRegion;
    initialRegion = "";
    region.innerHTML =
      '<option value="">All regions</option>' +
      atlas.countries
        .filter((c) => !country.value || c.id === country.value)
        .flatMap((c) =>
          c.regions.map(
            (r) =>
              `<option value="${c.id}:${esc(r.id)}">${esc(r.name)}${!country.value ? " · " + c.name : ""}</option>`,
          ),
        )
        .join("");
    region.value = keep;
  }
  function render() {
    const fd = new FormData(form!),
      query = norm(q.value),
      r = String(fd.get("region") ?? ""),
      theme = String(fd.get("theme") ?? ""),
      order = String(fd.get("sort") ?? "name");
    const cities = atlas.cities.filter(
      (c) =>
        (!country.value || c.countryId === country.value) &&
        (!r || `${c.countryId}:${c.regionId}` === r) &&
        (!query || cityMatches(c, query)) &&
        (!theme || (c.ratings[theme]?.score ?? 0) >= 4),
    );
    if (order === "population")
      cities.sort(
        (a, b) => (b.population?.value ?? 0) - (a.population?.value ?? 0),
      );
    else if (order === "affordability")
      cities.sort(
        (a, b) => b.ratings.affordability.score - a.ratings.affordability.score,
      );
    else cities.sort((a, b) => a.name.localeCompare(b.name));
    out.innerHTML =
      cities.map(card).join("") ||
      '<p class="empty">No cities match. Try a different filter or spelling.</p>';
    count.textContent = `${cities.length} ${cities.length === 1 ? "city" : "cities"}`;
  }
  regions();
  country.addEventListener("change", () => {
    region.value = "";
    regions();
    render();
  });
  form.addEventListener("input", render);
  form.addEventListener("change", render);
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    render();
  });
  render();
}
function compareMarkup(cities: City[], atlas: Atlas) {
  return `<div class="comparison-leads" style="--columns:${cities.length}">${cities.map((c) => `<article><p class="eyebrow">${esc(c.regionName)} · ${esc(atlas.countries.find((k) => k.id === c.countryId)?.name)}</p><h2><a href="${esc(c.url)}">${esc(c.name)} ↗</a></h2><p>${esc(c.summary)}</p><p class="compare-fit"><strong>Good for:</strong> ${c.goodFor.map(esc).join(", ")}.</p></article>`).join("")}</div>${atlas.categories.map((category) => `<section class="compare-category"><div class="compare-category-title"><h3>${esc(category.name)}</h3><p>${esc(category.description)}</p></div><div class="comparison-values" style="--columns:${cities.length}">${cities.map((c) => `<article><p class="compare-city-label">${esc(c.name)}</p>${stars(c.ratings[category.id].score)}<p>${esc(c.ratings[category.id].summary)}</p></article>`).join("")}</div></section>`).join("")}${[
    { id: "food", name: "Food & local flavor" },
    { id: "neighborhoods", name: "Neighborhoods to know" },
  ]
    .map(
      (category) =>
        `<section class="compare-category"><div class="compare-category-title"><h3>${category.name}</h3></div><div class="comparison-values" style="--columns:${cities.length}">${cities.map((c) => `<article><p class="compare-city-label">${esc(c.name)}</p><p>${esc(c.details[category.id as "food" | "neighborhoods"])}</p></article>`).join("")}</div></section>`,
    )
    .join(
      "",
    )}<section class="compare-category"><div class="compare-category-title"><h3>The compromise</h3></div><div class="comparison-values" style="--columns:${cities.length}">${cities.map((c) => `<article><p class="compare-city-label">${esc(c.name)}</p><p>${c.tradeoffs.map(esc).join("; ")}</p><a class="text-link" href="${esc(c.url)}">Read about ${esc(c.name)} →</a></article>`).join("")}</div></section>`;
}
async function compare() {
  const form = $<HTMLFormElement>("#compare-form");
  if (!form) return;
  const atlas = await data(),
    out = $("#compare-results")!,
    selects = [...form.querySelectorAll<HTMLSelectElement>("select")];
  const options = (empty = false) =>
    (empty ? '<option value="">No third city</option>' : "") +
    atlas.countries
      .map(
        (c) =>
          `<optgroup label="${esc(c.name)}">${c.cities.map((city) => `<option value="${c.id}:${city.id}">${esc(city.name)}</option>`).join("")}</optgroup>`,
      )
      .join("");
  const params = new URLSearchParams(location.search),
    initial = params.get("cities")?.split(",") ?? [
      "ES:madrid",
      "FR:paris",
      "IT:rome",
    ];
  selects.forEach((s, i) => {
    s.innerHTML = options(i === 2);
    s.value = initial[i] ?? "";
  });
  function render() {
    const selected = selects
      .map((s) =>
        atlas.cities.find((c) => `${c.countryId}:${c.id}` === s.value),
      )
      .filter(Boolean) as City[];
    const distinct = [
      ...new Map(selected.map((c) => [`${c.countryId}:${c.id}`, c])).values(),
    ];
    if (distinct.length < 2) {
      out.innerHTML =
        '<p role="status">Choose at least two different cities.</p>';
      return;
    }
    out.innerHTML = compareMarkup(distinct, atlas);
    const url = new URL(location.href);
    url.searchParams.set(
      "cities",
      distinct.map((c) => `${c.countryId}:${c.id}`).join(","),
    );
    history.replaceState(null, "", url);
  }
  form.addEventListener("change", render);
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    render();
  });
  render();
}
async function map() {
  const node = $("#atlas-map");
  if (!node) return;
  const disclosure = node.closest("details");
  if (disclosure && !disclosure.open)
    await new Promise<void>((resolve) => {
      const onToggle = () => {
        if (disclosure.open) {
          disclosure.removeEventListener("toggle", onToggle);
          resolve();
        }
      };
      disclosure.addEventListener("toggle", onToggle);
    });
  const status = $("#map-status");
  try {
    const atlas = await data(),
      { default: libre } = await import("maplibre-gl");
    const cc = node.dataset.country,
      regionId = node.dataset.region,
      selectedCity = node.dataset.city;
    const country = atlas.countries.find((c) => c.id === cc),
      city = atlas.cities.find(
        (c) => `${c.countryId}:${c.id}` === selectedCity,
      );
    const countries = await fetch(asset("/data/maps/world.geojson")).then((r) =>
      r.json(),
    );
    const layers = await Promise.all(
      atlas.countries.map((c) =>
        fetch(asset(`/data/maps/${c.slug}-regions.geojson`))
          .then((r) => r.json())
          .then((d) => ({ country: c, geo: d })),
      ),
    );
    const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
    const m = new libre.Map({
      container: node,
      style: {
        version: 8,
        sources: { countries: { type: "geojson", data: countries } },
        layers: [
          {
            id: "water",
            type: "background",
            paint: { "background-color": "#dfe9e7" },
          },
          {
            id: "land",
            type: "fill",
            source: "countries",
            paint: {
              "fill-color": [
                "match",
                ["get", "id"],
                "ES",
                "#dfdcc4",
                "FR",
                "#d2dfd1",
                "IT",
                "#e7d5c5",
                "#eeece4",
              ],
            },
          },
          {
            id: "borders",
            type: "line",
            source: "countries",
            paint: { "line-color": "#a0afa4", "line-width": 0.8 },
          },
        ],
      },
      center: city
        ? [city.lon, city.lat]
        : country
          ? country.view.center
          : [5, 45],
      zoom: city ? 9 : country ? country.view.zoom : 3.7,
      attributionControl: false,
      maxZoom: 14,
      minZoom: 2,
      cooperativeGestures: !!city,
    });
    m.dragRotate.disable();
    m.touchZoomRotate.disableRotation();
    m.addControl(
      new libre.NavigationControl({ showCompass: false }),
      "top-right",
    );
    m.addControl(
      new libre.AttributionControl({
        compact: false,
        customAttribution:
          "© EuroGeographics for the administrative boundaries · Eurostat GISCO",
      }),
    );
    const fit = (f: any) => {
      const points = (a: any): number[][] =>
        typeof a[0] === "number" ? [a] : a.flatMap(points);
      const b = new libre.LngLatBounds();
      points(f.geometry.coordinates).forEach((p) =>
        b.extend(p as [number, number]),
      );
      m.fitBounds(b, { padding: 45, maxZoom: 8, duration: reduced ? 0 : 500 });
    };
    const popup = new libre.Popup({ closeButton: true, maxWidth: "310px" }),
      markers: {
        marker: Marker;
        city?: City;
        kind: "city" | "country";
        element: HTMLElement;
      }[] = [];
    m.on("load", () => {
      if (status) status.hidden = true;
      for (const layer of layers) {
        m.addSource("regions-" + layer.country.id, {
          type: "geojson",
          data: layer.geo,
        });
        m.addLayer({
          id: "region-fill-" + layer.country.id,
          type: "fill",
          source: "regions-" + layer.country.id,
          paint: {
            "fill-color": "#628272",
            "fill-opacity": cc === layer.country.id ? 0.07 : 0,
          },
          minzoom: 4.3,
        });
        m.addLayer({
          id: "region-lines-" + layer.country.id,
          type: "line",
          source: "regions-" + layer.country.id,
          minzoom: 4.3,
          paint: { "line-color": "#789082", "line-width": 0.9 },
        });
        m.on("click", "region-fill-" + layer.country.id, (e) => {
          if (
            m.queryRenderedFeatures(e.point, { layers: ["city-points"] }).length
          )
            return;
          const f = e.features?.[0],
            r = layer.country.regions.find((r) => r.id === f?.properties.id);
          if (!r) return;
          popup
            .setLngLat(e.lngLat)
            .setHTML(
              `<p class="eyebrow">${esc(layer.country.name)}</p><h3>${esc(r.name)}</h3><p>${esc(
                r.summary
                  .split(/(?<=[.!?])\s/)
                  .slice(0, 2)
                  .join(" "),
              )}</p><a class="map-link" href="${esc(r.url)}">Explore cities →</a>`,
            )
            .addTo(m);
        });
      }
      const points = {
        type: "FeatureCollection",
        features: atlas.cities.map((c) => ({
          type: "Feature",
          properties: { key: `${c.countryId}:${c.id}` },
          geometry: { type: "Point", coordinates: [c.lon, c.lat] },
        })),
      };
      m.addSource("city-points", { type: "geojson", data: points as any });
      m.addLayer({
        id: "city-points",
        type: "circle",
        source: "city-points",
        minzoom: 5,
        paint: {
          "circle-color": "#a64e39",
          "circle-radius": 5,
          "circle-stroke-color": "#fffef9",
          "circle-stroke-width": 1.5,
        },
      });
      m.on("click", "city-points", (e) => {
        const c = atlas.cities.find(
          (c) => `${c.countryId}:${c.id}` === e.features?.[0]?.properties.key,
        );
        if (c) openCity(c);
      });
      function openCity(c: City) {
        popup
          .setLngLat([c.lon, c.lat])
          .setHTML(
            `<p class="eyebrow">${esc(c.regionName)}</p><h3>${esc(c.name)}</h3><p>${esc(c.summary)}</p><a class="map-link" href="${esc(c.url)}">Read about ${esc(c.name)} →</a>`,
          )
          .addTo(m);
      }
      const shown = city
        ? [city]
        : atlas.cities.filter((c) => !country || c.countryId === country.id);
      for (const c of shown) {
        const b = document.createElement("button");
        b.className = "city-pin";
        b.ariaLabel = `Explore ${c.name}`;
        b.innerHTML = `<span class="pin-dot"></span><span class="pin-name">${esc(c.name)}</span>`;
        b.addEventListener("click", (e) => {
          e.stopPropagation();
          openCity(c);
        });
        markers.push({
          marker: new libre.Marker({ element: b, anchor: "left" })
            .setLngLat([c.lon, c.lat])
            .addTo(m),
          city: c,
          kind: "city",
          element: b,
        });
      }
      if (!country && !city)
        for (const c of atlas.countries) {
          const a = document.createElement("a");
          a.className = "country-label";
          a.href = c.url;
          a.textContent = c.name;
          markers.push({
            marker: new libre.Marker({ element: a })
              .setLngLat(c.view.center)
              .addTo(m),
            kind: "country",
            element: a,
          });
        }
      function labels() {
        const z = m.getZoom();
        for (const x of markers) {
          const visible =
            x.kind === "country"
              ? z < 4.8
              : !!city ||
                ((!!country || z >= 4.6) && (x.city!.mapLabel || z >= 6.2));
          x.element.style.display = visible ? "flex" : "none";
        }
      }
      labels();
      m.on("zoom", labels);
      if (regionId && country) {
        const f = layers
          .find((x) => x.country.id === country.id)
          ?.geo.features.find((f: any) => f.properties.id === regionId);
        if (f) fit(f);
      }
      $<HTMLSelectElement>("#map-region")?.addEventListener("change", (e) => {
        const id = (e.target as HTMLSelectElement).value;
        const f = layers
          .find((x) => x.country.id === country?.id)
          ?.geo.features.find((f: any) => f.properties.id === id);
        if (f) fit(f);
        else reset();
      });
      function reset() {
        m.flyTo({
          center: country ? country.view.center : [5, 45],
          zoom: country ? country.view.zoom : 3.7,
          duration: reduced ? 0 : 500,
        });
      }
      $<HTMLButtonElement>("#map-reset")?.addEventListener("click", reset);
      $<HTMLSelectElement>("#map-inset")?.addEventListener("change", (e) => {
        const value = (e.target as HTMLSelectElement).value;
        const inset = country?.view.insets[Number(value)];
        if (value !== "" && inset)
          m.flyTo({
            center: inset.center,
            zoom: inset.zoom,
            duration: reduced ? 0 : 500,
          });
      });
    });
    m.on("error", () => {
      if (status) {
        status.hidden = false;
        status.textContent =
          "The map could not load. You can browse every featured city below.";
      }
    });
    new ResizeObserver(() => m.resize()).observe(node);
  } catch {
    if (status) {
      status.hidden = false;
      status.innerHTML = `Map unavailable. <a href="${asset("/cities/")}">Browse cities →</a>`;
    }
  }
}
navigation();
void search();
void browse();
void compare();
void map();
