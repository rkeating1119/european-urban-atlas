/** Serve pre-rendered documents, keeping missing routes a real 404. */
export default {
  async fetch(request, env) {
    if (!["GET", "HEAD"].includes(request.method))
      return new Response("Method not allowed", {
        status: 405,
        headers: { Allow: "GET, HEAD" },
      });
    const url = new URL(request.url);
    let response = await env.ASSETS.fetch(request);
    if (
      response.status === 404 &&
      !url.pathname.split("/").pop().includes(".")
    ) {
      const index = new URL(request.url);
      index.pathname = url.pathname.replace(/\/$/, "") + "/index.html";
      response = await env.ASSETS.fetch(new Request(index, request));
    }
    if (
      response.status === 404 &&
      request.headers.get("accept")?.includes("text/html")
    ) {
      const error = new URL(request.url);
      error.pathname = "/404.html";
      const page = await env.ASSETS.fetch(new Request(error, request));
      response = new Response(page.body, {
        status: 404,
        headers: page.headers,
      });
    }
    const headers = new Headers(response.headers);
    headers.set("X-Content-Type-Options", "nosniff");
    headers.set("Referrer-Policy", "strict-origin-when-cross-origin");
    headers.set(
      "Permissions-Policy",
      "geolocation=(), camera=(), microphone=()",
    );
    return new Response(response.body, {
      status: response.status,
      statusText: response.statusText,
      headers,
    });
  },
};
