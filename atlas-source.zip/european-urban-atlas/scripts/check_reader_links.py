#!/usr/bin/env python3
"""Audit current reader-edition source URLs; blocked/timeouts remain inconclusive."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from collections import Counter
from datetime import datetime,timezone
import json,sys
from check_links import check
ROOT=Path(__file__).resolve().parents[1]
refs={}
for file in (ROOT/'public/data/editorial').glob('*.json'):
 for city in json.loads(file.read_text())['cities']:
  for source in city['sources']:refs.setdefault(source['url'],[]).append(file.stem+'/'+city['id'])
results=[]
with ThreadPoolExecutor(max_workers=12)as pool:
 jobs={pool.submit(check,url,7):url for url in refs}
 for task in as_completed(jobs):
  r=task.result();r['cities']=refs[r['url']];results.append(r)
report={'checkedAt':datetime.now(timezone.utc).isoformat(),'counts':dict(Counter(r['result']for r in results)),'totalURLs':len(refs),'results':sorted(results,key=lambda r:r['url']),'note':'HTTP accessibility is not substantive verification. Blocked and timed-out sources are not treated as confirmed broken.'}
(ROOT/'docs/READER-SOURCE-LINKS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:report[k]for k in ['totalURLs','counts']},indent=2))
