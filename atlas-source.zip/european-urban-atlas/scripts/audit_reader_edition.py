#!/usr/bin/env python3
"""Audit the curated reader edition, its prose and its base-path-safe static output.

Default mode requires the final 60/51/50 city selection. --draft permits work in
progress and a stale or absent reader build, while preserving material data errors.
External source contents and browser interactions require separate human/agent QA.
"""
from __future__ import annotations
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit,urljoin,unquote
from urllib.request import Request,urlopen
from datetime import date,datetime,timezone
from collections import Counter,defaultdict
from itertools import combinations
from concurrent.futures import ThreadPoolExecutor,as_completed
import argparse,hashlib,json,math,re,statistics,sys,xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
COUNTRIES={'ES':('spain',60,19),'FR':('france',51,18),'IT':('italy',50,20)}
SECTIONS={'character','architecture','history','work','housing','neighborhoods','culture','food','transport','climate'}
RATINGS={'affordability','careers','transport','culture','social','outdoors','climate'}
BANNED=[r'\bresearch coverage\b',r'\bresearch foundation\b',r'\beditorial synthesis\b',r'\bmeasured statistical condition\b',r'\bdocumented public concern\b',r'\bgeographic baseline\b',r'\bclaim[- ]level\b',r'\bevidence ledger\b',r'\bcoverage tier\b',r'\breference period\b',r'\bfunctional urban relationship\b',r'\bread the units\b',r'\burban[- ]system\b',r'\bthis atlas\b',r'\bthe atlas\b',r'\bplaceholder\b',r'\blorem ipsum\b']
TOPICS=[
 ('Quick impression','summary',None),('Geography and city layout','overview',None),('Architecture and visual character','architecture',None),('What neighborhoods are like','neighborhoods',None),('Housing and cost tradeoffs','housing',None),('Work and careers','work',None),('Culture and things to do','culture',None),('Local food','food',None),('Important history','history',None),('Getting around','transport',None),('Weather through the year','climate',None),('Nature and outdoor time','outdoors',None),
 ('Student and university life',None,r'\bstudent\w*\b|\buniversit\w*\b|\bcampus\b'),('Families, schools and children',None,r'\bfamil(?:y|ies)\b|\bschool\w*\b|\bchildren\b'),('Nightlife and social opportunities',None,r'\bnightlife\b|\bbars?\b|\bclubs?\b|\bsocial\b|\bevenings?\b'),('Language and settling in',None,r'\blanguage\w*\b|\bspeak\w*\b|\blearn\w*\b|\bbilingual\b|\bsettling\b|\bsettle\b'),('Major suburbs and satellite cities','suburb',None),('Clear compromises','tradeoffs',None)]
ERRORS=[];WARNINGS=[];METRICS={};CHECKS={};CITY_FINDINGS=[]
def issue(code,message,location=None,warning=False):
 (WARNINGS if warning else ERRORS).append({'code':code,'message':message,'location':location})
def ensure(ok,code,message,location=None,warning=False):
 if not ok:issue(code,message,location,warning)
def read(path,default=None):
 try:return json.loads(path.read_text())
 except FileNotFoundError:return default
 except (ValueError,OSError) as exc:issue('invalid-json',str(exc),str(path));return default

def words(value):return re.findall(r"[\wÀ-ÿ]+(?:[’'-][\wÀ-ÿ]+)*",str(value),re.UNICODE)
def normalized(value):return ' '.join(re.findall(r'[\wÀ-ÿ]+',str(value).lower(),re.UNICODE))
def nonempty(value):return isinstance(value,str)and bool(value.strip())
def valid_url(value):
 try:
  u=urlsplit(value);return isinstance(value,str)and u.scheme in ('http','https')and bool(u.hostname)and not u.username and not u.password and not any(c.isspace()for c in value)
 except (ValueError,TypeError,AttributeError):return False

def point_in_ring(p,ring):
 x,y=p;inside=False
 for a,b in zip(ring,ring[1:]):
  ax,ay=a[:2];bx,by=b[:2]
  # Administrative borders and rounded coordinates can coincide exactly.
  cross=(x-ax)*(by-ay)-(y-ay)*(bx-ax)
  if abs(cross)<1e-8 and min(ax,bx)-1e-8<=x<=max(ax,bx)+1e-8 and min(ay,by)-1e-8<=y<=max(ay,by)+1e-8:return True
  if (ay>y)!=(by>y)and x<(bx-ax)*(y-ay)/(by-ay)+ax:inside=not inside
 return inside

def within(p,geometry):
 if geometry.get('type')=='Polygon':polys=[geometry['coordinates']]
 elif geometry.get('type')=='MultiPolygon':polys=geometry['coordinates']
 else:return False
 return any(point_in_ring(p,poly[0])and not any(point_in_ring(p,h)for h in poly[1:])for poly in polys if poly)

class Document(HTMLParser):
 def __init__(self):
  super().__init__(convert_charrefs=True);self.ids=set();self.duplicates=set();self.refs=[];self.images=[];self.heading1=0;self.text=[];self.details=[];self.options=[];self.selects=[];self.current_select=None;self.hidden_depth=0
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if a.get('id'):
   if a['id']in self.ids:self.duplicates.add(a['id'])
   self.ids.add(a['id'])
  if tag=='h1':self.heading1+=1
  if tag=='img':self.images.append(a)
  if tag=='details':self.details.append(a)
  if tag=='select':self.current_select=a;self.selects.append(a)
  if tag=='option':self.options.append((self.current_select,a.get('value','')))
  for key in ['href','src','poster','action']:
   if a.get(key):self.refs.append((a[key],tag,key))
  if a.get('srcset'):
   for entry in a['srcset'].split(','):
    if entry.strip():self.refs.append((entry.strip().split()[0],tag,'srcset'))
  if tag=='meta'and a.get('http-equiv','').lower()=='refresh':
   m=re.search(r';\s*url\s*=\s*(.*)',a.get('content',''),re.I)
   if m:self.refs.append((m[1].strip(' \"\''),tag,'refresh'))
 def handle_endtag(self,tag):
  if tag=='select':self.current_select=None
 def handle_data(self,data):self.text.append(data)

def audit_content(root,draft):
 countries=[];allcities=[];source_urls=set();paragraphs=defaultdict(list);topic_rows=[];regions_without=[]
 for cid,(slug,count,region_count)in COUNTRIES.items():
  path=root/'public/data/editorial'/f'{slug}.json';country=read(path)
  if not country:
   issue('missing-country',f'{slug} has no reader dataset',str(path),warning=draft);continue
  ensure(country.get('id')==cid and country.get('slug')==slug,'country-identity','Country ID or route slug does not match the maintained country',slug)
  cities=country.get('cities',[]);regions=country.get('regions',[])
  ensure(isinstance(cities,list)and isinstance(regions,list),'country-shape','cities and regions must be arrays',slug)
  if not isinstance(cities,list)or not isinstance(regions,list):continue
  ensure(len(cities)==count,'city-selection-count',f'Expected {count} curated cities, found {len(cities)}',slug,warning=draft)
  ensure(len(regions)==region_count,'region-count',f'Expected {region_count} regional jurisdictions, found {len(regions)}',slug,warning=draft)
  ensure(nonempty(country.get('summary')),'country-summary','Country needs a readable summary',slug)
  for pattern in BANNED:
   ensure(not re.search(pattern,country.get('summary',''),re.I),'meta-country-copy','Country introduction contains reader-facing methodology/status wording',slug)
  rby={r.get('id'):r for r in regions};cby={c.get('id'):c for c in cities}
  municipality_counts=Counter(c.get('municipalityId')for c in cities if c.get('municipalityId'))
  ensure(not any(v>1 for v in municipality_counts.values()),'duplicate-municipality-selection','Featured cities must not duplicate the same native municipality identifier',slug)
  ensure(len(rby)==len(regions),'duplicate-region','Duplicate regional IDs',slug);ensure(len(cby)==len(cities),'duplicate-city','Duplicate city IDs',slug)
  shape=read(root/'public/data/maps'/f'{slug}-regions.geojson',{})or{};features={str(f.get('properties',{}).get('id')):f for f in shape.get('features',[])}
  ensure(shape.get('type')=='FeatureCollection'and bool(features),'missing-region-map','A local regional boundary layer is required',slug)
  ensure(set(rby)<=set(features),'missing-region-geometry','Configured regions missing from packaged geometry: '+', '.join(sorted(set(rby)-set(features))),slug)
  missing_population=[];country_sentence_lengths=[];short=[];missing_specific=[];city_wordcounts=[];overview_wordcounts=[]
  for r in regions:
   rid=r.get('id');location=f'{slug}/region/{rid}'
   ensure(isinstance(rid,str)and nonempty(r.get('name')),'region-fields','Region IDs are native strings and names must be present',location)
   ensure(nonempty(r.get('summary'))and len(words(r.get('summary','')))>=35,'thin-region-summary','Regional summaries must describe the actual region, not be empty/placeholders',location)
   members=[c for c in cities if c.get('regionId')==rid]
   if not members:regions_without.append(location);issue('region-without-city','Each region needs a featured city and a map label',location,warning=draft)
   stated=r.get('cityIds',[])
   ensure(isinstance(stated,list)and set(stated)=={c.get('id')for c in members},'region-city-index','Region cityIds must match actual featured city relationships',location)
   for pattern in BANNED:
    ensure(not re.search(pattern,r.get('summary',''),re.I),'meta-region-copy','Region introduction contains methodology/status prose',location)
  for city in cities:
   key=f'{cid}:{city.get("id")}';loc=f'{slug}/city/{city.get("id")}'
   ensure(city.get('countryId')==cid,'city-country','Wrong country parent',loc)
   ensure(isinstance(city.get('id'),str)and re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*',city['id'])is not None,'city-route-id','City route ID must be a stable safe slug',loc)
   ensure(nonempty(city.get('name')),'city-name','City name is missing',loc)
   ensure(isinstance(city.get('aliases'),list)and all(isinstance(x,str)for x in city['aliases']),'city-aliases','Aliases must be a string array',loc)
   ensure(city.get('regionId')in rby,'city-region','City references an unknown region',loc)
   if city.get('regionId')in rby:ensure(city.get('regionName')==rby[city['regionId']]['name'],'city-region-name','Region name does not match region record',loc)
   coords=[city.get('lon'),city.get('lat')];finite=all(isinstance(v,(int,float))and not isinstance(v,bool)and math.isfinite(v)for v in coords)
   ensure(finite,'city-coordinates','Coordinates must be finite numbers',loc)
   if finite:
    ensure(-180<=coords[0]<=180 and -90<=coords[1]<=90,'coordinate-range','Coordinates outside WGS84 longitude/latitude range',loc)
    feature=features.get(city.get('regionId'))
    if feature:ensure(within(coords,feature['geometry']),'city-outside-region','Map point lies outside its stated regional polygon',loc,warning=True)
   ensure(city.get('size')in ('major','regional','suburb'),'city-size','Use major/regional/suburb selection types',loc)
   ensure(isinstance(city.get('goodFor'),list)and len(city['goodFor'])>=2 and all(nonempty(v)for v in city['goodFor']),'city-fit','Provide at least two useful reasons to choose the city',loc)
   ensure(isinstance(city.get('tradeoffs'),list)and len(city['tradeoffs'])>=1 and all(nonempty(v)for v in city['tradeoffs']),'city-tradeoffs','Provide a clear compromise',loc)
   summary=city.get('summary','');ensure(nonempty(summary)and 25<=len(words(summary))<=115,'city-summary','Top summaries should be concise complete descriptions, about25–115words',loc)
   overview=city.get('overview',[])
   ensure(isinstance(overview,list)and len(overview)>=2 and all(nonempty(p)for p in overview),'city-overview','Every city needs a general overview after the short opening',loc)
   overview_text=' '.join(overview)if isinstance(overview,list)else''
   overview_words=len(words(overview_text));overview_wordcounts.append(overview_words)
   ensure(overview_words>=100,'thin-city-overview','The general overview must explain the actual geography and urban layout',loc)
   for paragraph in overview if isinstance(overview,list)else[]:
    token=normalized(paragraph);paragraphs['overview'].append((key,paragraph,set(token.split()),token))
    for sentence in re.split(r'(?<=[.!?])\s+',paragraph):
     if sentence.strip():country_sentence_lengths.append(len(words(sentence)))
   population=city.get('population')
   if population is None:missing_population.append(city.get('id'))
   elif isinstance(population,dict):
    value=population.get('value');year=population.get('year')
    ensure(isinstance(value,(int,float))and not isinstance(value,bool)and math.isfinite(value)and value>0,'population-value','Known population must be positive and finite; unknown is null',loc)
    ensure(isinstance(year,int)and 1900<=year<=2026,'population-year','Population needs an actual reference year',loc)
    ensure(nonempty(population.get('unit'))and valid_url(population.get('sourceUrl')),'population-metadata','Population needs a geographic unit and genuine source URL',loc)
    if valid_url(population.get('sourceUrl')):source_urls.add(population['sourceUrl'])
   else:issue('population-shape','Population must be a definition-bearing object or null',loc)
   ss=city.get('sources',[]);ensure(isinstance(ss,list)and len(ss)>=1,'city-sources','Every city needs real source references',loc)
   sourceby={s.get('id'):s for s in ss if isinstance(s,dict)}
   ensure(len(sourceby)==len(ss),'duplicate-local-source','Source IDs must be unique inside each city bibliography',loc)
   for source in ss:
    ensure(all(nonempty(source.get(k))for k in ['id','title','publisher']),'source-fields','Source needs ID/title/publisher',loc)
    ensure(valid_url(source.get('url')),'source-url','Source URL must be an absolute HTTP(S) URL without credentials',loc)
    if valid_url(source.get('url')):source_urls.add(source['url'])
    accessed=source.get('accessed')
    try:date.fromisoformat(accessed)
    except (ValueError,TypeError):issue('source-access-date','Source accessed date must be an ISO calendar date',loc)
   sections=city.get('sections',[]);sectionby={s.get('id'):s for s in sections if isinstance(s,dict)}
   ensure(set(sectionby)==SECTIONS and len(sections)==10,'city-content-sections','Each city needs all ten actual reading categories, including architecture, without duplicates',loc)
   body=[];section_lengths={}
   for section in sections:
    ensure(nonempty(section.get('title')),'section-title','Reading sections need ordinary descriptive headings',loc)
    ps=section.get('paragraphs',[])
    ensure(isinstance(ps,list)and len(ps)>=1 and all(nonempty(p)for p in ps),'empty-section','No empty or placeholder section paragraphs',loc)
    text=' '.join(ps)if isinstance(ps,list)else'';body.append(text);section_lengths[section.get('id')]=len(words(text))
    ensure(len(words(text))>=10,'empty-depth','A category needs a meaningful summary, not a few label words',loc+'/'+str(section.get('id')))
    if len(words(text))<20:short.append(loc+'/'+str(section.get('id')))
    ids=section.get('sourceIds',[])
    ensure(isinstance(ids,list)and bool(ids)and all(x in sourceby for x in ids),'section-source-reference','Each section needs valid background source IDs',loc+'/'+str(section.get('id')))
    for paragraph in ps:
     token=normalized(paragraph)
     if len(words(paragraph))>=22:paragraphs[section.get('id')].append((key,paragraph,set(token.split()),token))
     for sentence in re.split(r'(?<=[.!?])\s+',paragraph):
      if sentence.strip():country_sentence_lengths.append(len(words(sentence)))
   architecture=sectionby.get('architecture',{})
   ensure(len(words(' '.join(architecture.get('paragraphs',[]))))>=100,'thin-architecture','Architecture needs specific buildings, materials, street scale and visual atmosphere',loc)
   text=summary+' '+overview_text+' '+' '.join(body)
   for pattern in BANNED:
    if re.search(pattern,text,re.I):issue('reader-meta-language','Remove public methodology/status prose matching '+pattern,loc)
   for pattern in [r'\bfoster\b',r'\bleverage\b',r'\bdelve\b',r'\bmultifaceted tapestry\b']:
    if re.search(pattern,text,re.I)and(pattern!=r'\bfoster\b'or re.search(pattern,text)):issue('reader-style','Canned or unnatural wording: '+pattern,loc,warning=True)
   total=len(words(' '.join(body)));city_wordcounts.append(total)
   ensure(total+overview_words>=500,'thin-city-profile','Expanded city pages need substantial readable detail beyond the opening',loc)
   # Named local details matter more than an empty nine-heading template.
   neighbor=' '.join(sectionby.get('neighborhoods',{}).get('paragraphs',[]));food=' '.join(sectionby.get('food',{}).get('paragraphs',[]))
   named=re.findall(r'\b[A-ZÀ-ÖØ-Þ][\wÀ-ÿ’\'-]*(?:\s+(?:de|del|la|di|du|des|le|Les|La|El|San|Santa|[A-ZÀ-ÖØ-Þ][\wÀ-ÿ’\'-]*))*',neighbor)
   named=[x for x in named if x not in ['The','A','An','It','Its','In','For','Some','Other','Central','Most','Many','Each']]
   if len(named)<2:missing_specific.append(loc)
   ensure(len(words(food))>=15,'thin-food-summary','Food section needs specific useful content',loc)
   ratings=city.get('ratings',{});ensure(isinstance(ratings,dict)and set(ratings)==RATINGS,'category-ratings','Exactly seven explained editorial category scores are required',loc)
   for category,rating in ratings.items():
    score=rating.get('score');desc=rating.get('summary')
    ensure(isinstance(score,int)and not isinstance(score,bool)and 1<=score<=5,'score-range','Category score must be an integer from1to5',loc+'/'+category)
    ensure(nonempty(desc)and len(words(desc))>=10,'score-explanation','Every category score needs a substantive city-specific explanation',loc+'/'+category)
    ensure(not re.search(r'\b(?:universal|objective|scientifically proven)\s+(?:score|ranking)',desc or'',re.I),'false-rating-certainty','Editorial scores cannot be presented as objective measurement',loc+'/'+category)
   ensure(not any(k in city for k in ['overallScore','livabilityScore','overallRating']),'overall-score','Do not average subjective categories into an arbitrary overall score',loc)
   CITY_FINDINGS.append({'city':key,'name':city.get('name'),'region':city.get('regionId'),'sectionWords':total,'overviewWords':overview_words,'summaryWords':len(words(summary)),'sourceCount':len(ss),'sectionWordsByCategory':section_lengths,'namedNeighborhoodSignals':named[:8]})
   allcities.append(city)
  if missing_population:issue('population-not-published',f'{len(missing_population)} cities omit unknown population rather than inventing it',slug,warning=True)
  if short:issue('very-brief-sections',f'{len(short)} category summaries are under20words; review for useful substance',short[:12],warning=True)
  if missing_specific:issue('neighborhood-specificity','Review whether the neighborhood paragraph names enough actual places',missing_specific,warning=True)
  avg=statistics.mean(country_sentence_lengths)if country_sentence_lengths else 0
  if avg>23:issue('long-sentences',f'Average sentence length is{avg:.1f}words; simplify the reading prose',slug,warning=True)
  METRICS[cid]={'cities':len(cities),'regions':len(regions),'sectionWords':sum(city_wordcounts),'overviewWords':sum(overview_wordcounts),'readingWords':sum(city_wordcounts)+sum(overview_wordcounts),'shortestSectionProfileWords':min(city_wordcounts)if city_wordcounts else 0,'longestSectionProfileWords':max(city_wordcounts)if city_wordcounts else 0,'meanWordsPerSentence':round(avg,1),'medianWordsPerSentence':statistics.median(country_sentence_lengths)if country_sentence_lengths else 0,'longestSentenceWords':max(country_sentence_lengths)if country_sentence_lengths else 0,'unknownPopulations':len(missing_population),'suburbs':sum(c.get('size')=='suburb'for c in cities)}
  topiccounts={}
  for label,field,pattern in TOPICS:
   n=0
   for city in cities:
    full=city.get('summary','')+' '+' '.join(city.get('overview',[]))+' '+' '.join(' '.join(s.get('paragraphs',[]))for s in city.get('sections',[]))+' '+' '.join(r.get('summary','')for r in city.get('ratings',{}).values())
    if field=='summary':ok=nonempty(city.get('summary'))
    elif field=='overview':ok=isinstance(city.get('overview'),list)and len(city['overview'])>=2
    elif field=='outdoors':ok=nonempty(city.get('ratings',{}).get('outdoors',{}).get('summary'))
    elif field=='suburb':ok=city.get('size')=='suburb'
    elif field=='tradeoffs':ok=bool(city.get('tradeoffs'))
    elif field:ok=any(s.get('id')==field and s.get('paragraphs')for s in city.get('sections',[]))
    else:ok=bool(re.search(pattern,full,re.I))
    n+=bool(ok)
   topiccounts[label]=n
  topic_rows.append({'country':country['name'],'cities':len(cities),'topics':topiccounts});countries.append(country)
 # Duplicate paragraphs expose mechanically copied guides; similar prose is highlighted for review.
 exact=[];near=[]
 for section,rows in paragraphs.items():
  grouped=defaultdict(list)
  for key,paragraph,tokens,text in rows:grouped[text].append(key)
  for text,ids in grouped.items():
   if len(set(ids))>1:exact.append({'section':section,'cities':sorted(set(ids)),'text':text[:260]})
  for a,b in combinations(rows,2):
   if a[0]==b[0]or a[3]==b[3]:continue
   union=a[2]|b[2];similarity=len(a[2]&b[2])/len(union)if union else 0
   if similarity>=0.8:near.append({'section':section,'cities':[a[0],b[0]],'wordSetSimilarity':round(similarity,3)})
 if exact:issue('duplicated-reading-paragraphs','Reading paragraphs are reused verbatim across cities',exact[:15])
 if near:issue('similar-reading-paragraphs','Review similar paragraphs for generic or copied descriptions',sorted(near,key=lambda x:-x['wordSetSimilarity'])[:15],warning=True)
 METRICS['uniqueSourceURLs']=len(source_urls);METRICS['duplicateParagraphs']=len(exact);METRICS['similarParagraphPairs']=len(near);METRICS['allCities']=len(allcities)
 CHECKS['readingProse']='Top summary, general geographic overview, architecture and streets, actual category prose, named neighborhood signals, local food, compromises, sentence lengths and duplicate/similar paragraphs inspected.'
 CHECKS['sourceScope']='URLs, local source IDs, titles and dates validated structurally. This script does not verify every source’s content or HTTP availability.'
 CHECKS['scores']='Seven explained 1–5 editorial categories; no arbitrary overall score, missing price or salary figures are not fabricated.'
 return countries,allcities,topic_rows

def audit_built(root,countries,cities,draft):
 dist=root/'dist/client';atlaspath=dist/'data/atlas.json';atlas=read(atlaspath)
 if not atlas:
  issue('reader-build-missing','Build the curated reader edition before final validation',str(atlaspath),warning=draft);return
 expected_keys={f'{c["countryId"]}:{c["id"]}'for c in cities};actual={f'{c.get("countryId")}:{c.get("id")}':c for c in atlas.get('cities',[])}
 ensure(set(actual)==expected_keys,'stale-reader-build','Built client city selection differs from maintained reader content',warning=draft)
 for city in cities:
  key=f'{city["countryId"]}:{city["id"]}';built=actual.get(key)
  if not built:continue
  for field in ['summary','ratings','name','lat','lon','regionId','goodFor','tradeoffs']:
   ensure(built.get(field)==city.get(field),'stale-client-prose','Built client field differs from current city content',key+'/'+field,warning=draft)
  ensure(isinstance(built.get('url'),str),'missing-city-url','Client city needs a published route',key)
 for c in countries:
  featured=[x for x in actual.values()if x.get('countryId')==c['id']]
  largest=sorted(featured,key=lambda x:(x.get('population')or{}).get('value',0),reverse=True)[:10]
  expected_labels={x['id']for x in largest};labels={x['id']for x in featured if x.get('mapLabel')}
  ensure(labels==expected_labels,'top-ten-map-labels','Exactly the ten largest featured municipalities should have permanent labels; other cities use hover/tap cards',c['id'])
 ensure({k.get('id')for k in atlas.get('categories',[])}==RATINGS,'comparison-category-model','Client comparison must contain all seven categories')
 cfg=read(root/'.openai/github-pages.json',{})or{};base=cfg.get('base_path','').rstrip('/');origin=cfg.get('expected_url','https://atlas.invalid').rstrip('/');ownhost=urlsplit(origin).netloc
 pages={};routes={};external=set();checked=0;fragments=0
 def logical(relative):
  t='/'+relative
  return t[:-10]if t.endswith('index.html')else t
 def resolve(path):
  path=unquote(path)
  if base:
   if path==base:path='/'
   elif path.startswith(base+'/'):path=path[len(base):]
   else:return None,'outside-base-path'
  target=dist/path.lstrip('/')
  try:target.resolve().relative_to(dist.resolve())
  except ValueError:return None,'path-escape'
  if target.is_file():return target,None
  if (target/'index.html').is_file():return target/'index.html',None
  return None,'missing-target'
 for f in dist.rglob('*.html'):
  relative=f.relative_to(dist).as_posix();doc=Document()
  try:doc.feed(f.read_text())
  except (OSError,ValueError)as exc:issue('invalid-built-html',str(exc),relative);continue
  pages[relative]=doc;routes[relative]=logical(relative)
  ensure(not doc.duplicates,'duplicate-built-id','Duplicate IDs break section navigation: '+', '.join(sorted(doc.duplicates)),relative)
  if relative!='404.html'and'/directory/'not in relative:
   ensure(doc.heading1==1,'page-heading','Reading pages need one clear main heading',relative)
   ensure(any(s.get('aria-label')=='Choose country'for s in doc.selects),'country-dropdown','Every reading page needs the top country dropdown',relative)
  for image in doc.images:ensure('alt'in image,'image-alt','Images need descriptive or deliberately empty alt text',relative)
 for relative,doc in pages.items():
  route=routes[relative];weburl=origin+base+route
  for href,tag,attr in doc.refs:
   if href.startswith(('data:','blob:','mailto:','tel:')):continue
   if href.lower().startswith('javascript:'):issue('javascript-url','Use real links/buttons instead of javascript: URLs',relative);continue
   parsed=urlsplit(href)
   if parsed.scheme and parsed.scheme not in ('http','https'):continue
   if parsed.netloc and parsed.netloc!=ownhost:external.add(href);continue
   targeturl=urlsplit(urljoin(weburl,href));target,reason=resolve(targeturl.path);checked+=1
   ensure(target is not None,'broken-built-link',f'{tag}.{attr}={href}: {reason}',relative)
   if target and targeturl.fragment and target.suffix=='.html':
    fragments+=1;t=pages.get(target.relative_to(dist).as_posix())
    if t:ensure(unquote(targeturl.fragment)in t.ids,'broken-built-fragment','Missing section target: '+href,relative)
 # CSS imports/url() and JS chunk imports use their own file location, not the HTML page.
 for kind,pattern in [('css',r'(?:url\(\s*[\"\']?)([^\"\')]+)'),('js',r'(?:from\s*|import\s*\(\s*)[\"\'](\.{1,2}/[^\"\']+)[\"\']')]:
  for file in (dist/'assets').rglob('*.'+kind):
   content=file.read_text();fileurl=origin+base+'/'+file.relative_to(dist).as_posix()
   for match in re.finditer(pattern,content):
    href=match[1].strip()
    if href.startswith(('data:','blob:','#')):continue
    parsed=urlsplit(href)
    if parsed.netloc or parsed.scheme:continue
    targeturl=urlsplit(urljoin(fileurl,href));target,reason=resolve(targeturl.path);checked+=1
    ensure(target is not None,'broken-css-or-chunk',f'{href}: {reason}',str(file.relative_to(dist)))
 for country in countries:
  for city in country['cities']:
   relative=f'{country["slug"]}/cities/{city["id"]}/index.html';doc=pages.get(relative)
   ensure(doc is not None,'missing-city-route','Every featured city must have a direct reading page',relative,warning=draft)
   if not doc:continue
   ensure(any('city-sources'in x.get('class','').split()and 'open'not in x for x in doc.details),'sources-not-collapsed','Sources should be tucked into an expandable section',relative)
   ensure(any('city-scores'in x.get('class','').split()for x in doc.details),'city-category-summary','City category explanations should be available without crowding the reading text',relative)
   ensure('The short version'not in doc.text,'redundant-summary-label','The opening summary should not have a repeated short-version heading',relative)
   ensure(all(p in doc.text for p in city.get('overview',[])),'missing-city-overview','The general overview must be rendered before the reading sections',relative)
   targets={h for h,_,_ in doc.refs}
   ensure(all(s['url']in targets for s in city['sources']),'missing-profile-source-link','Profile bibliography is missing a real maintained source link',relative,warning=draft)
   for section in city['sections']:ensure(section['id']in doc.ids,'missing-reading-anchor','Reading category has no working anchor',relative+'#'+section['id'])
 compare=pages.get('compare/index.html');ensure(compare is not None,'comparison-page','The comparison page is required')
 if compare:ensure('compare-form'in compare.ids and 'compare-results'in compare.ids,'comparison-hooks','Comparison needs usable selection and result containers')
 app=(root/'src/app.ts').read_text();builder=(root/'scripts/build.py').read_text()
 for condition,message in [('function compareMarkup'in app,'Comparison renderer exists'),('c.summary'in app,'Comparison includes actual city summaries'),('ratings[category.id].summary'in app,'Comparison includes every category explanation'),('ratings[category.id].score'in app,'Comparison includes category scores'),('c.tradeoffs'in app,'Comparison includes the main compromises')]:
  ensure(condition,'comparison-implementation',message+'; inspect client implementation')
 ensure(not re.search(r'overallScore|overallRating|livabilityScore',app),'overall-score-implementation','Client must not manufacture an overall score')
 ensure('mapLabel'in app and 'mapLabel'in builder,'map-priority-implementation','Top-ten city labels need both generated data and client rendering')
 for old in ['municipalities.json','sources.json','claims.json']:
  if (dist/'data'/old).exists():issue('obsolete-public-catalogue','Legacy all-municipality/research export remains in the reader build',old,warning=True)
 sitemap=dist/'sitemap.xml'
 if sitemap.is_file():
  try:
   tree=ET.fromstring(sitemap.read_text());urls=[n.text for n in tree.findall('.//{*}loc')]
   for value in urls:
    target,reason=resolve(urlsplit(value).path);ensure(target is not None,'broken-sitemap-route',str(value)+': '+str(reason))
   METRICS['sitemapURLs']=len(urls)
  except ET.ParseError as exc:issue('invalid-sitemap',str(exc))
 else:issue('missing-sitemap','The public edition needs a sitemap')
 METRICS.update(htmlPages=len(pages),internalTargetsChecked=checked,fragmentLinksChecked=fragments,uniqueBuiltExternalURLs=len(external),basePath=base)
 CHECKS['staticLinks']='All built HTML links/assets/anchors, redirects, stylesheet url() imports and JavaScript chunks resolve under the configured GitHub Pages base path.'
 CHECKS['comparison']='Client data and source inspected for short summaries, seven scored-and-explained categories and compromises; live behavior remains a separate browser check.'
 CHECKS['maps']='Every regional boundary and featured city point is packaged. Exactly the ten largest featured municipalities per country carry permanent labels; others open hover/tap cards. Zoom scaling and marker anchoring require separate browser checks.'


def publish_check(root,require_public):
 config=read(root/'.openai/github-pages.json',{})or{};u=config.get('expected_site_url');record={'url':u,'checked':False,'live':False,'samples':[]}
 if not require_public:
  record['status']='Not requested by this invocation; public production must be verified separately.';return record
 if not valid_url(u):issue('public-url-missing','No verified hosting URL is configured');return record
 built_home=root/'dist/client/index.html';match=re.search(r'data-release="([^"]+)"',built_home.read_text())if built_home.exists()else None
 expected_release=match[1]if match else None
 expected_data=read(root/'dist/client/data/atlas.json')
 record['expectedRelease']=expected_release
 samples=[('', 'html'),('spain/','html'),('france/','html'),('italy/','html'),('spain/cities/madrid/','html'),('france/cities/paris/','html'),('italy/cities/rome/','html'),('assets/app.js','javascript'),('assets/style.css','css'),('assets/maplibre-gl.css','css'),('data/atlas.json','json')]
 def request_one(sample):
  path,kind=sample;target=u.rstrip('/')+'/'+path;item={'url':target,'kind':kind,'passed':False}
  try:
   with urlopen(Request(target,headers={'User-Agent':'EuropeanUrbanAtlas-ReleaseAudit/1.0'}),timeout=20)as response:
    body=response.read(1500000).decode('utf-8','replace');item.update(httpStatus=response.status,finalURL=response.geturl())
    valid=response.status==200
    if kind=='html':valid=valid and 'European Urban Atlas'in body and ('Choose country'in body or 'Choose a country'in body)and(not expected_release or f'data-release="{expected_release}"'in body)
    elif kind=='json':valid=valid and isinstance(json.loads(body),dict)and bool(json.loads(body).get('cities'))and(not expected_data or json.loads(body)==expected_data)
    else:valid=valid and len(body)>100 and '<html'not in body[:200].lower()
    item['passed']=valid
  except Exception as exc:item['error']=str(exc)
  return item
 with ThreadPoolExecutor(max_workers=6)as pool:
  for result in pool.map(request_one,samples):record['samples'].append(result)
 record['checked']=True;record['live']=all(x['passed']for x in record['samples'])
 for result in record['samples']:ensure(result['passed'],'public-site-unverified','Public route/asset did not serve the expected reader edition without authentication',result['url'])
 return record


def markdown(report,topics):
 m=report['metrics'];lines=['# Reader edition audit','','This audit checks the revised city-selection, writing and comparison requirements. The previous all-municipality completion target is superseded by the user’s curated city scope.','',f"Result: **{'PASS' if report['passed'] else 'NEEDS FIXES'}** · {len(report['errors'])} material errors · {len(report['warnings'])} review notes.",'',f"Mode: {'draft/in-progress'if report['draft']else'final selection'}. Built site checked: {'yes'if report['builtChecked']else'no — content-only run'}. Generated {report['generatedAt']}.",'','## What a reader may look for','','The matrix checks actual summaries, named categories or text signals. A mention is not a guarantee of suitability. Family/student/language topics vary by place rather than being filled with invented advice.','', '| Reader interest | '+' | '.join(x['country']for x in topics)+' |','|---|'+'---|'*len(topics)]
 for label,_,_ in TOPICS:lines.append('| '+label+' | '+' | '.join(str(x['topics'].get(label,0))+'/'+str(x['cities'])for x in topics)+' |')
 lines+=['','## Previous edition review','','The first edition overemphasized administrative completeness and audit language. Its abstract thesis statements did not give readers a useful quick impression, and its short notes did not cover the practical categories consistently. The revised checks specifically address those defects.','','- The public selection is curated cities and major suburbs; the exhaustive municipality catalog is no longer the browsing experience.','- A concise plain-language summary appears before the detailed reading sections.','- Each city has a geographic overview plus sections on character, architecture, history, work, housing, actual neighborhoods, culture, food, transport and climate.','- Sources and score explanations remain accessible in collapsed disclosures, without evidence classifications interrupting the prose.','- Comparison uses the real city summaries plus seven explained category ratings and clear compromises.','- In-page country selection and top-ten city labels are tested explicitly; deployment requires separate public access verification.','','## Writing and selection','','| Country | Cities | Regions | Section words | Mean sentence length |','|---|---:|---:|---:|---:|']
 for cid in COUNTRIES:
  if cid in m:
   v=m[cid];lines.append(f'| {cid} | {v["cities"]} | {v["regions"]} | {v["sectionWords"]:,} | {v["meanWordsPerSentence"]} words |')
 lines+=['',f"Exact duplicate reading paragraphs: {m.get('duplicateParagraphs',0)}. Similar paragraph pairs flagged: {m.get('similarParagraphPairs',0)}.",'','The content checks require ten real sections, a general overview, a short top summary, named neighborhood signals, actual food discussion, seven explained category scores, sources and clear compromises. Unknown financial or population values are allowed to remain unknown.','', '## Navigation, maps and comparison','']
 for k in ['staticLinks','maps','comparison','scores']:
  if k in report['checks']:lines.append('- '+report['checks'][k])
 lines+=['',f"HTML pages: {m.get('htmlPages','not checked')}. Internal targets: {m.get('internalTargetsChecked','not checked')}. Section fragments: {m.get('fragmentLinksChecked','not checked')}. Hosting base path: `{m.get('basePath','not checked')}`.",'','Country dropdowns, direct city routes, source disclosure controls and image alternatives are checked in the built documents. Browser gestures, layout, keyboard use and the live comparison still require the separate browser audit.','', '## Material findings','']
 if report['errors']:
  for x in report['errors'][:50]:lines.append(f'- **{x["code"]}**: {x["message"]}'+(f' — {x["location"]}'if x.get('location')else''))
  if len(report['errors'])>50:lines.append(f'- {len(report["errors"])-50} additional findings are recorded in READER-AUDIT.json.')
 else:lines.append('No material structural/content defects were found by this run.')
 lines+=['','## Review notes','']
 if report['warnings']:
  for x in report['warnings'][:50]:lines.append(f'- **{x["code"]}**: {x["message"]}'+(f' — {x["location"]}'if x.get('location')else''))
 else:lines.append('No additional automated review notes.')
 lines+=['','## Public access','',f"Public URL: {report['publication'].get('url')}. Checked: {report['publication'].get('checked')}. All sampled routes passed: {report['publication'].get('live')}.", '', 'A successful static audit is not evidence of public publication. Use `--require-public` after deploying, and open the actual production URL in an ordinary browser.','', '## Limits','','This is a content and implementation audit, not a statistical certification of subjective ratings or a claim that every linked source was available. It does not invent prices, salaries, quotations, resident opinions or current construction status. Source HTTP checks and substantive fact review remain separate. The complete JSON report contains per-city section lengths, named-detail signals and every finding.','']
 return'\n'.join(lines)


def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--root',type=Path,default=ROOT);parser.add_argument('--draft',action='store_true');parser.add_argument('--skip-built',action='store_true');parser.add_argument('--require-public',action='store_true');args=parser.parse_args()
 countries,cities,topics=audit_content(args.root,args.draft)
 if not args.skip_built:audit_built(args.root,countries,cities,args.draft)
 publication=publish_check(args.root,args.require_public)
 report={'generatedAt':datetime.now(timezone.utc).isoformat(),'referenceDate':'2026-11-07','draft':args.draft,'passed':not ERRORS,'builtChecked':'staticLinks'in CHECKS,'errors':ERRORS,'warnings':WARNINGS,'metrics':METRICS,'checks':CHECKS,'readerInterests':topics,'cityFindings':CITY_FINDINGS,'publication':publication,'scope':'Curated60Spanish/51French/50Italian city reader edition; exhaustive municipal cataloguing is not required.'}
 (args.root/'docs').mkdir(parents=True,exist_ok=True);(args.root/'docs/READER-AUDIT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');(args.root/'docs/READER-AUDIT.md').write_text(markdown(report,topics))
 print(json.dumps({'passed':report['passed'],'draft':args.draft,'errors':len(ERRORS),'warnings':len(WARNINGS),'metrics':METRICS,'firstErrors':ERRORS[:12]},ensure_ascii=False,indent=2));return 0 if report['passed']else 1
if __name__=='__main__':sys.exit(main())
