#!/usr/bin/env python3
"""Validate maintained content, official geography, normalized schemas and every built link.
Standard library only. Run after the production build; writes docs/VALIDATION.json.
Exit 1 means material errors. Warnings preserve research limitations without disguising them.
"""
from pathlib import Path
from collections import Counter,defaultdict
from datetime import date,datetime,timezone
from html.parser import HTMLParser
from urllib.parse import urlsplit,urljoin,unquote
import argparse,hashlib,importlib.util,json,math,posixpath,re,sys,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
REFERENCE_DATE=date(2026,11,7)
ERRORS=[];WARNINGS=[];CHECKS={};METRICS={}
def issue(code,message,location=None,severity='error'):
 (ERRORS if severity=='error' else WARNINGS).append(dict(code=code,message=message,location=location))
def ensure(condition,code,message,location=None):
 if not condition:issue(code,message,location)
 return bool(condition)
def read(path):
 try:return json.loads(Path(path).read_text(encoding='utf-8'))
 except Exception as ex:issue('invalid-json',str(ex),str(path));return None
def nonempty(x):return isinstance(x,str) and bool(x.strip())
def valid_url(u):
 if not nonempty(u) or any(c.isspace() or ord(c)<32 for c in u):return False
 try:
  p=urlsplit(u);return p.scheme in ('https','http') and bool(p.hostname) and p.username is None and p.password is None
 except ValueError:return False
def date_check(value,loc,allow_null=False):
 if value is None and allow_null:return
 try:
  ensure(isinstance(value,str) and re.fullmatch(r'\d{4}-\d{2}-\d{2}',value) is not None,'date-format','Expected exact ISO date or explicitly allowed null',loc)
  d=date.fromisoformat(value)
  ensure(d<=REFERENCE_DATE,'future-date','Research/publication/edit date is later than the release research date',loc)
 except (ValueError,TypeError):issue('invalid-date',repr(value),loc)
def unique(rows,label):
 ids=[r.get('id') for r in rows if isinstance(r,dict)]
 for i,n in Counter(ids).items():
  if i is None or not nonempty(i):issue('missing-id','Expected a non-empty string ID',label)
  if n>1:issue('duplicate-id',f'{i}: {n} occurrences',label)
 return {r['id']:r for r in rows if isinstance(r,dict) and 'id'in r}
def each_ref(obj,key):
 if isinstance(obj,dict):
  for k,v in obj.items():
   if k==key:
    yield from (v if isinstance(v,list) else [v])
   else:yield from each_ref(v,key)
 elif isinstance(obj,list):
  for v in obj:yield from each_ref(v,key)
def schema_validate(value,schema,root,path='$'):
 """Implement precisely the validation keywords used by the two bundled schemas.
 This is not advertised as a general-purpose JSON Schema implementation.
 """
 out=[]
 if '$ref' in schema:
  target=root
  if not schema['$ref'].startswith('#/'):return [path+': unsupported external schema reference']
  for key in schema['$ref'][2:].split('/'):target=target[key.replace('~1','/').replace('~0','~')]
  return schema_validate(value,target,root,path)
 if 'oneOf'in schema:
  matches=[schema_validate(value,s,root,path) for s in schema['oneOf']]
  if sum(not x for x in matches)!=1:
   best=min(matches,key=len);out.append(path+': oneOf did not match exactly one alternative');out.extend(best[:10])
  return out
 expected=schema.get('type')
 typemap={'object':lambda v:isinstance(v,dict),'array':lambda v:isinstance(v,list),'string':lambda v:isinstance(v,str),'number':lambda v:isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v),'integer':lambda v:isinstance(v,int) and not isinstance(v,bool),'boolean':lambda v:isinstance(v,bool),'null':lambda v:v is None}
 if expected and not any(typemap[t](value) for t in (expected if isinstance(expected,list) else [expected])):return [path+': invalid type; expected '+str(expected)]
 if 'const'in schema and value!=schema['const']:out.append(path+': const mismatch')
 if 'enum'in schema and value not in schema['enum']:out.append(path+': enum mismatch')
 if isinstance(value,str):
  if len(value)<schema.get('minLength',0):out.append(path+': string too short')
  if 'pattern'in schema and not re.search(schema['pattern'],value):out.append(path+': pattern mismatch')
  if schema.get('format')=='date':
   try:date.fromisoformat(value)
   except ValueError:out.append(path+': invalid date')
  if schema.get('format')=='uri' and not valid_url(value):out.append(path+': invalid HTTP(S) URI')
 if isinstance(value,(int,float)) and not isinstance(value,bool):
  if 'minimum'in schema and value<schema['minimum']:out.append(path+': below minimum')
  if 'maximum'in schema and value>schema['maximum']:out.append(path+': above maximum')
 if isinstance(value,list):
  if len(value)<schema.get('minItems',0):out.append(path+': not enough items')
  if schema.get('uniqueItems') and len({json.dumps(v,sort_keys=True) for v in value})!=len(value):out.append(path+': duplicate array values')
  for i,v in enumerate(value):
   if 'items'in schema:out.extend(schema_validate(v,schema['items'],root,f'{path}[{i}]'))
 if isinstance(value,dict):
  for k in schema.get('required',[]):
   if k not in value:out.append(path+': missing '+k)
  props=schema.get('properties',{})
  for k,v in value.items():
   if k in props:out.extend(schema_validate(v,props[k],root,path+'.'+k))
   elif schema.get('additionalProperties') is False:out.append(path+': unexpected property '+k)
   elif isinstance(schema.get('additionalProperties'),dict):out.extend(schema_validate(v,schema['additionalProperties'],root,path+'.'+k))
 return out
class PageParser(HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=True);self.ids=[];self.refs=[];self.title=False;self.main=False;self.lang=False
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if a.get('id'):self.ids.append(a['id'])
  if tag=='a' and a.get('name'):self.ids.append(a['name'])
  if tag=='title':self.title=True
  if tag=='main':self.main=True
  if tag=='html' and a.get('lang'):self.lang=True
  for attr in ('href','src','poster','action'):
   if a.get(attr):self.refs.append((a[attr],tag,attr))
  if a.get('srcset'):
   for item in a['srcset'].split(','):
    parts=item.strip().split()
    if parts:self.refs.append((parts[0],tag,'srcset'))
 def handle_startendtag(self,tag,attrs):self.handle_starttag(tag,attrs)
def geometry_checks(path,idkey,expected_ids=None,municipal_by=None):
 d=read(path)
 if not d:return
 ensure(d.get('type')=='FeatureCollection','geometry-type','Expected FeatureCollection',str(path))
 seen=[]
 def coords(v):
  if isinstance(v,list) and len(v)>=2 and all(isinstance(a,(int,float)) for a in v[:2]):
   if not(all(math.isfinite(x) for x in v[:2]) and -180<=v[0]<=180 and -90<=v[1]<=90):issue('geometry-coordinate','Invalid longitude/latitude',str(path))
  elif isinstance(v,list):
   for a in v:coords(a)
 def in_ring(point,ring):
  x,y=point;inside=False
  for a,b in zip(ring,ring[1:]):
   dx,dy=b[0]-a[0],b[1]-a[1]
   if abs((x-a[0])*dy-(y-a[1])*dx)<1e-8 and min(a[0],b[0])-1e-6<=x<=max(a[0],b[0])+1e-6 and min(a[1],b[1])-1e-6<=y<=max(a[1],b[1])+1e-6:return True
   if (a[1]>y)!=(b[1]>y) and x<(b[0]-a[0])*(y-a[1])/(b[1]-a[1])+a[0]:inside=not inside
  return inside
 for f in d.get('features',[]):
  fid=str(f.get('properties',{}).get(idkey,''));seen.append(fid);g=f.get('geometry')
  if not g or g.get('type')not in ('Polygon','MultiPolygon'):issue('missing-geometry','Expected polygon geometry for '+fid,str(path));continue
  coords(g.get('coordinates'))
  polygons=g['coordinates']if g['type']=='MultiPolygon'else[g['coordinates']]
  for poly in polygons:
   for ring in poly:ensure(len(ring)>=4 and ring[0]==ring[-1],'polygon-ring','Polygon ring must have at least four positions and be closed',str(path)+'#'+fid)
  if municipal_by and fid in municipal_by:
   m=municipal_by[fid];point=(m['lon'],m['lat'])
   ensure(any(poly and in_ring(point,poly[0])and not any(in_ring(point,hole)for hole in poly[1:])for poly in polygons),'municipal-point-outside-boundary','Representative point is outside its packaged municipality polygon',fid)
 if len(seen)!=len(set(seen)):issue('duplicate-boundary','Duplicate geometry ID',str(path))
 if expected_ids is not None:ensure(set(seen)==set(expected_ids),'boundary-inventory-mismatch',f'Missing {len(set(expected_ids)-set(seen))}; extra {len(set(seen)-set(expected_ids))}',str(path))
 METRICS['boundaryFeatures']=METRICS.get('boundaryFeatures',0)+len(seen)
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--root',type=Path,default=ROOT);ap.add_argument('--output',type=Path);ap.add_argument('--skip-built',action='store_true');args=ap.parse_args()
 root=args.root.resolve();data=root/'public/data';geo=data/'geography';dist=root/'dist/client'
 loaded={p.name:read(p) for p in data.glob('*.json')}
 municipalities=read(geo/'municipalities.json')or[];regions=read(geo/'regions.json')or[];provinces=read(geo/'provinces.json')or[];islands=read(geo/'islands.json')or[];fuas=read(geo/'functional-urban-areas.json')or[];provenance=read(geo/'provenance.json')or{}
 muni=unique(municipalities,'municipalities');reg=unique(regions,'geographic regions');prov=unique(provinces,'provinces');isl=unique(islands,'islands');fua=unique(fuas,'functional urban areas')
 ensure(len(muni)==8132,'municipal-count','Expected dated INE inventory of 8,132 municipalities')
 ensure(set(reg)=={f'{x:02d}'for x in range(1,20)},'region-id-set','Expected official region codes 01–19')
 ensure(set(prov)=={f'{x:02d}'for x in range(1,53)},'province-id-set','Expected codes 01–52 including autonomous-city statistical references')
 ensure(sum(x.get('type')=='province'for x in provinces)==50,'province-kind-count','Expected 50 provinces')
 ensure(sum(x.get('type')=='autonomous-community'for x in regions)==17,'community-kind-count','Expected 17 autonomous communities')
 for r in regions:ensure(r['type']==('autonomous-city'if r['id']in('18','19')else'autonomous-community'),'region-kind','Incorrect autonomous-city classification',r['id'])
 for p in provinces:
  ensure(p.get('regionId')in reg,'broken-admin-reference','Province references unknown region',p['id'])
  ensure(p.get('type')==('autonomous-city'if p['id']in('51','52')else'province'),'province-kind','Incorrect province/autonomous-city classification',p['id'])
 for m in municipalities:
  mid=m['id'];ensure(re.fullmatch(r'\d{5}',mid)is not None,'municipality-id-format','Expected string five-digit INE municipality ID',mid)
  ensure(m.get('provinceId')==mid[:2] and m.get('provinceId')in prov,'municipality-province','Municipality code/province mismatch',mid)
  if m.get('provinceId')in prov:ensure(m.get('regionId')==prov[m['provinceId']]['regionId'],'municipality-region','Municipality/province/region mismatch',mid)
  ensure(m.get('countryId')=='ES'and nonempty(m.get('name')),'municipality-required','Missing official name or country',mid)
  ensure(isinstance(m.get('aliases'),list)and all(isinstance(a,str)for a in m['aliases']),'municipality-aliases','Aliases must be string array',mid)
  ensure(all(isinstance(m.get(k),(int,float))and not isinstance(m.get(k),bool)and math.isfinite(m[k])for k in ('lat','lon')),'municipality-coordinate-type','Missing coordinate',mid)
  if all(isinstance(m.get(k),(int,float))for k in('lat','lon')):ensure(-90<=m['lat']<=90 and -180<=m['lon']<=180,'municipality-coordinate-range','Invalid coordinate range',mid)
  ensure(isinstance(m.get('population'),int)and not isinstance(m.get('population'),bool)and m['population']>=0,'municipality-population','Expected nonnegative official population',mid)
  ensure(m.get('populationYear')==2025 and m.get('populationSourceId')=='ine-population-29005','municipality-population-period','Expected explicit INE Padrón 2025 source',mid)
  for f in m.get('functionalUrbanAreaIds',[]):ensure(f in fua,'fua-reference','Unknown functional urban area',mid)
  if m.get('islandAdministrativeUnitId'):ensure(m['islandAdministrativeUnitId']in isl,'island-reference','Unknown island administration',mid)
 # Compare against the independent cached official inventory and population extraction.
 cache=root/'reference/official';dictionary=read(cache/'ine-municipality-dictionary-2026.json') if(cache/'ine-municipality-dictionary-2026.json').exists()else None;pop=read(cache/'ine-municipality-population-2025.json')if(cache/'ine-municipality-population-2025.json').exists()else None
 if dictionary:
  ensure(set(dictionary)==set(muni),'official-code-equality','Maintained municipality codes differ from cached INE2026 inventory')
  for mid,m in muni.items():
   if mid in dictionary:
    ensure(m['name']==dictionary[mid]['name'],'official-name-equality','Name differs from INE2026 official dictionary',mid)
    ensure(m['regionId']==dictionary[mid]['regionId'],'official-region-equality','Region differs from official dictionary',mid)
  CHECKS['officialDictionary']='All codes, names and first-level relationships compared with cached INE2026 extraction'
 else:issue('official-cache-absent','Official dictionary cache absent; inventory independently attested in provenance but not rechecked','geography',severity='warning')
 if pop:
  for mid,m in muni.items():
   ensure(mid in pop,'official-population-missing','No cached official population record',mid)
   if mid in pop:ensure(m['population']==pop[mid]['population']and m['populationYear']==pop[mid]['populationYear'],'official-population-equality','Population differs from cached INE series',mid)
  CHECKS['officialPopulation']='All 8,132 values and reference years compared with cached INE Padrón extraction'
 else:issue('population-cache-absent','Official population cache absent; values not independently re-compared','geography',severity='warning')
 for rows,key in [(regions,'regionId'),(provinces,'provinceId')]:
  for item in rows:
   children=[m for m in municipalities if m[key]==item['id']]
   ensure(item.get('municipalityCount')==len(children),'aggregate-municipal-count','Aggregate municipality count mismatch',item['id'])
   ensure(item.get('population')==sum(m['population']for m in children),'aggregate-population','Aggregate population mismatch',item['id'])
   ensure(nonempty(item.get('populationDefinition'))and item.get('populationYear')==2025,'aggregate-definition','Aggregate lacks explicit comparable population definition',item['id'])
 island_members=set()
 for i in islands:
  ensure(i.get('regionId')in reg and i.get('provinceId')in prov,'island-admin','Unknown island administrative relationship',i['id'])
  for mid in i.get('municipalityIds',[]):
   ensure(mid in muni,'island-member','Unknown municipality',i['id'])
   if mid in muni:ensure(muni[mid]['regionId']==i['regionId']and muni[mid]['provinceId']==i['provinceId'],'island-member-admin','Island member administrative mismatch',mid)
   if i.get('type')=='island-administrative-unit':
    ensure(mid not in island_members,'island-duplicate-member','Municipality belongs to more than one primary island administration',mid);island_members.add(mid)
  if i.get('administeredById'):ensure(i['administeredById']in isl,'island-admin-reference','Unknown administering island',i['id'])
 for f in fuas:
  ensure(nonempty(f.get('membershipMethod')),'fua-method','Computed FUA links require explicit method',f['id'])
  for mid in f.get('municipalityIds',[]):
   ensure(mid in muni,'fua-member','Unknown municipality',f['id'])
   if mid in muni:ensure(f['id']in muni[mid].get('functionalUrbanAreaIds',[]),'fua-reciprocity','FUA memberships not reciprocal',mid)
 # Local essential polygons.
 geometry_checks(geo/'regions.geojson','id',reg);geometry_checks(geo/'provinces.geojson','id',prov)
 for pid in prov:geometry_checks(geo/f'municipalities-{pid}.geojson','id',[m['id']for m in municipalities if m['provinceId']==pid],muni)
 geometry_checks(geo/'functional-urban-areas.geojson','id',fua)
 for file in ['spain.geojson','europe.geojson','countries.geojson']:ensure((geo/file).is_file(),'essential-map-geometry','Missing locally packaged country geometry',file)
 METRICS.update(municipalities=len(muni),regions=len(reg),provinces=sum(x['type']=='province'for x in provinces),autonomousCities=2,islandRecords=len(isl),functionalUrbanAreas=len(fua),nationalMunicipalPopulation=sum(m['population']for m in municipalities))
 # Country-independent adapter and exact contract-schema validation.
 try:
  sys.path.insert(0,str(root/'scripts'));from geographic_contract import read_registry,registry_checks,load_country,validate_graph
  registry=read_registry(root)
  for err in registry_checks(registry,root):issue('country-registry',err)
  configschema=read(data/'country-config.schema.json');geoschema=read(data/'geographic-entities.schema.json')
  for err in schema_validate(registry,configschema,configschema):issue('country-config-schema',err)
  # Prefer an independently maintained standards implementation when the QA
  # dependency bundle is available. The explicit checks above remain portable.
  qa_libs=root.parent/'schema-qa-libs'
  if qa_libs.is_dir():sys.path.insert(0,str(qa_libs))
  independent=None
  try:
   from jsonschema import Draft202012Validator,FormatChecker
   Draft202012Validator.check_schema(configschema);Draft202012Validator.check_schema(geoschema)
   independent=(Draft202012Validator,FormatChecker)
   for err in Draft202012Validator(configschema,format_checker=FormatChecker()).iter_errors(registry):issue('independent-country-config-schema',err.message,str(list(err.absolute_path)))
   CHECKS['independentSchemaEngine']='jsonschema Draft202012Validator with FormatChecker; both bundled schemas checked against their metaschema'
  except ImportError:
   issue('independent-schema-engine-unavailable','Independent jsonschema library absent; explicit contract and bundled-keyword checks still run',severity='warning')
  for cfg in registry['countries']:
   if not cfg.get('enabled'):continue
   result=load_country(cfg['id'],root)
   for err in validate_graph(result['graph'],cfg,root):issue('geographic-graph',err)
   for err in schema_validate(result['graph'],geoschema,geoschema):issue('geographic-graph-schema',err)
   if independent:
    validator,checker=independent
    for err in validator(geoschema,format_checker=checker()).iter_errors(result['graph']):issue('independent-geographic-graph-schema',err.message,str(list(err.absolute_path)))
   declared={x['id']for x in cfg.get('sources',[])}|{provenance.get('id'),'gisco-nuts-2024'}|{x['id']for x in provenance.get('additionalSources',[])}
   for ref in each_ref(result['graph'],'sourceRefs'):ensure(ref in declared,'geographic-source-reference','Unknown geographic source '+str(ref))
   METRICS['normalizedGeographicEntities']=len(result['graph']['entities']);METRICS['normalizedRelationships']=len(result['graph']['relationships'])
  CHECKS['schemaEngine']='Standard-library implementation of every validation keyword used by the two bundled schemas, plus adapter graph validation; no external JSON Schema package required'
 except Exception as ex:issue('geographic-contract-exception',str(ex))
 # Editorial source and claim integrity.
 sources=(loaded.get('sources-cities.json')or[])+(loaded.get('sources-regions.json')or[]);claims=(loaded.get('claims-cities.json')or[])+(loaded.get('claims-regions.json')or[])
 source=unique(sources,'sources');claim=unique(claims,'claims');cityrows=loaded.get('cities.json')or[];editorialregions=loaded.get('regions.json')or[];country=loaded.get('country.json')or{}
 city=unique(cityrows,'city profiles');eregs=unique(editorialregions,'regional profiles');profiles=[country]+editorialregions+cityrows
 ensure(set(eregs)==set(reg),'regional-editorial-coverage','Every region/autonomous city must have a synthesis')
 geo_source_ids={provenance.get('id'),'gisco-nuts-2024'}|{x.get('id')for x in provenance.get('additionalSources',[])}
 for s in sources:
  loc=s['id']
  for field in['title','publisher','referencePeriod','findings','limitations','reliabilityNotes']:ensure(nonempty(s.get(field)),'source-required','Missing '+field,loc)
  ensure(valid_url(s.get('url')),'source-url','Source URL is not a well-formed HTTP(S) URL',loc)
  date_check(s.get('accessed',s.get('accessDate')),loc+'.accessed');date_check(s.get('publicationDate'),loc+'.publicationDate',allow_null=True)
  for field in['geographicCoverage','relevantSections']:ensure(isinstance(s.get(field),list),'source-scope','Expected '+field+' array',loc)
 used_sources=set();used_claims=set()
 for p in profiles:
  pid=p.get('id','unknown');date_check(p.get('updated'),pid+'.updated');date_check(p.get('researched'),pid+'.researched')
  if p.get('updated')and p.get('researched'):ensure(p['updated']>=p['researched'],'edit-before-research','Updated date predates research date',pid)
  ensure(nonempty(p.get('thesis'))and isinstance(p.get('limitations'),list)and bool(p['limitations']),'profile-required','Profile needs thesis and disclosed limitations',pid)
  secs=p.get('sections',[]);secids=[x.get('id')for x in secs];ensure(len(secids)==len(set(secids)),'duplicate-section','Duplicate profile section ID',pid)
  for sec in secs:
   ensure(nonempty(sec.get('title'))and nonempty(sec.get('body')),'empty-section','Empty editorial title/body',pid+'.'+str(sec.get('id')))
   ensure(nonempty(sec.get('evidenceType')),'section-evidence-type','Missing evidence classification',pid+'.'+str(sec.get('id')))
   ensure(not re.search(r'\b(TODO|lorem ipsum|coming soon)\b',sec.get('body',''),re.I),'placeholder-content','Unfinished placeholder presented as body text',pid+'.'+str(sec.get('id')))
  for sid in each_ref(p,'sourceIds'):
   ensure(sid in source,'broken-source-reference','Unknown source '+str(sid),pid);used_sources.add(sid)
  for cid in each_ref(p,'claimIds'):
   ensure(cid in claim,'broken-claim-reference','Unknown claim '+str(cid),pid);used_claims.add(cid)
 for r in editorialregions:
  if r['id']in reg:ensure(r.get('kind')==reg[r['id']]['type'],'regional-editorial-kind','Editorial/admin class mismatch',r['id'])
 required={'identity','urbanism','economy','housing','social','culture','food','climate','problems','livability','verdict','neighborhoods','relationships','outlook'}
 for c in cityrows:
  pid=c['id'];mid=c.get('municipalityId');ensure(mid in muni,'city-municipality','City profile is not bound to an official municipality',pid)
  if mid in muni:
   ensure(c.get('provinceId')==muni[mid]['provinceId']and c.get('regionId')==muni[mid]['regionId'],'city-admin-match','City province/region does not match official municipality',pid)
  if c.get('tier')==1:ensure(required<={x['id']for x in c['sections']},'major-city-sections','Missing standard major-city sections '+str(sorted(required-{x['id']for x in c['sections']})),pid)
  ensure(bool(c.get('sourceIds')),'city-sources','Major profile has no bibliography',pid)
  for stat in c.get('statistics',[]):
   for f in['label','unit','geographicUnit','referencePeriod','definition']:ensure(nonempty(stat.get(f)),'statistic-definition','Statistic missing '+f,pid)
   ensure(isinstance(stat.get('value'),(int,float))and not isinstance(stat.get('value'),bool)and math.isfinite(stat['value']),'statistic-value','Statistic lacks finite numeric value',pid)
   ensure(bool(stat.get('sourceIds'))and all(s in source for s in stat.get('sourceIds',[])),'statistic-source','Statistic lacks valid source',pid)
   pcids=set(each_ref(c,'claimIds'));matches=[claim[x]for x in pcids if x in claim and claim[x].get('evidenceType','').replace(' ','-')=='measured-statistical-condition'and claim[x].get('referencePeriod')==stat.get('referencePeriod')and claim[x].get('geographicUnit')==stat.get('geographicUnit')and set(claim[x].get('sourceIds',[]))&set(stat.get('sourceIds',[]))]
   ensure(bool(matches),'statistic-claim','Statistic has no matching measured claim with same source/unit/period',pid)
 for c in claims:
  for f in['claim','referencePeriod','evidenceType','confidence','editorialTreatment']:ensure(nonempty(c.get(f)),'claim-required','Claim missing '+f,c['id'])
  ensure(bool(c.get('geographicUnit')),'claim-geography','Claim missing geographic unit',c['id'])
  for sid in c.get('sourceIds',[]):ensure(sid in source,'claim-source','Unknown source '+str(sid),c['id']);used_sources.add(sid)
  if not c.get('sourceIds'):ensure(c.get('evidenceType','').replace(' ','-')=='editorial-interpretation','unsourced-factual-claim','Noneditorial claim has no source',c['id'])
 for sid in set(source)-used_sources:issue('orphan-source','Source is not used by a profile or evidence record',sid)
 for cid in set(claim)-used_claims:issue('orphan-claim','Evidence record is not linked from a profile',cid)
 updates=loaded.get('editorial-updates.json')or[];unique(updates,'editorial updates')
 for u in updates:
  date_check(u.get('lastResearched'),u['id']+'.lastResearched');date_check(u.get('lastUpdated'),u['id']+'.lastUpdated')
  ensure(not u.get('certifiedComplete'),'false-completion-claim','Current research is not certified complete',u['id'])
 update_ids={u.get('profileId')for u in updates};expected_updates={'ES'}|{'ES-'+r['id']for r in editorialregions}|set(city)
 if expected_updates-update_ids:issue('editorial-update-index-partial',str(len(expected_updates-update_ids))+' profiles lack an entry in the optional consolidated update index; per-profile histories remain separate',severity='warning')
 METRICS.update(cityProfiles=len(cityrows),regionalSyntheses=len(editorialregions),sources=len(source),claims=len(claim),editorialUpdateRecords=len(updates),numericCityStatistics=sum(len(c.get('statistics',[]))for c in cityrows))
 CHECKS['contentScope']='Geographic directory and structural integrity verified; research-depth completion is explicitly not certified'
 # Inspect every generated page, asset target and fragment.
 if not args.skip_built:
  ensure(dist.is_dir(),'missing-build','Run the production build before validation')
  pages={};routes={};htmlfiles=sorted(dist.rglob('*.html'))
  for file in htmlfiles:
   rel=file.relative_to(dist).as_posix();route='/'+rel[:-10]if rel.endswith('index.html')else'/'+rel
   parser=PageParser();parser.feed(file.read_text(encoding='utf-8'));pages[rel]=parser;routes[route]=rel
   for x,n in Counter(parser.ids).items():
    if n>1:issue('duplicate-html-id',f'{x}: {n} occurrences',rel)
   ensure(parser.main and parser.title and parser.lang,'page-semantics','Missing main/title/document language',rel)
  def resolve(path):
   path=unquote(path);p=(dist/path.lstrip('/')).resolve()
   if not p.is_relative_to(dist.resolve()):return None
   if p.is_dir():p=p/'index.html'
   if p.is_file():return p
   if not Path(path).suffix and (p/'index.html').is_file():return p/'index.html'
   return None
  origin='https://atlas.invalid'
  hostconfig=root/'.openai/hosting.json'
  own_hosts=set()
  if hostconfig.exists():
   hc=read(hostconfig)or{}
   for key in ['expected_url','current_live_url','current_preview_url']:
    if hc.get(key):own_hosts.add(urlsplit(hc[key]).netloc)
  checked=0;fragments=0;external=set()
  for route,rel in routes.items():
   for href,tag,attr in pages[rel].refs:
    if href.startswith(('data:','blob:','mailto:','tel:','javascript:')):continue
    parsed=urlsplit(href)
    if parsed.scheme or parsed.netloc:
     if parsed.netloc not in own_hosts:external.add(href);continue
    joined=urlsplit(urljoin(origin+route,href));target=resolve(joined.path or route);checked+=1
    if target is None:issue('broken-built-target',href,rel);continue
    if joined.fragment and target.suffix=='.html':
     targetrel=target.relative_to(dist).as_posix();fragment=unquote(joined.fragment);fragments+=1
     if targetrel in pages:ensure(fragment in pages[targetrel].ids,'broken-built-fragment',href,rel)
  for mid in muni:ensure(resolve('/spain/places/'+mid+'/')is not None,'missing-municipal-route','Missing direct municipality route',mid)
  for rid in reg:ensure(resolve('/spain/regions/'+rid+'/')is not None,'missing-region-route','Missing direct regional route',rid)
  for pid in prov:ensure(resolve('/spain/provinces/'+pid+'/')is not None,'missing-province-route','Missing province/autonomous-city route',pid)
  for c in cityrows:
   f=resolve('/spain/places/'+c['municipalityId']+'/')
   if f:ensure('sources'in pages[f.relative_to(dist).as_posix()].ids,'missing-city-bibliography','City route lacks Sources section',c['id'])
  # A freshly built artifact must contain the exact maintained public files.
  mismatch=[]
  for file in (root/'public').rglob('*'):
   if not file.is_file():continue
   target=dist/file.relative_to(root/'public')
   if not target.exists()or hashlib.sha256(file.read_bytes()).digest()!=hashlib.sha256(target.read_bytes()).digest():mismatch.append(str(file.relative_to(root/'public')))
  if mismatch:issue('stale-build-public-data',str(len(mismatch))+' files differ from public source; rebuild before publication. Examples: '+', '.join(mismatch[:12]))
  for filename,expected in [('sources.json',sources),('claims.json',claims)]:
   actual=read(dist/'data'/filename)
   ensure(actual==expected,'stale-build-merged-data','Merged generated file differs from maintained records',filename)
  sitemap=dist/'sitemap.xml'
  if sitemap.exists():
   try:
    tree=ET.fromstring(sitemap.read_text());urls=[x.text for x in tree.findall('.//{*}loc')]
    for u in urls:ensure(resolve(urlsplit(u).path)is not None,'broken-sitemap-route',u)
    METRICS['sitemapURLs']=len(urls)
   except ET.ParseError as ex:issue('sitemap-xml',str(ex))
  else:issue('missing-sitemap','Generated sitemap is missing')
  METRICS.update(htmlPages=len(htmlfiles),internalTargetsChecked=checked,fragmentsChecked=fragments,uniqueExternalPageURLs=len(external))
  CHECKS['internalLinks']='All static HTML href/src/poster/action/srcset targets and HTML fragments checked; dynamic map/search interactions require separate browser tests. Datalist list= and other JS-populated controls are not treated as static href anchors.'
 # Preserve declared limitations as warnings, never a false certificate of complete research.
 for code,message in [('research-depth-incomplete','The complete Spanish editorial commission is not achieved; current profiles disclose research gaps.'),('fua-membership-derived','FUA memberships are computed spatial links, not an official municipality membership roster.'),('boundary-vintage','Geometry is 2024; names/codes are 2026 and population is official Padrón 2025.'),('historic-housing-data','The validated city rental-expenditure statistics refer to 2022; they are not current asking rents.')]:issue(code,message,severity='warning')
 report={'referenceDate':REFERENCE_DATE.isoformat(),'generatedAt':datetime.now(timezone.utc).isoformat(),'passed':not ERRORS,'spainEditorialComplete':False,'errors':ERRORS,'warnings':WARNINGS,'metrics':METRICS,'checks':CHECKS,'scopeExclusions':['External HTTP availability is audited separately by scripts/check_links.py.','No actual iPad hardware, screen reader, browser interaction, or qualitative source-triangulation claim is made by this static validator.']}
 out=args.output or root/'docs/VALIDATION.json';out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'passed':report['passed'],'errors':len(ERRORS),'warnings':len(WARNINGS),'metrics':METRICS,'report':str(out)},ensure_ascii=False,indent=2))
 if ERRORS:
  for e in ERRORS[:20]:print(e['code']+': '+e['message']+' ['+str(e.get('location'))+']',file=sys.stderr)
 return 0 if not ERRORS else 1
if __name__=='__main__':sys.exit(main())
