#!/usr/bin/env python3
"""Reproducible GISCO Spain import. Standard library only; downloaded sources cached outside public/.
Never upgrades reference periods silently. See docs/GEOGRAPHY.md for provenance and limitations.
"""
from pathlib import Path
import json, csv, math, subprocess, hashlib, datetime, sys, zipfile, shutil, xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
CACHE=ROOT/'work/data-downloads'; OUT=ROOT/'public/data/geography'
CACHE.mkdir(parents=True,exist_ok=True); OUT.mkdir(parents=True,exist_ok=True)
BASE='https://gisco-services.ec.europa.eu/distribution/v2'
REGIONS=[
 ('01','Andalucía','ES61','autonomous-community',['Andalusia']),('02','Aragón','ES24','autonomous-community',['Aragon']),('03','Principado de Asturias','ES12','autonomous-community',['Asturias']),('04','Illes Balears','ES53','autonomous-community',['Islas Baleares','Balearic Islands']),('05','Canarias','ES70','autonomous-community',['Canary Islands']),('06','Cantabria','ES13','autonomous-community',[]),('07','Castilla y León','ES41','autonomous-community',['Castile and León']),('08','Castilla-La Mancha','ES42','autonomous-community',[]),('09','Catalunya','ES51','autonomous-community',['Cataluña','Catalonia']),('10','Comunitat Valenciana','ES52','autonomous-community',['Comunidad Valenciana','Valencian Community']),('11','Extremadura','ES43','autonomous-community',[]),('12','Galicia','ES11','autonomous-community',[]),('13','Comunidad de Madrid','ES30','autonomous-community',['Madrid']),('14','Región de Murcia','ES62','autonomous-community',['Murcia']),('15','Comunidad Foral de Navarra','ES22','autonomous-community',['Navarra','Nafarroa','Navarre']),('16','País Vasco','ES21','autonomous-community',['Euskadi','Basque Country']),('17','La Rioja','ES23','autonomous-community',[]),('18','Ceuta','ES63','autonomous-city',[]),('19','Melilla','ES64','autonomous-city',[])]
PROVINCES=[
 ('01','Araba/Álava','16',['ES211']),('02','Albacete','08',['ES421']),('03','Alicante/Alacant','10',['ES521']),('04','Almería','01',['ES611']),('05','Ávila','07',['ES411']),('06','Badajoz','11',['ES431']),('07','Illes Balears','04',['ES531','ES532','ES533']),('08','Barcelona','09',['ES511']),('09','Burgos','07',['ES412']),('10','Cáceres','11',['ES432']),('11','Cádiz','01',['ES612']),('12','Castellón/Castelló','10',['ES522']),('13','Ciudad Real','08',['ES422']),('14','Córdoba','01',['ES613']),('15','A Coruña','12',['ES111']),('16','Cuenca','08',['ES423']),('17','Girona','09',['ES512']),('18','Granada','01',['ES614']),('19','Guadalajara','08',['ES424']),('20','Gipuzkoa','16',['ES212']),('21','Huelva','01',['ES615']),('22','Huesca','02',['ES241']),('23','Jaén','01',['ES616']),('24','León','07',['ES413']),('25','Lleida','09',['ES513']),('26','La Rioja','17',['ES230']),('27','Lugo','12',['ES112']),('28','Madrid','13',['ES300']),('29','Málaga','01',['ES617']),('30','Murcia','14',['ES620']),('31','Navarra','15',['ES220']),('32','Ourense','12',['ES113']),('33','Asturias','03',['ES120']),('34','Palencia','07',['ES414']),('35','Las Palmas','05',['ES704','ES705','ES708']),('36','Pontevedra','12',['ES114']),('37','Salamanca','07',['ES415']),('38','Santa Cruz de Tenerife','05',['ES703','ES706','ES707','ES709']),('39','Cantabria','06',['ES130']),('40','Segovia','07',['ES416']),('41','Sevilla','01',['ES618']),('42','Soria','07',['ES417']),('43','Tarragona','09',['ES514']),('44','Teruel','02',['ES242']),('45','Toledo','08',['ES425']),('46','Valencia/València','10',['ES523']),('47','Valladolid','07',['ES418']),('48','Bizkaia','16',['ES213']),('49','Zamora','07',['ES419']),('50','Zaragoza','02',['ES243']),('51','Ceuta','18',['ES630']),('52','Melilla','19',['ES640'])]

def fetch(name,url):
 path=CACHE/name
 if not path.exists():
  print('Downloading',url,flush=True)
  subprocess.run(['curl','--fail','--location','--retry','3','--max-time','300','--silent','--show-error',url,'--output',str(path.with_suffix(path.suffix+'.part'))],check=True)
  path.with_suffix(path.suffix+'.part').rename(path)
 return path

def save(name,value):
 (OUT/name).write_text(json.dumps(value,ensure_ascii=False,separators=(',',':')),encoding='utf-8')

def point_in_ring(p,ring):
 x,y=p;inside=False
 for a,b in zip(ring,ring[1:]+ring[:1]):
  if ((a[1]>y)!=(b[1]>y)) and x<(b[0]-a[0])*(y-a[1])/(b[1]-a[1])+a[0]:inside=not inside
 return inside

def representative(geom):
 polys=geom['coordinates'] if geom['type']=='MultiPolygon' else [geom['coordinates']]
 def signed_area(r):return sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(r,r[1:]+r[:1]))/2
 poly=max(polys,key=lambda p:abs(signed_area(p[0])))
 ring=poly[0]; a=signed_area(ring)
 if a:
  x=sum((p[0]+q[0])*(p[0]*q[1]-q[0]*p[1]) for p,q in zip(ring,ring[1:]+ring[:1]))/(6*a)
  y=sum((p[1]+q[1])*(p[0]*q[1]-q[0]*p[1]) for p,q in zip(ring,ring[1:]+ring[:1]))/(6*a)
 else:x,y=ring[0]
 def within(p):return point_in_ring(p,ring) and not any(point_in_ring(p,h) for h in poly[1:])
 if not within((x,y)):
  loX=min(p[0] for p in ring);hiX=max(p[0] for p in ring);loY=min(p[1] for p in ring);hiY=max(p[1] for p in ring)
  points=[(loX+(hiX-loX)*i/20,loY+(hiY-loY)*j/20) for i in range(1,20) for j in range(1,20)]
  points=[p for p in points if within(p)]
  if points:x,y=min(points,key=lambda p:(p[0]-x)**2+(p[1]-y)**2)
  else:x,y=ring[0]
 return round(x,6),round(y,6)

def aliases(name):
 vals=set()
 for part in name.split('/'):
  part=part.strip()
  if part!=name:vals.add(part)
  if ', ' in part:
   base,article=part.rsplit(', ',1)
   vals.add(article+('' if article.endswith("'") or article.endswith('’') else ' ')+base)
 return sorted(v for v in vals if v and v!=name)

def fc(features):return {'type':'FeatureCollection','features':features}

def official_dictionary(path):
 z=zipfile.ZipFile(path);ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
 strings=[''.join(n.itertext()) for n in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('s:si',ns)];out={}
 for r in ET.fromstring(z.read('xl/worksheets/sheet1.xml')).findall('.//s:row',ns)[2:]:
  vals={}
  for c in r.findall('s:c',ns):
   v=c.find('s:v',ns)
   if v is not None:vals[c.get('r')[0]]=strings[int(v.text)] if c.get('t')=='s' else v.text
  if all(k in vals for k in ['A','B','C','E']):out[vals['B'].zfill(2)+vals['C'].zfill(3)]={'name':vals['E'],'regionId':vals['A'].zfill(2)}
 return out

def official_population(path):
 out={}
 for series in json.loads(path.read_text()):
  md={m['T3_Variable']:m for m in series['MetaData']}
  if md.get('Sexo',{}).get('Codigo')!='0':continue
  code=md.get('Municipios',{}).get('Codigo')
  if not code or len(code)!=5 or not series['Data']:continue
  d=series['Data'][-1]
  out[code]={'population':int(d['Valor']) if d['Valor'] is not None else None,'populationYear':d['Anyo'],'ineSeriesId':series['COD']}
 return out

def main():
 lau_path=fetch('LAU_RG_01M_2024_4326.geojson',BASE+'/lau/geojson/LAU_RG_01M_2024_4326.geojson')
 nuts_path=fetch('NUTS_RG_03M_2024_4326.geojson',BASE+'/nuts/geojson/NUTS_RG_03M_2024_4326.geojson')
 dictionary_path=fetch('diccionario26.xlsx','https://www.ine.es/daco/daco42/codmun/diccionario26.xlsx')
 population_path=fetch('ine-population-29005.json','https://servicios.ine.es/wstempus/js/ES/DATOS_TABLA/29005?nult=1&tip=AM')
 dictionary=official_dictionary(dictionary_path);populations=official_population(population_path)
 lau=json.loads(lau_path.read_text());nuts=json.loads(nuts_path.read_text())
 regs=[dict(id=i,countryId='ES',name=n,nutsId=nut,type=t,aliases=al) for i,n,nut,t,al in REGIONS]
 provs=[dict(id=i,countryId='ES',name=n,regionId=r,nutsIds=ns,type='province' if i not in ['51','52'] else 'autonomous-city') for i,n,r,ns in PROVINCES]
 pm={p['id']:p for p in provs};rm={r['nutsId']:r for r in regs}
 municipalities=[];sf=[]
 for f in lau['features']:
  p=f['properties']
  if p.get('CNTR_CODE')!='ES':continue
  code=str(p.get('LAU_ID') or p.get('LAU_CODE') or p.get('GISCO_ID','').removeprefix('ES_')).zfill(5)
  source_name=p.get('LAU_NAME') or p.get('NAME_LATN') or p.get('NAME')
  name=dictionary[code]['name']
  if code[:2] not in pm:raise ValueError('Unknown province '+code)
  lon,lat=representative(f['geometry'])
  population=populations[code];pop=population['population'];year=population['populationYear']
  municipalities.append(dict(id=code,countryId='ES',name=name,aliases=sorted(set(aliases(name)+aliases(source_name)+([source_name] if source_name!=name else []))),provinceId=code[:2],regionId=pm[code[:2]]['regionId'],lat=lat,lon=lon,population=pop,populationYear=year,type='municipality',coverageTier=4,coordinateType='polygon-representative-point',sourceId='gisco-lau-2024',nameSourceId='ine-municipal-dictionary-2026',populationSourceId='ine-population-29005',ineSeriesId=population['ineSeriesId']))
  sf.append({'type':'Feature','properties':{'id':code,'name':name},'geometry':f['geometry']})
 municipalities.sort(key=lambda m:m['id'])
 if len(municipalities)!=8132:raise ValueError('Expected 8132 municipalities, got '+str(len(municipalities)))
 if len({m['id'] for m in municipalities})!=len(municipalities):raise ValueError('Duplicate IDs')
 if set(dictionary)!={m['id'] for m in municipalities}:raise ValueError('2026 municipality code set differs from 2024 boundaries')
 if set(populations)!=set(dictionary):raise ValueError('Population / dictionary ID mismatch')
 if sum(m['population'] for m in municipalities)!=49114494:raise ValueError('Population total differs from verified 2025 Padrón total')
 geometry_by_id={f['properties']['id']:f['geometry'] for f in sf}
 for m in municipalities:
  if not isinstance(m['population'],int) or m['population']<=0 or m['populationYear']!=2025:raise ValueError('Invalid population '+m['id'])
  geom=geometry_by_id[m['id']];polygons=geom['coordinates'] if geom['type']=='MultiPolygon' else [geom['coordinates']];point=(m['lon'],m['lat'])
  if not any(point_in_ring(point,poly[0]) and not any(point_in_ring(point,h) for h in poly[1:]) for poly in polygons):raise ValueError('Representative point outside municipality '+m['id'])
  if m['regionId']!=dictionary[m['id']]['regionId']:raise ValueError('Community parent mismatch '+m['id'])
 known_aliases={'01059':['Vitoria','Gasteiz'],'15030':['La Coruña'],'17079':['Gerona'],'25120':['Lérida'],'07026':['Ibiza'],'07040':['Palma de Mallorca'],'41091':['Seville'],'50297':['Saragossa'],'48020':['Bilbo'],'08279':['Tarrasa']}
 for m in municipalities:m['aliases']=sorted(set(m['aliases']+known_aliases.get(m['id'],[])))
 save('municipalities.json',municipalities);save('regions.json',regs);save('provinces.json',provs)
 # NUTS3 island units are preserved separately; they are not mislabeled provinces.
 levels={l:[f for f in nuts['features'] if f['properties']['CNTR_CODE']=='ES' and int(f['properties']['LEVL_CODE'])==l] for l in [0,2,3]}
 for f in levels[2]:
  f['properties']['regionId']=rm[f['properties']['NUTS_ID']]['id'];f['properties']['id']=f['properties']['regionId']
 save('spain.geojson',fc(levels[0]));save('regions.geojson',fc(levels[2]));save('nuts3.geojson',fc(levels[3]))
 # Europe includes every NUTS0 country, including countries without editorial coverage.
 save('europe.geojson',fc([f for f in nuts['features'] if int(f['properties']['LEVL_CODE'])==0]))
 # Province geometries: combine member NUTS polygons into a MultiPolygon (internal island edges remain).
 nm={f['properties']['NUTS_ID']:f for f in levels[3]};pfs=[]
 for p in provs:
  coords=[]
  for nid in p['nutsIds']:
   g=nm[nid]['geometry'];coords.extend(g['coordinates'] if g['type']=='MultiPolygon' else [g['coordinates']])
  pfs.append({'type':'Feature','properties':p,'geometry':{'type':'MultiPolygon','coordinates':coords}})
 save('provinces.geojson',fc(pfs))
 # Per-province municipal geometry supports local map loads without a giant national bundle.
 for p in provs:save('municipalities-'+p['id']+'.geojson',fc([f for f in sf if f['properties']['id'].startswith(p['id'])]))
 provenance={'id':'gisco-lau-2024','publisher':'Eurostat / GISCO','dataset':'LAU 2024 (1:1 million) and NUTS 2024 (1:3 million)','boundaryYear':2024,'municipalNamesReferenceDate':'2026-01-01','municipalCodeCheck':'Exact set equality with all 8,132 INE municipality codes at 2026-01-01','populationDefinition':'Official municipal Padrón population, total sexes, at 2025-01-01; INE table 29005; not annual population census or metropolitan population','additionalSources':[{'id':'ine-municipal-dictionary-2026','publisher':'Instituto Nacional de Estadística','title':'Relación de municipios y códigos por comunidades autónomas y provincias a 1 de enero de 2026','url':'https://www.ine.es/daco/daco42/codmun/diccionario26.xlsx'},{'id':'ine-population-29005','publisher':'Instituto Nacional de Estadística','title':'Cifras oficiales de población de los municipios españoles: revisión del Padrón municipal','url':'https://www.ine.es/jaxiT3/Tabla.htm?t=29005','downloadUrl':'https://servicios.ine.es/wstempus/js/ES/DATOS_TABLA/29005?nult=1&tip=AM','referencePeriod':'2025-01-01'}],'accessedAt':'2026-11-07','crs':'EPSG:4326','sources':[{'url':BASE+'/lau/geojson/'+lau_path.name,'sha256':hashlib.sha256(lau_path.read_bytes()).hexdigest()},{'url':BASE+'/nuts/geojson/'+nuts_path.name,'sha256':hashlib.sha256(nuts_path.read_bytes()).hexdigest()}],'license':'GISCO specific noncommercial reuse conditions; attribution required','licenseUrl':'https://ec.europa.eu/eurostat/web/gisco/geodata/statistical-units','attribution':'© EuroGeographics for the administrative boundaries','municipalityCount':len(municipalities),'communityCount':17,'autonomousCityCount':2,'provinceCount':50,'municipalPopulationReferenceYears':sorted({m['populationYear'] for m in municipalities}),'coordinateDefinition':'Representative point in largest municipal polygon; geographic location, not settlement center or town-hall coordinate.','limitations':['Geometry is a 2024 administrative snapshot; names and code inventory independently checked against INE 2026.','GISCO POP_2024 contains zero sentinels for all Spanish records; those values are discarded. Municipal populations come from INE Padrón 2025 instead.','NUTS statistical geography is crosswalked to provinces; island NUTS3 units remain separately available.','Full named functional urban memberships are not inferred from distance and require a separate official crosswalk.']}
 save('provenance.json',provenance)
 subprocess.run([sys.executable,str(Path(__file__).with_name('import-geography-relations.py'))],check=True)
 print(json.dumps({'municipalities':len(municipalities),'populationYears':provenance['municipalPopulationReferenceYears'],'regions':len(regs),'provinceEntities':len(provs),'files':len(list(OUT.iterdir()))}),flush=True)
if __name__=='__main__':main()

# Preserve independent official reference extractions with the maintained source.
reference=ROOT/'reference/official';reference.mkdir(parents=True,exist_ok=True)
for name in ['ine-municipality-dictionary-2026.json','ine-municipality-population-2025.json','diccionario26.xlsx']:
 if (CACHE/name).exists():shutil.copyfile(CACHE/name,reference/name)
