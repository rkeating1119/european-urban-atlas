import { build } from "esbuild";
await build({
  entryPoints: ["src/app.ts"],
  bundle: true,
  minify: true,
  sourcemap: true,
  target: "es2022",
  outdir: "dist/client/assets",
  format: "esm",
  splitting: true,
  entryNames: "app",
  chunkNames: "map-[hash]",
});
