#!/usr/bin/env python3
"""Generic country publication adapter. Spain keeps its existing curated renderer.
Call render_configured_countries(output_root, render_page_callback) at the build end.
The callback signature is (path, title, body, description='', kind='WebPage').
"""
from pathlib import Path
from collections import defaultdict
from urllib.parse import quote,urlsplit
import html,json,math,re,statistics
from geographic_contract import ROOT,read_registry,load_country,validate_graph,resolve_public,read_json

def esc(value):return html.escape(str(value if value is not None else ''),quote=True)
def paragraphs(value):
 if isinstance(value,list):return ''.join(paragraphs(v) for v in value)
 return ''.join('<p>'+esc(v)+'</p>' for v in str(value or '').replace('\\n','\n').split('\n\n') if v.strip())
def section_anchor(section,index):return re.sub('[^a-zA-Z0-9_-]','-',str(section.get('id','section-'+str(index))))
def number(value):return f'{int(value):,}' if value is not None else 'Not available'
def dump(path,value):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
def safe_url(value):
 text=str(value or '');url=urlsplit(text)
 return text if url.scheme in ['http','https'] and url.netloc and not url.username and not url.password else None

def dataset(config,key,root,default):
 value=config.get('datasets',{}).get(key)
 if not value:return default
 if isinstance(value,list):
  output=[]
  for path in value:
   rows=read_json(resolve_public(path,root))
   if not isinstance(rows,list):raise ValueError(key+' collection must be an array: '+path)
   output.extend(rows)
  return output
 return read_json(resolve_public(value,root))

def source_index(config,root):
 sources={s['id']:s for s in config.get('sources',[])}
 for s in dataset(config,'sources',root,[]):sources[s['id']]=s
 provenance=dataset(config,'provenance',root,{})
 if isinstance(provenance,dict):
  for s in provenance.get('additionalSources',[]):
   if s.get('id'):sources[s['id']]=s
  if provenance.get('id'):
   p=dict(provenance);p.setdefault('title',p.get('dataset',p['id']))
   if not p.get('url') and p.get('sources'):p['url']=p['sources'][0].get('url')
   sources[p['id']]=p
 return sources

def source_html(source):
 sid=source['id'];url=safe_url(source.get('url'));title=esc(source.get('title',sid));link=f'<a href="{esc(url)}" target="_blank" rel="noopener noreferrer">{title} ↗</a>' if url else title
 date=source.get('accessed',source.get('accessDate',source.get('accessedAt','Not recorded')))
 return f'<article id="source-{esc(sid)}" class="source-record"><p class="eyebrow">{esc(sid)} · {esc(source.get("type",source.get("evidenceType","Source")))}</p><h3>{link}</h3><p class="source-meta">{esc(source.get("publisher",source.get("institution","")))} · Accessed {esc(date)} · Reference: {esc(source.get("referencePeriod","See source"))}</p>{paragraphs(source.get("findings",source.get("contribution","")))}<p class="note">Limitations: {esc(source.get("limitations",source.get("reliabilityNotes","Read the source in its geographic and temporal context.")))}</p></article>'

def profile_sources(profile):return list(dict.fromkeys(profile.get('sourceIds',[])+[sid for s in profile.get('sections',[]) for sid in s.get('sourceIds',[])]))
def editorial_sections(profile,sources):
 output=[]
 for i,section in enumerate(profile.get('sections',[])):
  sid=re.sub('[^a-zA-Z0-9_-]','-',str(section.get('id','section-'+str(i))))
  refs=section.get('sourceIds',[])
  for ref in refs:
   if ref not in sources:raise ValueError('Profile section references missing source '+ref)
  output.append(f'<section id="{esc(sid)}"><p class="evidence-type">{esc(section.get("evidenceType","Editorial synthesis").replace("-"," "))}</p><h2>{esc(section["title"])}</h2>{paragraphs(section.get("body",section.get("text","")))}'+('<p class="section-sources">Evidence: '+' · '.join(f'<a href="#source-{esc(ref)}">{esc(sources[ref].get("publisher",sources[ref].get("institution",ref)))}</a>' for ref in refs)+'</p>' if refs else '')+'</section>')
 return ''.join(output)
def bibliography(profile,sources,extra=()):
 ids=list(dict.fromkeys(profile_sources(profile)+list(extra)))
 for sid in ids:
  if sid not in sources:raise ValueError('Missing bibliography source '+sid)
 return '<section id="sources"><h2>Sources & further reading</h2>'+''.join(source_html(sources[sid]) for sid in ids)+'</section>' if ids else ''

def normalize_boundary(path,id_property,country_id,root,names=None):
 if not path:return {'type':'FeatureCollection','features':[]}
 data=read_json(resolve_public(path,root));features=[]
 if data.get('type')!='FeatureCollection':raise ValueError('Expected GeoJSON FeatureCollection: '+path)
 for feature in data['features']:
  props=feature.get('properties',{});native=props.get(id_property)
  if native is None:raise ValueError('Missing boundary identifier '+id_property+' in '+path)
  native=str(native)
  if names is not None and native not in names:continue
  name=names[native] if names is not None else props.get('NAME_ENGL',props.get('NUTS_NAME',props.get('CNTR_NAME',props.get('name',native))))
  features.append({'type':'Feature','properties':{'id':native,'name':name,'CNTR_CODE':country_id or props.get('CNTR_CODE',props.get('CNTR_ID',native))},'geometry':feature['geometry']})
 return {'type':'FeatureCollection','features':features}

def country_runtime(result,output_root,root,profile_list):
 config=result['country'];cid=config['id'];graph=result['graph'];entities=graph['entities'];by_id={e['id']:e for e in entities};outgoing=defaultdict(list)
 for rel in graph['relationships']:outgoing[rel['from']].append(rel)
 mapping_by_key={m['key']:m for m in config['adapter']['collections']}
 def entity_rows(key):
  mapping=mapping_by_key.get(key)
  return [e for e in entities if e['namespace']==mapping['namespace']] if mapping else []
 ancestry_cache={};active_ancestry=set()
 def ancestors(entity_id):
  if entity_id in active_ancestry:raise ValueError(cid+': cyclic administrative/statistical ancestry at '+entity_id)
  if entity_id in ancestry_cache:return ancestry_cache[entity_id]
  active_ancestry.add(entity_id)
  found=set()
  try:
   for relationship in outgoing[entity_id]:
    if relationship['type'] not in ['administrative-parent','statistical-parent']:continue
    target=relationship['to']
    if target not in by_id:raise ValueError(cid+': unknown administrative ancestor '+target)
    found.add(target);found.update(ancestors(target))
  finally:active_ancestry.remove(entity_id)
  ancestry_cache[entity_id]=found
  return found
 def parent(entity,target_key):
  mapping=mapping_by_key.get(target_key)
  if not mapping:return None
  matches={ancestor for ancestor in ancestors(entity['id']) if by_id[ancestor]['namespace']==mapping['namespace']}
  if len(matches)>1:raise ValueError(cid+': ambiguous '+mapping['namespace']+' ancestry for '+entity['id']+': '+', '.join(sorted(matches)))
  return by_id[next(iter(matches))]['nativeId'] if matches else None

 def display(entity):
  coords=entity.get('coordinates',{});pop=next((s for s in entity.get('statistics',[]) if s['indicator']=='population'),{})
  return {'id':entity['nativeId'],'entityId':entity['id'],'name':entity['name'],'aliases':entity.get('aliases',[]),'type':entity.get('legalType',entity['type']),'lat':coords.get('lat'),'lon':coords.get('lon'),'population':pop.get('value'),'populationYear':int(pop['referencePeriod'][:4]) if pop.get('referencePeriod') else None,'populationDefinition':pop.get('definition'),'populationSourceIds':pop.get('sourceRefs',[]),'geometryRef':entity.get('geometryRef')}
 regions=[display(e) for e in entity_rows('regions')];divisions=[];places=[]
 for ent in entity_rows('divisions'):
  row=display(ent);row['regionId']=parent(ent,'regions');divisions.append(row)
 for ent in entity_rows('municipalities'):
  row=display(ent);row['regionId']=parent(ent,'regions');row['divisionId']=parent(ent,'divisions');row['provinceId']=row['divisionId'];places.append(row)
 boundaries={};directory=output_root/'data/runtime'/cid
 for key,label,rows in [('regions','regions',regions),('divisions','provinces',divisions)]:
  mapping=mapping_by_key.get(key,{});fallback=config['datasets'].get('boundaries') if key=='regions' else None
  names={r['id']:r['name'] for r in rows};source_groups=defaultdict(dict)
  for row in rows:
   ref=row.get('geometryRef')
   if ref:source_groups[(ref['path'],ref['idProperty'])][row['id']]=row['name']
  if source_groups:
   features=[]
   for (path,prop),group_names in source_groups.items():features.extend(normalize_boundary(path,prop,cid,root,group_names)['features'])
   layer={'type':'FeatureCollection','features':features}
  else:layer=normalize_boundary(fallback,'id',cid,root,names)
  if rows and not layer['features']:raise ValueError(cid+': no usable '+label+' map geometry')
  dump(directory/(label+'.geojson'),layer);boundaries[label]=f'/data/runtime/{cid}/{label}.geojson'
 country_path=config['datasets'].get('countryBoundary')
 if country_path:
  source=read_json(resolve_public(country_path,root));country_features=[]
  for f in source['features']:country_features.append({'type':'Feature','properties':{'id':cid,'name':config['name'],'CNTR_CODE':cid},'geometry':f['geometry']})
  country_layer={'type':'FeatureCollection','features':country_features}
 else:
  coords=[]
  for f in read_json(directory/'regions.geojson')['features']:
   g=f['geometry'];coords.extend(g['coordinates'] if g['type']=='MultiPolygon' else [g['coordinates']])
  country_layer={'type':'FeatureCollection','features':[{'type':'Feature','properties':{'id':cid,'name':config['name'],'CNTR_CODE':cid},'geometry':{'type':'MultiPolygon','coordinates':coords}}]}
 dump(directory/'country.geojson',country_layer);boundaries['country']=f'/data/runtime/{cid}/country.geojson'
 world=config['datasets'].get('worldBoundaries') or '/data/geography/countries.geojson'
 world_file=resolve_public(world,root)
 if world_file.is_file():
  raw=read_json(world_file);p=raw['features'][0]['properties'];prop='CNTR_ID' if 'CNTR_ID' in p else 'CNTR_CODE' if 'CNTR_CODE' in p else 'NUTS_ID'
  world_layer=normalize_boundary(world,prop,None,root)
 else:world_layer=country_layer
 existing_world=output_root/'data/runtime/countries.geojson'
 if not world_file.is_file() and existing_world.is_file():
  old=read_json(existing_world);old['features']=[f for f in old['features'] if f['properties']['CNTR_CODE']!=cid]+world_layer['features'];world_layer=old
 dump(output_root/'data/runtime/countries.geojson',world_layer);boundaries['countries']='/data/runtime/countries.geojson'
 coordinates=[(e['lon'],e['lat']) for e in places if isinstance(e.get('lon'),(int,float)) and isinstance(e.get('lat'),(int,float))]
 view=dict(config.get('mapView',{}));view.setdefault('center',[statistics.median(x for x,y in coordinates),statistics.median(y for x,y in coordinates)] if coordinates else [0,45]);view.setdefault('zoom',5);provenance=dataset(config,'provenance',root,{});attribution=config.get('mapAttribution') or provenance.get('attribution') or view.get('attribution')
 if not attribution:raise ValueError(cid+': map attribution must be supplied by mapAttribution, mapView.attribution or geographic provenance before publication')
 view['attribution']=attribution;view.setdefault('insets',[])
 runtime={'country':config,'places':places,'regions':regions,'provinces':divisions,'profiles':profile_list,'boundaries':boundaries,'view':view,'entities':[display(e) for e in entities if e['type']!='country']}
 dump(output_root/f'data/runtime/{cid}.json',runtime)
 return runtime

def render_configured_countries(output_root,render_page_callback,root=ROOT):
 """Render enabled countries other than ES; disabled country configs create no pages.
 Returns {routes, countries}; callback owns document shell, global assets and sitemap registration.
 """
 output_root=Path(output_root);root=Path(root);rendered_routes=[];country_summaries=[]
 for config in read_registry(root)['countries']:
  if not config.get('enabled') or config['id']=='ES':continue
  result=load_country(config['id'],root);problems=validate_graph(result['graph'],config,root)
  if problems:raise ValueError('\n'.join(problems[:30]))
  entities=result['graph']['entities'];by_id={e['id']:e for e in entities};sources=source_index(config,root);mapping={m['key']:m for m in config['adapter']['collections']};base=config['routePrefix'];cid=config['id'];labels=config['labels'];segments=config.get('routeSegments',{})
  for key in ['regions','divisions','municipalities','directory']:
   segment=segments.get(key,key)
   if not re.fullmatch('[a-z][a-z0-9-]*',segment):raise ValueError('Invalid route segment '+segment)
  groups={key:[e for e in entities if e['namespace']==m['namespace']] for key,m in mapping.items()}
  primary={mapping[k]['namespace']:segments.get(k,k) for k in ['regions','divisions','municipalities'] if k in mapping}
  def href(entity):
   if entity['type']=='country':return base+'/'
   segment=primary.get(entity['namespace'])
   return base+'/'+segment+'/'+quote(entity['nativeId'],safe='')+'/' if segment else base+'/geography/'+quote(entity['namespace'],safe='')+'/'+quote(entity['nativeId'],safe='')+'/'
  overview=dataset(config,'countryOverview',root,{})
  region_profiles=dataset(config,'regionProfiles',root,[]);city_profiles=dataset(config,'cityProfiles',root,[])
  profile_by={}
  for key,records,reference_field in [('regions',region_profiles,'regionId'),('municipalities',city_profiles,'municipalityId')]:
   if key not in mapping:continue
   namespace=mapping[key]['namespace']
   for profile in records:
    canonical=profile.get('geographicEntityId',profile.get('entityId'))
    if not canonical:
     native=profile.get(reference_field,profile.get('id') if key=='regions' else None)
     if native is None:raise ValueError(cid+': profile lacks stable geographic reference')
     canonical=f'{cid}:{namespace}:{native}'
    if canonical not in by_id:raise ValueError(cid+': editorial profile references unknown entity '+canonical)
    if canonical in profile_by:raise ValueError(cid+': duplicate profile for '+canonical)
    profile_by[canonical]=profile
  country_entity=next(e for e in entities if e['type']=='country');profile_by[country_entity['id']]=overview
  runtime_profiles=[]
  for ent in groups.get('municipalities',[]):
   profile=profile_by.get(ent['id'])
   if profile and profile.get('sections'):runtime_profiles.append(dict(profile,municipalityId=ent['nativeId']))
  runtime=country_runtime(result,output_root,root,runtime_profiles)
  outgoing=defaultdict(list);incoming=defaultdict(list)
  for edge in result['graph']['relationships']:outgoing[edge['from']].append(edge);incoming[edge['to']].append(edge)
  def nav(links):return '<nav class="breadcrumbs" aria-label="Breadcrumb">'+'<span aria-hidden="true">/</span>'.join(f'<a href="{esc(url)}">{esc(name)}</a>' for name,url in [('Europe','/'),(config['name'],base+'/')]+links)+'</nav>'
  def listing(items):return '<div class="listing">'+''.join(f'<a href="{esc(href(e))}">{esc(e["name"])}</a>' for e in items)+'</div>'
  def page(path,title,body,description=''):
   render_page_callback(path,title,f'<div data-country="{cid}" data-country-config="/data/runtime/{cid}.json">{body}</div>',description,'WebPage');rendered_routes.append(path)
  def map_html(level,entity=None,large=False):
   extra=''
   if entity:
    kind='region' if entity['namespace']==mapping.get('regions',{}).get('namespace') else 'province' if entity['namespace']==mapping.get('divisions',{}).get('namespace') else 'place'
    extra=f' data-{kind}="{esc(entity["nativeId"])}"'
    ref=entity.get('geometryRef')
    if ref:extra+=f' data-geometry-path="{esc(ref["path"])}" data-geometry-id-property="{esc(ref["idProperty"])}" data-geometry-id="{esc(ref["idValue"])}"'
   options=''.join(f'<option value="{esc(e["nativeId"])}">{esc(e["name"])}</option>' for e in groups.get('regions',[]))
   insets=''.join(f'<option value="{i}">{esc(view["label"])}</option>' for i,view in enumerate(runtime['view']['insets']))
   return f'<div class="{"map-shell" if large else "profile-map"}"><div id="atlas-map" class="atlas-map" data-country="{cid}" data-country-config="/data/runtime/{cid}.json" data-level="{level}"{extra} role="region" aria-label="Interactive geographic map; the adjacent lists provide an accessible alternative"></div><div class="map-topbar"><a href="/">Europe</a><a class="active" href="{base}/">{esc(config["name"])}</a></div><p id="map-status" class="map-status" role="status">Loading local boundaries…</p><div class="map-bottom">'+(f'<select id="map-region" aria-label="Zoom to {esc(labels["firstLevelSingular"])}"><option value="">All {esc(labels["firstLevelPlural"].lower())}</option>{options}</select>' if large else '')+f'<button id="map-reset" aria-label="Reset map view">Reset view</button>'+(f'<select id="map-inset" aria-label="View overseas or island geography"><option value="">Other geographic extents</option>{insets}</select>' if insets else '')+f'</div><div class="map-legend"><label><input type="checkbox" id="toggle-provinces" checked> {esc(labels["secondLevelPlural"])}</label></div></div>'
  def profile_meta(profile,entity):
   coverage='Research profile' if profile.get('sections') else 'Geographic directory record'
   when=profile.get('researched',profile.get('lastResearched',profile.get('lastResearchedDate')))
   return '<div class="profile-meta"><span>'+esc(coverage)+'</span>'+('<span>Last researched '+esc(when)+'</span>' if when else '')+'<span>'+esc(entity.get('legalType',entity['type']).replace('-',' '))+'</span></div>'
  def facts(entity):
   stats=entity.get('statistics',[]);content=[]
   for stat in stats:
    content.append(f'<div><dt>{esc(stat["indicator"].replace("-"," ").title())}</dt><dd>{number(stat["value"])} {esc(stat["unit"])}<small>Reference {esc(stat["referencePeriod"])}</small></dd></div>')
   return '<dl class="facts">'+''.join(content)+'</dl>'+''.join(f'<p class="note">{esc(s["definition"])} · {esc(s["aggregation"].replace("-"," "))}</p>' for s in stats)
  def relationships(entity):
   rels=outgoing[entity['id']]
   if not rels:return ''
   text=[]
   for rel in rels:
    target=by_id[rel['to']];label=rel['type'].replace('-',' ');evidence='Computed spatial relationship' if rel['evidenceType']=='derived-spatial' else rel['evidenceType'].replace('-',' ')
    text.append(f'<li><a href="{esc(href(target))}">{esc(target["name"])}</a><small> · {esc(label)} · {esc(evidence)}</small><p class="note">{esc(rel["method"])}</p></li>')
   return '<section id="relationships"><h2>Geographic relationships</h2><ul>'+''.join(text)+'</ul></section>'
  def profile_content(profile,entity):
   limitations=profile.get('limitations',[])
   if isinstance(limitations,str):limitations=[limitations]
   notice='<div class="notice"><strong>Research scope.</strong> '+esc(' '.join(limitations))+'</div>' if limitations else ''
   if not profile.get('sections'):notice+='<p class="note">This is a geographic directory record. It provides sourced location, administrative relationships and available statistical context; it does not claim a researched account of everyday life.</p>'
   images=''
   for image in profile.get('images',[]):
    if not isinstance(image,dict) or not image.get('sourceId') or not image.get('license'):continue
    if image['sourceId'] not in sources:raise ValueError('Image refers to missing source '+image['sourceId'])
    url=image.get('url',image.get('path',''))
    if url.startswith('/assets/') or safe_url(url):images+=f'<figure><img src="{esc(url)}" alt="{esc(image.get("alt",""))}" loading="lazy"><figcaption>{esc(image.get("caption",""))} · {esc(image["license"])} · <a href="#source-{esc(image["sourceId"])}">Source</a></figcaption></figure>'
   refs=list(entity['sourceRefs'])+[im['sourceId'] for im in profile.get('images',[]) if isinstance(im,dict) and im.get('sourceId')]
   # Entity sources need actual source records, just like editorial claims.
   return notice+images+editorial_sections(profile,sources)+facts(entity)+relationships(entity)+bibliography(profile,sources,refs)
  region_list=groups.get('regions',[]);division_list=groups.get('divisions',[]);municipal_list=groups.get('municipalities',[])
  country_body=f'<div class="container">{nav([])}<header class="profile-header"><p class="eyebrow">Country atlas · {cid}</p><h1>{esc(config["name"])}</h1><p class="lede">{esc(overview.get("thesis",overview.get("summary","")))}</p>{profile_meta(overview,country_entity)}<p class="note">{esc(runtime["view"]["attribution"])}</p></header><section class="atlas-layout">{map_html("country",large=True)}<aside class="map-sidebar"><div><h2>{esc(labels["municipalityPlural"])}</h2><p>{number(len(municipal_list))} sourced geographic records.</p></div><div><a class="button" href="{base}/{segments.get("directory","directory")}/">Browse the national directory →</a><p class="note">{esc(config["coverage"].get("releaseClaim","Read the coverage and source dates attached to each record."))}</p></div></aside></section><section class="editorial-section"><h2>{esc(labels["firstLevelPlural"])}</h2>{listing(region_list)}</section><div class="profile-layout"><nav class="toc" aria-label="Country navigation"><a href="#sources">Sources</a><a href="{base}/sources/">National source catalogue</a><a href="{base}/evidence/">Evidence ledger</a></nav><div class="prose">{profile_content(overview,country_entity)}</div></div><section class="editorial-section"><h2>{esc(labels["secondLevelPlural"])}</h2>{listing(division_list)}</section></div>'
  page(base+'/',config['name'],country_body,overview.get('thesis',overview.get('summary','')))
  for entity in entities:
   if entity['type']=='country':continue
   profile=profile_by.get(entity['id'],{});namespace=entity['namespace'];is_region=namespace==mapping.get('regions',{}).get('namespace');is_division=namespace==mapping.get('divisions',{}).get('namespace');is_municipality=namespace==mapping.get('municipalities',{}).get('namespace')
   parents=[by_id[r['to']] for r in outgoing[entity['id']] if r['type'] in ['administrative-parent','statistical-parent']]
   ancestry=[]
   for parent in sorted(parents,key=lambda x:0 if x['namespace']==mapping.get('regions',{}).get('namespace') else 1):ancestry.append((parent['name'],href(parent)))
   children=[by_id[r['from']] for r in incoming[entity['id']] if r['type'] in ['administrative-parent','statistical-parent','member-of']]
   if is_region:
    # Include municipalities linked directly to this first-level unit as well as intermediate divisions.
    children=list({e['id']:e for e in children}.values())
    municipality_namespace=mapping.get('municipalities',{}).get('namespace')
    municipal_children=[e for e in children if e['namespace']==municipality_namespace]
    municipal_children.sort(key=lambda e:next((s['value'] for s in e.get('statistics',[]) if s['indicator']=='population'),0),reverse=True)
    children=[e for e in children if e['namespace']!=municipality_namespace]+municipal_children[:24]
   descendants='<section id="settlements"><h2>Places within this geography</h2>'+listing(sorted(children,key=lambda e:e['name']))+'</section>' if children else ''
   if is_region:descendants+=f'<p><a href="{base}/{segments.get("directory","directory")}/?region={quote(entity["nativeId"],safe="")}">Search every {esc(labels["municipalitySingular"].lower())} in this region →</a></p>'
   subtitle=profile.get('thesis',profile.get('summary',''))
   content=f'<div class="container">{nav(ancestry+[(entity["name"],href(entity))])}<header class="profile-header"><p class="eyebrow">{esc(entity.get("legalType",entity["type"]).replace("-"," "))} · {esc(config["name"])}</p><h1>{esc(entity["name"])}</h1>'+ (f'<p class="lede">{esc(subtitle)}</p>' if subtitle else '')+profile_meta(profile,entity)+'</header>'
   if entity.get('geometryRef') or entity.get('coordinates'):content+=map_html('region' if is_region else 'province' if is_division else 'place',entity)
   content+='<div class="profile-layout"><nav class="toc" aria-label="On this page">'+''.join(f'<a href="#{esc(section_anchor(s,i))}">{esc(s["title"])}</a>' for i,s in enumerate(profile.get('sections',[])))+'<a href="#relationships">Geographic relationships</a><a href="#sources">Sources</a></nav><div class="prose">'+profile_content(profile,entity)+descendants+'</div><aside class="profile-aside"><a class="text-link" href="'+base+'/">↑ '+esc(config['name'])+'</a></aside></div></div>'
   page(href(entity),entity['name'],content,subtitle or entity['name']+' geographic record within '+config['name'])
  directory_path=base+'/'+segments.get('directory','directory')+'/'
  directory=f'<div class="container">{nav([(labels["municipalityPlural"],directory_path)])}<header class="profile-header"><p class="eyebrow">Complete geographic browsing</p><h1>{esc(config["name"])}: every {esc(labels["municipalitySingular"].lower())}</h1><p class="lede">Search official names and alternate spellings, or follow the administrative geography.</p></header><form id="directory-form" class="directory-toolbar"><div class="directory-main-search"><label>Search<input id="directory-query" name="q" type="search" placeholder="Name or alternate spelling"></label><button class="button" type="submit">Search</button></div><div class="directory-filters"><label>{esc(labels["firstLevelSingular"])}<select id="filter-region" name="region"><option value="">All {esc(labels["firstLevelPlural"].lower())}</option></select></label><label>{esc(labels["secondLevelSingular"])}<select id="filter-province" name="province"><option value="">All {esc(labels["secondLevelPlural"].lower())}</option></select></label><label>Research coverage<select name="coverage"><option value="">Every record</option><option value="essay">Editorial profiles</option></select></label><label>Population<select name="size"><option value="">Every size</option><option value="small">Below 10,000</option><option value="large">100,000 or more</option></select></label><label>Sort<select name="sort"><option value="name">Name</option><option value="population">Population</option></select></label></div></form><p id="directory-count" role="status">{number(len(municipal_list))} geographic records</p><div id="directory-results">{listing(sorted(municipal_list,key=lambda e:e["name"])[:60])}</div><button id="load-more" class="button" type="button" hidden>Show more places</button><section class="editorial-section"><h2>Browse without using the map or search</h2><p>Each division page provides its complete list of municipalities.</p>{listing(division_list or region_list)}</section></div>'
  page(directory_path,config['name']+' municipal directory',directory,config['name']+' searchable geographic directory with an accessible administrative list alternative')
  page(base+'/sources/',config['name']+' sources','<div class="plain-page">'+nav([('Sources',base+'/sources/')])+'<h1>Sources: '+esc(config['name'])+'</h1><label>Filter sources<input id="source-filter" type="search"></label>'+''.join(source_html(s) for s in sources.values())+'</div>','Source catalogue with statistical definitions, reference periods and limitations')
  claims=dataset(config,'evidence',root,[])
  claim_body=[]
  for claim in claims:
   claim_body.append('<article class="source-record"><p class="eyebrow">'+esc(claim.get('id',claim.get('claimId','')))+'</p><h2>'+esc(claim.get('claim',claim.get('text','')) )+'</h2>'+''.join('<p><strong>'+esc(k.replace('_',' ').replace('-',' '))+':</strong> '+esc(v if not isinstance(v,(list,dict)) else json.dumps(v,ensure_ascii=False))+'</p>' for k,v in claim.items() if k not in ['id','claimId','claim','text'])+'</article>')
  page(base+'/evidence/',config['name']+' evidence ledger','<div class="plain-page">'+nav([('Evidence',base+'/evidence/')])+'<h1>Evidence ledger: '+esc(config['name'])+'</h1>'+''.join(claim_body)+'</div>','Claim-level evidence and geographic/statistical limitations')
  country_summaries.append({'id':cid,'municipalities':len(municipal_list),'regions':len(region_list),'divisions':len(division_list),'editorialProfiles':len(profile_by)-1,'runtimeConfig':'/data/runtime/'+cid+'.json'})
 return {'routes':rendered_routes,'countries':country_summaries}
