#!/usr/bin/env python3
"""Serve the exact GitHub Pages build locally, including its project URL prefix."""
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
import json,urllib.parse
ROOT=Path(__file__).resolve().parents[1]
config=ROOT/'.openai/github-pages.json';base=json.loads(config.read_text()).get('base_path','')if config.exists()else''
class Handler(SimpleHTTPRequestHandler):
 def __init__(self,*a,**kw):super().__init__(*a,directory=str(ROOT/'dist/client'),**kw)
 def translate_path(self,path):
  if base and (path==base or path.startswith(base+'/')):path=path[len(base):]or'/'
  return super().translate_path(path)
 def log_message(self,*a):pass
print('Atlas preview: http://localhost:4173'+base+'/',flush=True)
ThreadingHTTPServer(('127.0.0.1',4173),Handler).serve_forever()
