#!/usr/bin/env python3
"""Report manual profile review dates and old statistical periods separately."""
from pathlib import Path
from datetime import date
import argparse,json,re
ROOT=Path(__file__).resolve().parents[1]
a=argparse.ArgumentParser(description=__doc__);a.add_argument('--as-of',default='2026-11-07');args=a.parse_args();today=date.fromisoformat(args.as_of)
updates=json.loads((ROOT/'public/data/editorial-updates.json').read_text());cities=json.loads((ROOT/'public/data/cities.json').read_text());due=[];historical=[]
for u in updates:
 for topic,when in u.get('reviewSchedule',{}).items():
  if date.fromisoformat(when)<=today:due.append({'profileId':u['profileId'],'topic':topic,'reviewDue':when})
for c in cities:
 for s in c.get('statistics',[]):
  year=re.search(r'\d{4}',s['referencePeriod'])
  if year and int(year[0])<today.year-1:historical.append({'profileId':c['id'],'indicator':s['label'],'referencePeriod':s['referencePeriod'],'treatment':'Historical statistic; not a current market measure. Verify newer compatible releases before replacing.'})
report={'asOf':today.isoformat(),'reviewDue':due,'historicalStatistics':historical,'note':'A recent research date does not make old data current. This report schedules nothing.'}
(ROOT/'docs/STALE-RECORDS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False,indent=2))
