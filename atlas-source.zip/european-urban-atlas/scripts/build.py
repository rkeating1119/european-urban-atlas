#!/usr/bin/env python3
"""Build the curated, reader-facing atlas. Historical inventory remains in source control."""
from pathlib import Path
import os,json,html,re,shutil,subprocess,argparse,collections,hashlib
ROOT=Path(__file__).resolve().parents[1];os.chdir(ROOT)
parser=argparse.ArgumentParser();parser.add_argument('--draft',action='store_true');args=parser.parse_args()
OUT=ROOT/'dist/client';DATA=ROOT/'public/data';config=json.loads((ROOT/'.openai/hosting.json').read_text());github_config=ROOT/'.openai/github-pages.json'
if github_config.exists():config.update(json.loads(github_config.read_text()))
origin=config.get('expected_url','').rstrip('/');base=config.get('base_path','').rstrip('/')
def e(v):return html.escape(str(v if v is not None else ''),quote=True)
def url(p):return base+p
def read(p,default=None):return json.loads(p.read_text())if p.exists()else default
countries=[read(DATA/'editorial'/f'{slug}.json')for slug in ['spain','france','italy']];countries=[c for c in countries if c]
release=hashlib.sha256(b''.join(p.read_bytes()for p in [*(DATA/'editorial'/f'{slug}.json'for slug in ['spain','france','italy']),ROOT/'src/app.ts',ROOT/'public/assets/style.css',Path(__file__)])).hexdigest()[:12]
expected={'ES':60,'FR':51,'IT':50}
if not args.draft:
 if {c['id'] for c in countries}!=set(expected):raise ValueError('All three country datasets are required')
 for c in countries:
  if len(c['cities'])!=expected[c['id']]:raise ValueError(f'{c["name"]}: expected {expected[c["id"]]} complete city profiles, found {len(c["cities"])}')
views={'ES':{'center':[-3.8,39.3],'zoom':5.3,'insets':[{'name':'Canary Islands','center':[-15.5,28.4],'zoom':6.4},{'name':'Balearic Islands','center':[2.8,39.5],'zoom':7},{'name':'Ceuta & Melilla','center':[-4.3,35.5],'zoom':6.8}]},'FR':{'center':[2.6,46.5],'zoom':5.1,'insets':[{'name':'Corsica','center':[9,42.1],'zoom':7},{'name':'Guadeloupe','center':[-61.5,16.2],'zoom':8},{'name':'Martinique','center':[-61,14.65],'zoom':8},{'name':'French Guiana','center':[-52.4,4.9],'zoom':8},{'name':'Réunion','center':[55.5,-21.1],'zoom':8},{'name':'Mayotte','center':[45.2,-12.8],'zoom':9}]},'IT':{'center':[12.6,42.1],'zoom':5.1,'insets':[{'name':'Sicily','center':[14,37.6],'zoom':6.8},{'name':'Sardinia','center':[9,40],'zoom':6.8}]}}
categories=[{'id':'affordability','name':'Housing & everyday costs','description':'Higher means easier on an ordinary local budget.'},{'id':'careers','name':'Work & careers','description':'The range of jobs and professional opportunities.'},{'id':'transport','name':'Getting around','description':'How practical daily life is without a car.'},{'id':'culture','name':'Culture & things to do','description':'Museums, music, arts and the variety of an ordinary week.'},{'id':'social','name':'Social life','description':'Street life, students, nightlife and places to meet people.'},{'id':'outdoors','name':'Nature & outdoors','description':'Parks, coast, mountains and easy escapes from the city.'},{'id':'climate','name':'Weather comfort','description':'An editorial view of heat, cold, rain and everyday comfort.'}]
citylist=[]
for c in countries:
 c['url']=url('/'+c['slug']+'/');c['view']=views[c['id']]
 for r in c['regions']:r['url']=url(f'/{c["slug"]}/regions/{r["id"]}/')
 for city in c['cities']:
  city['url']=url(f'/{c["slug"]}/cities/{city["id"]}/');city.setdefault('aliases',[]);city['mapLabel']=False;citylist.append(city)
 # Permanent country labels identify the ten largest featured municipalities.
 # Every other featured city remains a zoom-scaled point with a hover/tap popup.
 for city in sorted(c['cities'],key=lambda x:(x.get('population')or{}).get('value',0),reverse=True)[:10]:city['mapLabel']=True
 if not args.draft:
  missing=[r['name']for r in c['regions']if not any(x['regionId']==r['id']for x in c['cities'])]
  if missing:raise ValueError('Regions without featured cities: '+', '.join(missing))
if OUT.exists():shutil.rmtree(OUT)
(OUT/'assets').mkdir(parents=True);(OUT/'data/maps').mkdir(parents=True)
for f in (ROOT/'public/assets').iterdir():
 if f.is_file()and '-v1'not in f.name:shutil.copy(f,OUT/'assets'/f.name)
shutil.copy(ROOT/'node_modules/maplibre-gl/dist/maplibre-gl.css',OUT/'assets/maplibre-gl.css')
for f in (DATA/'maps').iterdir():shutil.copy(f,OUT/'data/maps'/f.name)
for city in citylist:
 city['details']={}
 for sectionId in ['food','neighborhoods','architecture']:
  section=next((s for s in city['sections']if s['id']==sectionId),None)
  if section is None:continue
  text=' '.join(section['paragraphs']);city['details'][sectionId]=' '.join(re.split(r'(?<=[.!?])\s+',text)[:2])
clientKeys={'details','id','name','aliases','countryId','regionId','regionName','lat','lon','summary','goodFor','tradeoffs','population','size','ratings','url','mapLabel'}
clientCities=[{k:v for k,v in city.items()if k in clientKeys}for city in citylist]
clientCountries=[{**{k:v for k,v in c.items()if k!='cities'},'cities':[city for city in clientCities if city['countryId']==c['id']]}for c in countries]
(OUT/'data/atlas.json').write_text(json.dumps({'countries':clientCountries,'cities':clientCities,'categories':categories},ensure_ascii=False,separators=(',',':')))
logo='<svg viewBox="0 0 48 48" fill="none" aria-hidden="true"><circle cx="24" cy="24" r="20" stroke="currentColor" stroke-width=".8"/><path d="M24 1v46M1 24h46M10 10l28 28M10 38l28-28" stroke="currentColor" stroke-width=".6"/><path d="m24 8 5 16-5 16-5-16Z" fill="#275d4e"/><path d="m24 8 5 16h-5Z" fill="#b54a35"/></svg>'
routes=[]
def header(active=None):
 options=f'<option value="{url("/")}">Europe</option>'+''.join(f'<option value="{e(c["url"])}" '+('selected'if active==c['id']else'')+f'>{e(c["name"])}</option>'for c in countries)
 return f'''<a class="skip" href="#main">Skip to content</a><header class="site-header"><a class="brand" href="{url('/')}">{logo}<span class="brand-title">European Urban Atlas<small>SPAIN · FRANCE · ITALY</small></span></a><nav class="main-nav" aria-label="Main navigation"><label class="country-control"><span class="sr-only">Choose country</span><select class="country-switch" aria-label="Choose country">{options}</select></label><a href="{url('/cities/')}">Browse cities</a><a href="{url('/compare/')}">Compare</a></nav><div class="search-wrap"><span class="search-icon" aria-hidden="true">⌕</span><label class="sr-only" for="global-search">Find a city or region</label><input id="global-search" type="search" placeholder="Search cities and regions…" autocomplete="off" aria-controls="search-results"><div id="search-results" class="search-results" hidden role="region" aria-label="Search results" aria-live="polite"></div></div></header>'''
footer=f'<footer class="site-footer"><p>European Urban Atlas · Spain, France & Italy</p><nav aria-label="Footer"><a href="{url("/about/")}">About & ratings</a><a href="{url("/credits/")}">Sources & image credits</a></nav></footer>'
def page(path,title,body,description='',active=None,kind='WebPage'):
 path='/'+path.strip('/')+'/'if path!='/'else '/';target=OUT/path.lstrip('/')/'index.html';target.parent.mkdir(parents=True,exist_ok=True);canonical=origin+url(path)if origin else ''
 schema=json.dumps({'@context':'https://schema.org','@type':kind,'name':title,'description':description,'inLanguage':'en'},ensure_ascii=False).replace('</','<\\/')
 canonicalTag=f'<link rel="canonical" href="{e(canonical)}">'if canonical else ''
 target.write_text(f'''<!doctype html><html lang="en" data-base="{e(base)}" data-release="{release}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#275d4e"><title>{e(title)} · European Urban Atlas</title><meta name="description" content="{e(description[:300])}"><meta property="og:title" content="{e(title)}"><meta property="og:description" content="{e(description[:300])}">{canonicalTag}<link rel="icon" href="{url('/assets/favicon.svg')}" type="image/svg+xml"><link rel="stylesheet" href="{url('/assets/style.css')+'?v='+release}"><script type="module" src="{url('/assets/app.js')+'?v='+release}"></script><script type="application/ld+json">{schema}</script></head><body>{header(active)}<main id="main">{body}</main>{footer}</body></html>''');routes.append(path)
def crumb(parts):return '<nav class="breadcrumbs" aria-label="Breadcrumb">'+'<span aria-hidden="true">/</span>'.join(f'<a href="{e(u)}">{e(n)}</a>'for n,u in [('Europe',url('/'))]+parts)+'</nav>'
def paragraphs(ps):return ''.join(f'<p>{e(p)}</p>'for p in ps)
def countryof(city):return next(c for c in countries if c['id']==city['countryId'])
def card(city):
 c=countryof(city);photo=f'<figure><img src="{url("/assets/"+city["id"]+".jpg")}" alt="{e(city["name"])}" loading="lazy" width="1280" height="850"></figure>'if city['id']in ['madrid','bilbao','barcelona']else ''
 return f'<a class="browse-city" href="{e(city["url"])}"><p class="eyebrow">{e(city["regionName"])} · {e(c["name"])}</p><h3>{e(city["name"])} <span aria-hidden="true">↗</span></h3><p>{e(city["summary"])}</p><div class="city-tags">'+''.join(f'<span>{e(s)}</span>'for s in city['goodFor'][:3])+'</div></a>'
def map_html(country=None,region=None,city=None,large=False):
 attrs=(f'data-country="{country["id"]}"'if country else '')+(f' data-region="{region["id"]}"'if region else '')+(f' data-city="{city["countryId"]}:{city["id"]}"'if city else '')
 controls=f'<button id="map-reset" type="button" aria-label="Reset map view">Reset view</button>'
 if country and not city:
  controls=f'<label><span class="sr-only">Zoom to region</span><select id="map-region" aria-label="Zoom to region"><option value="">All regions</option>'+''.join(f'<option value="{r["id"]}">{e(r["name"])}</option>'for r in country['regions'])+'</select></label>'+controls
  controls+='<label><span class="sr-only">View islands or overseas regions</span><select id="map-inset" aria-label="View islands or overseas regions"><option value="">Islands & other areas</option>'+''.join(f'<option value="{i}">{e(x["name"])}</option>'for i,x in enumerate(country['view']['insets']))+'</select></label>'
 help='Hover over a dot for a quick look, or tap it to open the city card.'if city else'The ten largest cities are labelled. Hover over a dot for a quick look, or tap it to open the city card.'
 return f'<div class="map-shell {"large-map"if large else"city-map"}"><div id="atlas-map" class="atlas-map" {attrs} role="region" aria-label="Interactive city map"></div><p id="map-status" class="map-status" role="status">Loading map…</p><div class="map-bottom">{controls}</div></div><p class="map-help">{help}</p>'
def regionlinks(c):return '<div class="regions-grid">'+''.join(f'<a class="region-row" href="{e(r["url"])}"><span>{e(r["name"])}</span><span aria-hidden="true">↗</span></a>'for r in c['regions'])+'</div>'
def heading(title,link=None):return f'<div class="section-heading"><h2>{e(title)}</h2>'+ (f'<a href="{e(link[1])}">{e(link[0])} →</a>'if link else'')+'</div>'
# Home: a geographic introduction and a manageable choice of places.
home='<div class="container"><section class="page-intro"><p class="eyebrow">Cities, neighborhoods & everyday life</p><h1>Explore Spain,<br>France & Italy.</h1><p class="lede">What’s it like to live there? Find the places that fit your interests, compare their strengths, and get to know the neighborhoods, food and daily life.</p></section>'+map_html(large=True)+'<section class="editorial-section">'+heading('Choose a country')+'<div class="country-grid">'+''.join(f'<a class="country-card" href="{e(c["url"])}"><span class="country-number">{i+1:02d}</span><h2>{e(c["name"])} ↗</h2><p>{e(c["summary"])}</p><span class="text-link">Explore {len(c["cities"])} cities →</span></a>'for i,c in enumerate(countries))+'</div></section><section class="editorial-section">'+heading('Start with a city',('Browse all cities',url('/cities/')))+'<div class="city-grid">'+''.join(card(x)for key in ['ES:madrid','FR:paris','IT:rome','ES:barcelona','FR:lyon','IT:bologna']for x in citylist if f'{x["countryId"]}:{x["id"]}'==key)+'</div></section><section class="compare-invite"><h2>Torn between a few places?</h2><p>Compare housing, jobs, transport, culture, social life, the outdoors and weather, with a short explanation for each city.</p><a class="button" href="'+url('/compare/')+'">Compare cities →</a></section></div>'
page('/','Explore cities in Spain, France and Italy',home,'Clear, lively guides to cities in Spain, France and Italy. Neighborhoods, housing, work, culture, food and practical comparisons.')
for c in countries:
 cityJump='<label class="country-jump">Jump to a city<select class="city-switch" aria-label="Jump to a city"><option value="">Choose a city…</option>'+''.join(f'<option value="{e(x["url"])}">{e(x["name"])}</option>'for x in sorted(c['cities'],key=lambda x:x['name']))+'</select></label>'
 body='<div class="container">'+crumb([(c['name'],c['url'])])+f'<header class="profile-header"><p class="eyebrow">{len(c["cities"])} cities to get to know</p><h1>{e(c["name"])}</h1><p class="lede">{e(c["summary"])}</p>{cityJump}</header>'+map_html(c,large=True)+'<section class="editorial-section">'+heading('Explore by region')+regionlinks(c)+'</section><section class="editorial-section">'+heading('Cities & major suburbs',('Search and filter',url('/cities/')+'?country='+c['id']))+'<div class="city-grid">'+''.join(card(x)for x in c['cities'])+'</div></section></div>'
 page('/'+c['slug']+'/',c['name'],body,c['summary'],c['id'])
 for r in c['regions']:
  cs=[x for x in c['cities']if x['regionId']==r['id']]
  body='<div class="container">'+crumb([(c['name'],c['url']),(r['name'],r['url'])])+f'<header class="profile-header"><p class="eyebrow">{e(c["name"])}</p><h1>{e(r["name"])}</h1><p class="lede">{e(r["summary"])}</p></header>'+map_html(c,r,large=True)+'<section class="editorial-section">'+heading('Cities in this region')+'<div class="city-grid">'+''.join(card(x)for x in cs)+'</div></section></div>'
  page(f'/{c["slug"]}/regions/{r["id"]}/',r['name'],body,r['summary'],c['id'])
 for city in c['cities']:
  r=next((r for r in c['regions']if r['id']==city['regionId']),None)
  photo=''
  if city['id']in ['madrid','bilbao','barcelona']:
   credit={'madrid':'Gran Vía, 2010 · Felipe Gabaldón','bilbao':'The Bilbao estuary, 2009 · Zarateman','barcelona':'Barcelona, 2016 · Zarateman'}[city['id']]
   photo=f'<figure class="profile-photo"><img src="{url("/assets/"+city["id"]+".jpg")}" alt="{e(credit)}" width="1280" height="850"><figcaption>{e(credit)} · <a href="{url("/credits/")}">Image credits</a></figcaption></figure>'
  summary=f'<div class="quick-read"><div><p>{e(city["summary"])}</p></div><div class="quick-lists"><p><strong>Good for</strong></p><ul>'+''.join(f'<li>{e(x)}</li>'for x in city['goodFor'])+'</ul><p><strong>Keep in mind</strong></p><ul>'+''.join(f'<li>{e(x)}</li>'for x in city['tradeoffs'])+'</ul></div></div>'
  overview=f'<div class="city-overview" aria-label="City overview">{paragraphs(city.get("overview",[]))}</div>'
  sectionHtml=''.join(f'<section id="{e(s["id"])}"><h2>{e(s["title"])}</h2>{paragraphs(s["paragraphs"])}</section>'for s in city['sections'])
  toc='<nav class="toc" aria-label="On this page"><p class="eyebrow">Jump to</p>'+''.join(f'<a href="#{e(s["id"])}">{e(s["title"])}</a>'for s in city['sections'])+'</nav>'
  related=[x for x in c['cities']if x['regionId']==city['regionId']and x['id']!=city['id']][:5]
  if len(related)<3:related+=(x for x in c['cities'][:6]if x['id']!=city['id']and x not in related)
  stats=''
  if city.get('population'):p=city['population'];stats=f'<div><dt>Population</dt><dd>{int(p["value"]):,}<small>{p["year"]} · {e(p.get("unit","municipality"))}</small></dd></div>'
  aside=f'<aside class="profile-aside"><div><p class="eyebrow">At a glance</p><dl class="facts"><div><dt>Region</dt><dd>{e(city["regionName"])}</dd></div>{stats}</dl><a class="button light" href="{url("/compare/")}?cities={c["id"]}:{city["id"]},'+('FR:paris'if c['id']!='FR'else'ES:madrid')+'">Compare with another city →</a><p class="eyebrow" style="margin-top:30px">Nearby & related</p>'+''.join(f'<a class="region-row" href="{e(x["url"])}">{e(x["name"])} ↗</a>'for x in list(related)[:5])+'</div></aside>'
  sourceList='<details class="city-sources"><summary>Sources</summary><ul>'+''.join(f'<li><a href="{e(s["url"])}" target="_blank" rel="noopener noreferrer">{e(s["publisher"])}: {e(s["title"])}</a></li>'for s in city['sources'])+f'</ul><p>Updated {e(city.get("updated","2026-11-07"))}.</p></details>'
  ratings='<details class="city-scores"><summary>How this city compares</summary><p class="note">Editorial ratings, 1–5. Higher means stronger in that category. <a href="'+url('/about/')+'">How ratings work</a>.</p><div class="score-list">'+''.join(f'<article><h3>{e(k["name"])}</h3><span class="rating-value"><b>{city["ratings"][k["id"]]["score"]}</b><small>/5</small></span><p>{e(city["ratings"][k["id"]]["summary"])}</p></article>'for k in categories)+'</div></details>'
  body='<div class="container">'+crumb([(c['name'],c['url'])]+([(r['name'],r['url'])]if r else[])+[(city['name'],city['url'])])+f'<header class="profile-header city-header"><p class="eyebrow">{e(city["regionName"])} · {e(c["name"])}</p><h1>{e(city["name"])}</h1></header>'+summary+overview+photo+f'<div class="profile-layout">{toc}<div class="prose">{sectionHtml}{ratings}{sourceList}</div>{aside}</div><details class="location-details"><summary>Show location on the map</summary>'+map_html(c,city=city)+'</details></div>'
  page(f'/{c["slug"]}/cities/{city["id"]}/',city['name'],body,city['summary'],c['id'],kind='Article')
  # Keep previously shared Spanish city links working; the 8,132-place catalog is retired from navigation.
  if c['id']=='ES'and city.get('municipalityId'):
   old=OUT/'spain/places'/city['municipalityId']/'index.html';old.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(OUT/c['slug']/'cities'/city['id']/'index.html',old);routes.append(f'/spain/places/{city["municipalityId"]}/')
# Reader-facing browse and comparison pages.
options=''.join(f'<option value="{c["id"]}">{e(c["name"])}</option>'for c in countries)
browse=f'<div class="container"><header class="profile-header"><p class="eyebrow">Spain · France · Italy</p><h1>Find a city you’d enjoy.</h1><p class="lede">Big capitals, regional favorites and major suburbs. Browse by place, or look for what matters to you.</p></header><form id="browse-form" class="browse-form"><label>Search<input id="browse-query" name="q" type="search" placeholder="City or region…"></label><label>Country<select id="browse-country" name="country"><option value="">All countries</option>{options}</select></label><label>Region<select id="browse-region" name="region"><option value="">All regions</option></select></label><label>What matters most?<select name="theme"><option value="">Anything</option>'+''.join(f'<option value="{k["id"]}">{e(k["name"])}</option>'for k in categories)+'</select></label><label>Sort<select name="sort"><option value="name">Name</option><option value="population">Population</option><option value="affordability">More affordable first</option></select></label><button class="button" type="submit">Find cities →</button></form><p id="browse-count" class="browse-count" role="status">'+str(len(citylist))+' cities</p><div id="browse-results" class="city-grid">'+''.join(card(x)for x in citylist)+'</div></div>'
page('/cities/','Browse cities',browse,'Find cities in Spain, France and Italy by region, affordability, jobs, culture, social life, transport, outdoors and weather.')
comparison=f'<div class="container"><header class="profile-header"><p class="eyebrow">Choose two or three cities</p><h1>Compare places.</h1><p class="lede">A quick side-by-side look at the things that shape everyday life.</p></header><form id="compare-form" class="compare-form"><label>First city<select name="a" required aria-label="First city"></select></label><label>Second city<select name="b" required aria-label="Second city"></select></label><label>Third city (optional)<select name="c" aria-label="Third city"></select></label><button class="button" type="submit">Compare →</button></form><p class="rating-note">Editorial ratings, 1–5. Higher means stronger in that category; affordability runs from expensive to easier on a local budget. The descriptions explain the tradeoffs. <a href="{url("/about/")}">How ratings work</a>.</p><div id="compare-results" aria-live="polite"><p>Choose your cities above to see the comparison.</p></div></div>'
page('/compare/','Compare cities',comparison,'Compare housing costs, career opportunities, transport, culture, social life, outdoors and weather across European cities.')
about=f'<div class="plain-page"><p class="eyebrow">About the atlas</p><h1>A guide to getting to know a place.</h1><p>This is a personal city atlas for curious readers. It covers a selection of cities and major suburbs in Spain, France and Italy: the obvious capitals, useful regional centers and places with a distinct character.</p><p>Read the short version when you want a quick impression, or spend more time with the neighborhoods, history, food, housing, work and cultural life. The selection favors places people might seriously want to understand or live in.</p><h2>How ratings work</h2><p>Ratings are editorial judgments from 1 to 5, not statistical rankings or guarantees. Each category comes with an explanation. A high score means a relative strength across this selection of cities; it does not mean a place suits everyone. There is no overall score.</p>'+''.join(f'<p><strong>{e(k["name"])}:</strong> {e(k["description"])}</p>'for k in categories)+'<p>Climate is especially personal: a higher rating favors milder everyday conditions. If you love hot summers, cold winters or tropical weather, the description matters more than the number. Career prospects also depend heavily on your occupation, language skills and right to work.</p><h2>Sources</h2><p>City pages draw on public statistics, local and regional institutions, transport operators, cultural organizations and reporting. Open “Sources” at the end of a page for the references. Where population appears, its year and geographic unit appear alongside it. A city’s reputation and everyday feel are editorial descriptions.</p><p>The maps use packaged administrative boundaries, so the main geographic view does not depend on a remote tile service. Photo and map credits are <a href="'+url('/credits/')+'">listed here</a>.</p></div>'
page('/about/','About and ratings',about,'How to use the city guides and understand the editorial category ratings.')
images=read(DATA/'images.json',[])
credits='<div class="plain-page"><h1>Sources & credits</h1><p>References for each city are tucked into its “Sources” section. The complete bibliography is below.</p><h2>Maps</h2><p>© EuroGeographics for the administrative boundaries, distributed by Eurostat GISCO. 2024 geography, WGS84. Used for this independent noncommercial publication. <a href="https://ec.europa.eu/eurostat/web/gisco/geodata/statistical-units">Dataset terms</a>.</p><h2>Photography</h2>'+''.join(f'<p><a href="{e(x["source"])}">{e(x["title"])}</a> · {e(x["creator"])} · {e(x["date"])} · <a href="{e(x["licenseURL"])}">{e(x["license"])}</a>. {e(x["modifications"])}</p>'for x in images)+'<h2>City references</h2>'
for c in countries:
 credits+=f'<h3>{e(c["name"])}</h3><ul>'
 sources={s['url']:s for city in c['cities']for s in city['sources']}
 credits+=''.join(f'<li><a href="{e(s["url"])}">{e(s["publisher"])}: {e(s["title"])}</a></li>'for s in sources.values())+'</ul>'
credits+='<h2>Software</h2><p>MapLibre GL JS, BSD 3-Clause. Full dependency notices are preserved with the source.</p></div>';page('/credits/','Sources and credits',credits,'Sources, map data and photo credits.')
# Retain a useful landing for old directory links without exposing thousands of irrelevant tiny places.
for c in countries:
 target=OUT/c['slug']/'directory'/'index.html';target.parent.mkdir(parents=True,exist_ok=True);target.write_text(f'<!doctype html><html lang="en"><meta charset="utf-8"><meta http-equiv="refresh" content="0;url={url("/cities/")}?country={c["id"]}"><title>Browse {e(c["name"])}</title><a href="{url("/cities/")}?country={c["id"]}">Browse cities in {e(c["name"])}</a></html>');routes.append('/'+c['slug']+'/directory/')
page('/404/','Page not found','<div class="plain-page"><h1>We couldn’t find that page.</h1><p><a href="'+url('/cities/')+'">Browse the cities</a> or use the search box.</p></div>');shutil.copyfile(OUT/'404/index.html',OUT/'404.html')
(OUT/'.nojekyll').write_text('')
(OUT/'robots.txt').write_text('User-agent: *\nAllow: /\n'+('Sitemap: '+origin+url('/sitemap.xml')+'\n'if origin else ''))
(OUT/'sitemap.xml').write_text('<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+''.join(f'<url><loc>{e(origin+url(p))}</loc></url>'for p in routes if '/places/'not in p and '/directory/'not in p and p!='/404/')+'</urlset>')
(ROOT/'dist/server').mkdir(parents=True,exist_ok=True);(ROOT/'dist/.openai').mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/'src/worker.js',ROOT/'dist/server/index.js');shutil.copyfile(ROOT/'.openai/hosting.json',ROOT/'dist/.openai/hosting.json')
node=shutil.which('node')or'/Users/ryankeating/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node';subprocess.run([node,'scripts/bundle.mjs'],check=True)
summary={'countries':{c['name']:len(c['cities'])for c in countries},'cities':len(citylist),'routes':len(routes),'draft':args.draft,'output':str(OUT)};(OUT/'data/release.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
