#!/usr/bin/env python3
"""Audit HTTP accessibility of bibliography and geographic provenance URLs.
Uses bounded parallel HEAD requests, GET fallback where HEAD is unsupported.
A successful request is not source verification; blocked/transient requests are inconclusive.
Network failure is reported as a skipped audit, never as a successful external-link test.
"""
from pathlib import Path
from datetime import datetime,timezone
from urllib.parse import urlsplit
from urllib.request import Request,urlopen
from urllib.error import HTTPError,URLError
from concurrent.futures import ThreadPoolExecutor,as_completed
from collections import Counter
import argparse,html,json,re,socket,ssl,sys,time
ROOT=Path(__file__).resolve().parents[1]
def valid_url(u):
 try:
  p=urlsplit(u);return isinstance(u,str)and p.scheme in('http','https')and bool(p.hostname)and not any(x.isspace()for x in u)and p.username is None
 except (ValueError,AttributeError,TypeError):return False
def collect(root):
 refs={}
 for filename in ['sources-cities.json','sources-regions.json','geography/provenance.json','countries.json']:
  p=root/'public/data'/filename
  if not p.exists():continue
  d=json.loads(p.read_text())
  def walk(x,owner=filename):
   if isinstance(x,dict):
    owner=x.get('id',owner)
    for k,v in x.items():
     if k in('url','downloadUrl','licenseUrl')and isinstance(v,str):refs.setdefault(v,set()).add(owner)
     elif isinstance(v,(list,dict)):walk(v,owner)
   elif isinstance(x,list):
    for v in x:walk(v,owner)
  walk(d)
 # Include outward links present in the tested release, such as photo credits,
 # without queueing thousands of absolute self-canonical links.
 own_hosts=set()
 config=root/'.openai/hosting.json'
 if config.exists():
  d=json.loads(config.read_text())
  for key in ['expected_url','current_live_url','current_preview_url']:
   if d.get(key):own_hosts.add(urlsplit(d[key]).netloc)
 for page in (root/'dist/client').rglob('*.html'):
  for match in re.finditer(r'''href\s*=\s*["'](https?://[^"']+|//[^"']+)["']''',page.read_text(encoding='utf-8'),re.I):
   url=html.unescape(match.group(1))
   if url.startswith('//'):url='https:'+url
   if urlsplit(url).netloc not in own_hosts:refs.setdefault(url,set()).add('published-html-link')
 return refs
def check(url,timeout):
 start=time.monotonic();status=None;method='HEAD';final=url
 headers={'User-Agent':'EuropeanUrbanAtlas-LinkAudit/1.0 (source accessibility check)','Accept':'*/*'}
 try:
  try:
   with urlopen(Request(url,headers=headers,method='HEAD'),timeout=timeout)as response:status=response.status;final=response.geturl();ctype=response.headers.get('Content-Type')
  except HTTPError as ex:
   if ex.code not in(405,501):raise
   method='GET';headers['Range']='bytes=0-1023'
   with urlopen(Request(url,headers=headers,method='GET'),timeout=timeout)as response:status=response.status;final=response.geturl();ctype=response.headers.get('Content-Type');response.read(1024)
  result='accessible'if status and status<400 else'needs-review'
  return {'url':url,'result':result,'httpStatus':status,'finalURL':final,'method':method,'contentType':ctype,'elapsedSeconds':round(time.monotonic()-start,2)}
 except HTTPError as ex:
  result='broken'if ex.code in(404,410)else'access-blocked'if ex.code in(401,403,407,429)else'transient-or-server-error'
  return {'url':url,'result':result,'httpStatus':ex.code,'finalURL':ex.geturl(),'method':method,'detail':str(ex),'elapsedSeconds':round(time.monotonic()-start,2)}
 except (URLError,TimeoutError,socket.timeout,OSError,ssl.SSLError)as ex:
  detail=str(ex);reason=getattr(ex,'reason',ex)
  result='network-unavailable'if isinstance(reason,socket.gaierror)or any(t in detail.lower()for t in['nodename nor servname','name or service not known','network is unreachable','operation not permitted','permission denied'])else'inconclusive-network-error'
  return {'url':url,'result':result,'httpStatus':None,'method':method,'detail':detail,'elapsedSeconds':round(time.monotonic()-start,2)}
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--root',type=Path,default=ROOT);ap.add_argument('--output',type=Path);ap.add_argument('--skip-network',action='store_true');ap.add_argument('--timeout',type=float,default=7);ap.add_argument('--workers',type=int,default=6);ap.add_argument('--limit',type=int);args=ap.parse_args()
 refs=collect(args.root);urls=sorted(refs);invalid=[u for u in urls if not valid_url(u)];results=[{'url':u,'result':'invalid-url-syntax','sourceIds':sorted(refs[u])}for u in invalid];pending=[u for u in urls if u not in invalid];skipped=None
 if args.limit:pending=pending[:args.limit]
 if args.skip_network:skipped='Network audit explicitly skipped in this execution environment. URL syntax checked; no HTTP-accessibility pass claimed.'
 elif pending:
  probe=check(next((u for u in pending if urlsplit(u).hostname=='www.ine.es'),pending[0]),args.timeout)
  probe['sourceIds']=sorted(refs[probe['url']]);results.append(probe);pending.remove(probe['url'])
  if probe['result']=='network-unavailable':skipped='Network/DNS access is unavailable to this process. Remaining URLs were not requested. This is not evidence that they are broken.'
  else:
   with ThreadPoolExecutor(max_workers=max(1,min(args.workers,12)))as pool:
    jobs={pool.submit(check,u,args.timeout):u for u in pending}
    for job in as_completed(jobs):
     r=job.result();r['sourceIds']=sorted(refs[r['url']]);results.append(r)
 if skipped:
  for u in pending:results.append({'url':u,'result':'not-checked','sourceIds':sorted(refs[u]),'detail':skipped})
 counts=dict(Counter(r['result']for r in results));broken=counts.get('broken',0)+counts.get('invalid-url-syntax',0)
 report={'generatedAt':datetime.now(timezone.utc).isoformat(),'referenceDate':'2026-11-07','status':'skipped-network-unavailable'if skipped else'completed-with-issues'if broken else'completed','totalUniqueURLs':len(urls),'counts':counts,'allURLsHTTPChecked':not skipped and len(results)==len(urls),'brokenCount':broken,'reason':skipped,'limitations':['HEAD/GET accessibility is not a substantive verification of source contents.','Authentication, anti-bot responses, timeouts and server errors remain inconclusive; they are not silently counted as working or permanently broken.','Links can change after this dated audit.'], 'results':sorted(results,key=lambda x:x['url'])}
 out=args.output or args.root/'docs/EXTERNAL-LINKS.json';out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({k:report[k]for k in['status','totalUniqueURLs','counts','allURLsHTTPChecked','brokenCount','reason']},ensure_ascii=False,indent=2))
 return 1 if broken else 0
if __name__=='__main__':sys.exit(main())
