#!/usr/bin/env python3
"""Country-independent geographic collection adapter and graph validator.
CLI: --country ES --validate --summary [--output PATH]; --check-config.
Consumers can import load_country(), validate_graph(), read_registry(). No Spanish field names are embedded in the adapter.
"""
from pathlib import Path
import argparse,json,re,sys,collections,math
from datetime import date
ROOT=Path(__file__).resolve().parents[1]

def read_json(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def read_registry(root=ROOT):return read_json(Path(root)/'public/data/countries.json')
def resolve_public(path,root=ROOT):
 if not path or not path.startswith('/data/'):raise ValueError('Dataset path must be an absolute /data/ path')
 public=(Path(root)/'public').resolve();resolved=(public/path.lstrip('/')).resolve()
 if not resolved.is_relative_to(public):raise ValueError('Dataset escapes public directory')
 return resolved

def entity_id(country,namespace,native):return f'{country}:{namespace}:{native}'
def registry_checks(registry,root=ROOT):
 errors=[];countries=registry.get('countries',[]);ids=[c.get('id') for c in countries]
 if registry.get('schemaVersion')!='1.0.0':errors.append('Unsupported registry schemaVersion')
 if len(ids)!=len(set(ids)):errors.append('Duplicate country IDs')
 if registry.get('defaultCountryId') not in ids:errors.append('Default country is not registered')
 for c in countries:
  cid=c.get('id','')
  if not re.fullmatch('[A-Z]{2}',cid):errors.append('Invalid country ID '+cid)
  if not re.fullmatch('/[a-z][a-z-]*',c.get('routePrefix','')):errors.append(cid+': invalid routePrefix')
  if c.get('enabled') and not c.get('adapter',{}).get('collections'):errors.append(cid+': enabled country has no adapter collections')
  if c.get('enabled'):
   for key,value in c.get('datasets',{}).items():
    for path in value if isinstance(value,list) else [value]:
     if path and not resolve_public(path,root).is_file():errors.append(cid+': missing '+key+' dataset '+path)
  names=[x.get('namespace') for x in c.get('adapter',{}).get('collections',[])]
  if len(names)!=len(set(names)):errors.append(cid+': duplicate collection namespace')
  if not c.get('enabled') and c.get('coverage',{}).get('municipalInventory')=='complete-validated':errors.append(cid+': disabled country claims validated complete inventory')
  if c.get('status')=='configured-not-imported' and any(c.get('datasets',{}).get(k) for k in ['municipalities','regions','divisions']):errors.append(cid+': unimported country has active inventory path')
 return errors

def load_country(country_id,root=ROOT,include_graph=True):
 registry=read_registry(root);problems=registry_checks(registry,root)
 if problems:raise ValueError('; '.join(problems))
 config=next((c for c in registry['countries'] if c['id']==country_id),None)
 if not config:raise ValueError('Unknown country '+country_id)
 if not config['enabled']:raise ValueError(country_id+' is configured but has no imported atlas; run the country acquisition process before enabling it')
 data={};entities=[];cid=config['id']
 entities.append({'id':entity_id(cid,'country',cid),'countryId':cid,'namespace':'country','nativeId':cid,'name':config['name'],'aliases':config.get('aliases',[]),'type':'country','sourceRefs':config.get('sourceIds',[]),'dataRef':'/data/countries.json','metadata':{'status':config['status'],'routePrefix':config['routePrefix']}})
 for mapping in config['adapter']['collections']:
  rows=read_json(resolve_public(mapping['path'],root))
  if mapping.get('arrayKey'):rows=rows[mapping['arrayKey']]
  if not isinstance(rows,list):raise ValueError(mapping['path']+' must contain an array')
  data[mapping['key']]=rows
  for row in rows:
   native=str(row[mapping['idField']]);eid=entity_id(cid,mapping['namespace'],native)
   rawkind=row.get(mapping.get('typeField',''),'')
   ent={'id':eid,'countryId':cid,'namespace':mapping['namespace'],'nativeId':native,'name':row[mapping['nameField']],'aliases':row.get(mapping.get('aliasesField',''),[]),'type':mapping.get('typeMap',{}).get(rawkind,mapping['defaultType']),'legalType':rawkind or mapping.get('legalType',mapping['defaultType']),'sourceRefs':list(dict.fromkeys([*mapping.get('sourceRefs',[]),*[row[k] for k in mapping.get('sourceFields',[]) if row.get(k)]])),'dataRef':mapping['path']+'#'+native,'metadata':{k:row[k] for k in mapping.get('metadataFields',[]) if k in row}}
   if mapping.get('codeScheme'):ent['nativeIdentifiers']=[{'scheme':mapping['codeScheme'],'value':native}]
   coords=mapping.get('coordinates')
   if coords and row.get(coords['lat']) is not None and row.get(coords['lon']) is not None:ent['coordinates']={'lat':row[coords['lat']],'lon':row[coords['lon']],'definition':coords['definition']}
   if mapping.get('geometry'):
    g=mapping['geometry'];path=g['pathTemplate'].format_map(row)
    ent['geometryRef']={'path':path,'idProperty':g['idProperty'],'idValue':native,'referencePeriod':g['referencePeriod'],'crs':'EPSG:4326','sourceRefs':g['sourceRefs']}
   stat=mapping.get('population')
   if stat and row.get(stat['valueField']) is not None:
    year=str(row[stat['yearField']]);ent['statistics']=[{'id':eid+':population:'+year,'indicator':'population','value':row[stat['valueField']],'unit':'persons','referencePeriod':year+'-01-01','geographicEntityId':eid,'definition':row.get(stat.get('definitionField','')) or stat['definition'],'sourceRefs':[row[stat['sourceField']]] if row.get(stat.get('sourceField','')) else stat['sourceRefs'],'aggregation':stat.get('aggregation','none')}]
   if 'coverageTier' in row:ent['coverageTier']=row['coverageTier']
   entities.append(ent)
 relationships=[]
 relation_manifest=read_json(resolve_public(config['adapter']['relationshipsPath'],root))
 for mapping in relation_manifest['edgeSets']:
  if mapping['countryId']!=cid:continue
  rows=data.get(mapping['datasetKey'])
  if rows is None:raise ValueError('Relationship dataset is not loaded: '+mapping['datasetKey'])
  for row in rows:
   raw=row.get(mapping.get('targetField','')) if 'targetField' in mapping else mapping['targetConstant']
   if raw is None:continue
   values=raw if isinstance(raw,list) else [raw]
   source_native=str(row[mapping['sourceField']]);source=entity_id(cid,mapping['sourceNamespace'],source_native)
   for value in values:
    target=entity_id(cid,mapping['targetNamespace'],str(value));rtype=mapping['type'];evidence=mapping['evidenceType']
    for exc in mapping.get('exceptions',[]):
     if all(row.get(k)==v for k,v in exc['when'].items()):rtype=exc.get('type',rtype);evidence=exc.get('evidenceType',evidence)
    relationships.append({'id':source+'|'+rtype+'|'+target,'from':source,'to':target,'type':rtype,'evidenceType':evidence,'referencePeriod':mapping.get('referencePeriod'),'sourceRefs':mapping['sourceRefs'],'method':mapping.get('method','Direct correspondence in the cited source')})
 for edge in relation_manifest.get('explicitEdges',[]):
  if edge.get('countryId')==cid:relationships.append({k:v for k,v in edge.items() if k!='countryId'})
 graph={'schemaVersion':'1.0.0','countryId':cid,'entities':entities,'relationships':list({r['id']:r for r in relationships}.values())}
 return {'country':config,'collections':data,'graph':graph} if include_graph else {'country':config,'collections':data}

def validate_graph(graph,config,root=ROOT):
 errors=[];entities=graph['entities'];ids=[e['id'] for e in entities];idset=set(ids);geometry_cache={}
 if len(ids)!=len(idset):errors.append('Duplicate normalized geographic IDs')
 for ent in entities:
  if not ent['sourceRefs']:errors.append('Entity has no source reference: '+ent['id'])
  if ent['countryId']!=graph['countryId']:errors.append('Country mismatch: '+ent['id'])
  coords=ent.get('coordinates')
  if coords and not(-90<=coords['lat']<=90 and -180<=coords['lon']<=180):errors.append('Invalid coordinate: '+ent['id'])
  for stat in ent.get('statistics',[]):
   valid_period=True
   try:date.fromisoformat(stat['referencePeriod'])
   except (ValueError,TypeError):valid_period=False
   value=stat['value']
   if stat['geographicEntityId']!=ent['id'] or isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or value<0 or not valid_period:errors.append('Invalid statistic: '+stat['id'])
  ref=ent.get('geometryRef')
  if ref:
   cache_key=(ref['path'],ref['idProperty'])
   if cache_key not in geometry_cache:
    try:
     geometry=read_json(resolve_public(ref['path'],root))
     if geometry.get('type')!='FeatureCollection':raise ValueError('Expected GeoJSON FeatureCollection')
     geometry_cache[cache_key]={str(f['properties'][ref['idProperty']]) for f in geometry['features'] if f.get('geometry')}
    except (ValueError,KeyError,FileNotFoundError):geometry_cache[cache_key]=set()
   if ref['idValue'] not in geometry_cache[cache_key]:errors.append('Missing geometry feature for '+ent['id'])
  if config.get('coverage',{}).get('municipalInventory')=='complete-validated' and ent['type']=='municipality':
   if not ent.get('geometryRef') or not ent.get('coordinates') or not any(st['indicator']=='population' for st in ent.get('statistics',[])):errors.append('Complete municipal inventory lacks geometry, location or population: '+ent['id'])
 relids=set();parents=collections.defaultdict(list);outgoing=collections.defaultdict(list)
 for rel in graph['relationships']:
  if rel['id'] in relids:errors.append('Duplicate relationship: '+rel['id'])
  relids.add(rel['id']);outgoing[rel['from']].append(rel)
  if rel['from'] not in idset or rel['to'] not in idset:errors.append('Broken geographic relationship: '+rel['id'])
  if rel['from']==rel['to']:errors.append('Self relationship: '+rel['id'])
  if rel['type']=='administrative-parent':parents[rel['from']].append(rel['to'])
  if rel['evidenceType']=='derived-spatial' and not rel.get('method'):errors.append('Inferred relationship lacks method')
 visited=set();active=set()
 def walk(i):
  if i in active:errors.append('Administrative cycle at '+i);return
  if i in visited:return
  active.add(i)
  for parent in parents.get(i,[]):walk(parent)
  active.remove(i);visited.add(i)
 for i in ids:walk(i)
 counts=collections.Counter(e['type'] for e in entities)
 for check in config['validation'].get('entityCounts',[]):
  count=sum(1 for e in entities if all(e.get(k)==v for k,v in check['where'].items()))
  if count!=check['expected']:errors.append(f"{check['label']}: expected {check['expected']}, got {count}")
 # Each primary municipality must have exactly one primary administrative parent when configured.
 for rule in config['validation'].get('requiredParents',[]):
  for ent in entities:
   if ent['namespace']!=rule['sourceNamespace']:continue
   matches=[r for r in outgoing[ent['id']] if r['type'] in rule['relationshipTypes'] and r['to'].split(':')[1]==rule['targetNamespace']]
   if len(matches)!=1:errors.append('Expected one '+rule['targetNamespace']+' reference for '+ent['id'])
 return errors

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--country',default=None);parser.add_argument('--check-config',action='store_true');parser.add_argument('--validate',action='store_true');parser.add_argument('--summary',action='store_true');parser.add_argument('--output',type=Path);args=parser.parse_args()
 registry=read_registry();errors=registry_checks(registry)
 if errors:raise ValueError('; '.join(errors))
 if args.check_config and not args.country:
  print(json.dumps({'schemaVersion':registry['schemaVersion'],'countries':[{'id':c['id'],'enabled':c['enabled'],'status':c['status']} for c in registry['countries']],'configValid':True},indent=2));return
 cid=args.country or registry['defaultCountryId'];result=load_country(cid)
 errors=validate_graph(result['graph'],result['country'])
 if errors:raise ValueError('\n'.join(errors[:30]))
 if args.output:
  args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(result['graph'],ensure_ascii=False,separators=(',',':')),encoding='utf-8')
 print(json.dumps({'countryId':cid,'valid':True,'entityCount':len(result['graph']['entities']),'relationshipCount':len(result['graph']['relationships']),'byType':dict(collections.Counter(e['type'] for e in result['graph']['entities'])),'status':result['country']['status'],'output':str(args.output) if args.output else None},indent=2))
if __name__=='__main__':
 try:main()
 except (ValueError,KeyError,FileNotFoundError) as exc:print(str(exc),file=sys.stderr);sys.exit(2)
