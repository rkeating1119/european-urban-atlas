#!/usr/bin/env python3
"""Exercise generic publication with synthetic, temporary French/Italian source fixtures.
These fixtures are never copied into the real public dataset.
"""
from pathlib import Path
import copy,json,tempfile
from geographic_contract import read_registry,load_country
from render_country import render_configured_countries,country_runtime

def write(root,path,value):
 target=root/'public'/path.lstrip('/');target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps(value,ensure_ascii=False));return target

def main():
 calls=[]
 result=render_configured_countries(Path('/tmp/atlas-disabled-country-render-check'),lambda *args:calls.append(args))
 assert not calls and not result['routes'],'Disabled countries emitted public pages'
 for cid,region,division,commune in [('FR','94','2A','2A001'),('IT','01','001','001001')]:
  with tempfile.TemporaryDirectory(prefix='atlas-render-fixture-') as tmp:
   root=Path(tmp);out=root/'dist/client';cfg=copy.deepcopy(next(c for c in read_registry()['countries'] if c['id']==cid));cfg.update(enabled=True,status='in-progress',name='Synthetic '+cid+' fixture',sources=[{'id':'fixture-source','publisher':'Synthetic test fixture','title':'Renderer regression fixture','url':'https://example.org/fixture','accessed':'2026-11-07'}],sourceIds=['fixture-source']);cfg['mapAttribution']='Synthetic test geometry; no real geographic coverage';cfg['coverage']={'municipalInventory':'partial','editorial':'partial','releaseClaim':'Synthetic test fixture, not published atlas data'}
   ns={'regions':'region','divisions':'department' if cid=='FR' else 'division','municipalities':'commune' if cid=='FR' else 'comune'}
   cfg['datasets']={'countryOverview':'/data/country.json','regions':'/data/regions-geographic.json','divisions':'/data/divisions.json','municipalities':'/data/municipalities.json','regionProfiles':'/data/region-profiles.json','cityProfiles':'/data/cities.json','sources':['/data/sources.json'],'evidence':['/data/claims.json'],'countryBoundary':None,'boundaries':'/data/regions.geojson','provenance':None}
   cols=[]
   for key,kind in [('regions','administrative-region'),('divisions','administrative-division'),('municipalities','municipality')]:
    cols.append({'key':key,'namespace':ns[key],'path':cfg['datasets'][key],'idField':'code','nameField':'label','defaultType':kind,'sourceRefs':['fixture-source'],'coordinates':{'lat':'lat','lon':'lon','definition':'Synthetic coordinate'},'geometry':{'pathTemplate':'/data/'+key+'.geojson','idProperty':'OFFICIAL_CODE','referencePeriod':'2025','sourceRefs':['fixture-source']}})
   cfg['adapter']={'collections':cols,'relationshipsPath':'/data/relationships.json'};cfg['validation']={'entityCounts':[{'label':'Fixture municipality','where':{'namespace':ns['municipalities']},'expected':1}],'requiredParents':[]}
   write(root,'/data/countries.json',{'schemaVersion':'1.0.0','defaultCountryId':cid,'countries':[cfg]})
   for key,code,label,extra in [('regions',region,'Synthetic region',{}),('divisions',division,'Synthetic division',{'regionCode':region}),('municipalities',commune,'Synthetic municipality',{'divisionCode':division})]:
    write(root,cfg['datasets'][key],[dict(code=code,label=label,lat=42,lon=9,**extra)])
    write(root,'/data/'+key+'.geojson',{'type':'FeatureCollection','features':[{'type':'Feature','properties':{'OFFICIAL_CODE':code},'geometry':{'type':'Polygon','coordinates':[[[8,41],[10,41],[10,43],[8,43],[8,41]]]}}]})
   section={'id':'identity','title':'An actual supplied section','body':'Synthetic text with <script> markup must be escaped.','sourceIds':['fixture-source'],'evidenceType':'editorial-interpretation'}
   write(root,'/data/country.json',{'name':cfg['name'],'thesis':'Synthetic country thesis','sections':[section],'sourceIds':['fixture-source']});write(root,'/data/region-profiles.json',[{'id':region,'name':'Synthetic region','sections':[section],'sourceIds':['fixture-source']}]);write(root,'/data/cities.json',[{'id':'synthetic-city','municipalityId':commune,'name':'Synthetic municipality','sections':[section],'sourceIds':['fixture-source']}]);write(root,'/data/sources.json',[]);write(root,'/data/claims.json',[])
   edges=[]
   for key,target,field in [('municipalities','divisions','divisionCode'),('divisions','regions','regionCode')]:edges.append({'id':key+'-'+target,'countryId':cid,'datasetKey':key,'sourceNamespace':ns[key],'sourceField':'code','targetNamespace':ns[target],'targetField':field,'type':'administrative-parent','evidenceType':'official-correspondence','referencePeriod':'2025','sourceRefs':['fixture-source']})
   write(root,'/data/relationships.json',{'schemaVersion':'1.0.0','edgeSets':edges,'explicitEdges':[]})
   emitted={}
   def page(path,title,body,description='',kind='WebPage'):
    emitted[path]=body;target=out/path.lstrip('/')/'index.html';target.parent.mkdir(parents=True,exist_ok=True);target.write_text('<!doctype html><html><body>'+body+'</body></html>')
   result=render_configured_countries(out,page,root)
   base=cfg['routePrefix'];seg=cfg['routeSegments'];expected=[base+'/',base+'/'+seg['regions']+'/'+region+'/',base+'/'+seg['divisions']+'/'+division+'/',base+'/'+seg['municipalities']+'/'+commune+'/',base+'/'+seg['directory']+'/',base+'/sources/',base+'/evidence/']
   assert set(expected)==set(result['routes'])
   runtime=json.loads((out/'data/runtime'/f'{cid}.json').read_text());assert runtime['places'][0]['id']==commune and runtime['places'][0]['provinceId']==division and runtime['places'][0]['regionId']==region
   for key in ['countries','country','regions','provinces']:
    geometry=json.loads((out/runtime['boundaries'][key].lstrip('/')).read_text());assert geometry['features'];assert all('id' in f['properties'] and f['properties']['CNTR_CODE']==cid for f in geometry['features'])
   body=emitted[base+'/'+seg['municipalities']+'/'+commune+'/'];assert f'data-country="{cid}"' in body and '&lt;script&gt;' in body and '<script>' not in body and 'href="/spain/' not in body
   assert cfg['labels']['firstLevelSingular'] in emitted[base+'/'+seg['directory']+'/']
   assert runtime['provinces'][0]['regionId']==region
   # The source has only commune -> department -> region. No redundant direct
   # commune -> region edge is available to rescue region filtering/maps.
   projection=load_country(cid,root);graph=projection['graph']
   municipality_id=next(e['id'] for e in graph['entities'] if e['namespace']==ns['municipalities'])
   division_id=next(e['id'] for e in graph['entities'] if e['namespace']==ns['divisions'])
   region_id=next(e['id'] for e in graph['entities'] if e['namespace']==ns['regions'])
   assert not any(r['from']==municipality_id and r['to']==region_id for r in graph['relationships'])
   # A statistical parent is valid ancestry too; duplicate paths to the same
   # region must deduplicate instead of becoming an artificial ambiguity.
   statistical=copy.deepcopy(projection)
   for rel in statistical['graph']['relationships']:
    if rel['from']==division_id:rel['type']='statistical-parent'
   statistical['graph']['relationships'].append({'from':municipality_id,'to':region_id,'type':'administrative-parent'})
   derived=country_runtime(statistical,out/'statistical-check',root,[])
   assert derived['places'][0]['regionId']==region
   # An overlapping FUA-style membership is deliberately excluded from ancestry.
   overlapping=copy.deepcopy(projection);other=copy.deepcopy(next(e for e in graph['entities'] if e['id']==region_id));other['id']=cid+':region:OTHER';other['nativeId']='OTHER';other.pop('geometryRef',None)
   overlapping['graph']['entities'].append(other)
   overlapping['graph']['relationships'].append({'from':municipality_id,'to':other['id'],'type':'within-functional-urban-area'})
   derived=country_runtime(overlapping,out/'overlap-check',root,[])
   assert derived['places'][0]['regionId']==region
   # Ambiguous administrative ancestry must stop publication, not choose one.
   ambiguous=copy.deepcopy(overlapping);ambiguous['graph']['relationships'][-1]['type']='statistical-parent'
   try:country_runtime(ambiguous,out/'ambiguous-check',root,[])
   except ValueError as exc:assert 'ambiguous' in str(exc)
   else:raise AssertionError('Ambiguous regional ancestry was accepted')
   # Statistical and administrative parents together must still be acyclic.
   cyclic=copy.deepcopy(projection);cyclic['graph']['relationships'].append({'from':region_id,'to':division_id,'type':'statistical-parent'})
   try:country_runtime(cyclic,out/'cycle-check',root,[])
   except ValueError as exc:assert 'cyclic' in str(exc)
   else:raise AssertionError('Mixed administrative/statistical cycle was accepted')

 print('PASS: no disabled-country pages; synthetic FR/IT country, region, division, municipality, directory/source/evidence routes; native identifiers, section content escaping, runtime map normalization, variable administrative labels, transitive administrative/statistical parents, ignored overlapping memberships and ambiguity/cycle rejection.')
if __name__=='__main__':main()
