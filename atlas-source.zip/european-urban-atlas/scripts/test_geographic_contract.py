#!/usr/bin/env python3
"""Regression checks for cross-country identifier handling and overlapping geography."""
import json,tempfile,copy
from pathlib import Path
from geographic_contract import load_country,validate_graph,read_registry,ROOT

def write(root,path,value):
 target=root/'public'/path.lstrip('/');target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps(value))

def run():
 # Real FR/IT configs may not silently pretend imported content exists.
 for cid in ['FR','IT']:
  try:load_country(cid)
  except ValueError as err:assert 'configured' in str(err)
  else:raise AssertionError('An unimported country was silently activated')
 for cid,region,division,municipality,namespace in [('FR','94','2A','2A001','commune'),('IT','01','001','001001','comune')]:
  with tempfile.TemporaryDirectory(prefix='atlas-country-contract-') as tmp:
   root=Path(tmp);source='synthetic-contract-test';cols=[]
   for key,ns,kind in [('regions','region','administrative-region'),('divisions','division','administrative-division'),('municipalities',namespace,'municipality'),('functionalUrbanAreas','fua','functional-urban-area')]:
    cols.append({'key':key,'namespace':ns,'path':'/data/'+key+'.json','idField':'officialCode','nameField':'officialLabel','defaultType':kind,'sourceRefs':[source]})
   cfg={'id':cid,'routePrefix':'/test-country','enabled':True,'status':'in-progress','name':'Synthetic test country','sourceIds':[source],'datasets':{c['key']:c['path'] for c in cols},'coverage':{'municipalInventory':'partial'},'adapter':{'collections':cols,'relationshipsPath':'/data/relationships.json'},'validation':{'entityCounts':[{'label':'municipal fixture','where':{'namespace':namespace},'expected':1}],'requiredParents':[{'sourceNamespace':namespace,'targetNamespace':'division','relationshipTypes':['administrative-parent']}]}}
   write(root,'/data/countries.json',{'schemaVersion':'1.0.0','defaultCountryId':cid,'countries':[cfg]})
   write(root,'/data/regions.json',[{'officialCode':region,'officialLabel':'Test region'}]);write(root,'/data/divisions.json',[{'officialCode':division,'officialLabel':'Test division','regionCode':region}]);write(root,'/data/municipalities.json',[{'officialCode':municipality,'officialLabel':'Test municipality','divisionCode':division,'fuaCodes':['F1','F2']}]);write(root,'/data/functionalUrbanAreas.json',[{'officialCode':'F1','officialLabel':'Test FUA 1'},{'officialCode':'F2','officialLabel':'Test FUA 2'}])
   def edge(id,ns,key,targetns,targetfield,kind,evidence):return {'id':id,'countryId':cid,'datasetKey':key,'sourceNamespace':ns,'sourceField':'officialCode','targetNamespace':targetns,'targetField':targetfield,'type':kind,'evidenceType':evidence,'referencePeriod':'2025-01-01','sourceRefs':[source],'method':'Synthetic relationship fixture'}
   write(root,'/data/relationships.json',{'schemaVersion':'1.0.0','edgeSets':[edge('parent',namespace,'municipalities','division','divisionCode','administrative-parent','official-correspondence'),edge('fua',namespace,'municipalities','fua','fuaCodes','within-functional-urban-area','derived-spatial')],'explicitEdges':[]})
   result=load_country(cid,root);graph=result['graph'];assert not validate_graph(graph,cfg)
   ent=next(e for e in graph['entities'] if e['namespace']==namespace);assert ent['nativeId']==municipality and ent['id']==f'{cid}:{namespace}:{municipality}'
   matches=[r for r in graph['relationships'] if r['from']==ent['id'] and r['type']=='within-functional-urban-area'];assert len(matches)==2,'Overlapping non-administrative memberships were flattened'
   broken=copy.deepcopy(graph);broken['relationships'][0]['to']=cid+':division:DOES-NOT-EXIST';assert any('Broken geographic relationship' in x for x in validate_graph(broken,cfg))
   bad=copy.deepcopy(graph);bad['entities'][1]['coordinates']={'lat':100,'lon':0,'definition':'Synthetic invalid coordinate'};assert any('Invalid coordinate' in x for x in validate_graph(bad,cfg))
 print('PASS: disabled country protection; French alphanumeric and Italian zero-padded identifiers; different source column mappings; overlapping FUA links; broken-parent and invalid-coordinate rejection.')
if __name__=='__main__':run()
