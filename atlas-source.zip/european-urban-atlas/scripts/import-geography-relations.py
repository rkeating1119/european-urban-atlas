#!/usr/bin/env python3
"""Add authoritative FUA geometries, explicitly computed memberships, and island government relations."""
import runpy,json,hashlib
from pathlib import Path
shared=runpy.run_path(str(Path(__file__).with_name('import-geography.py')))
fetch,save,fc,point_in_ring,representative,OUT,BASE=[shared[k] for k in ['fetch','save','fc','point_in_ring','representative','OUT','BASE']]

def polys(geom):return geom['coordinates'] if geom['type']=='MultiPolygon' else [geom['coordinates']]
def bounds(geom):
 points=[p for poly in polys(geom) for ring in poly for p in ring]
 return min(p[0] for p in points),min(p[1] for p in points),max(p[0] for p in points),max(p[1] for p in points)
def within(p,geom):return any(point_in_ring(p,poly[0]) and not any(point_in_ring(p,h) for h in poly[1:]) for poly in polys(geom))

def main():
 fua_path=fetch('URAU_RG_100K_2024_4326_FUA.geojson',BASE+'/urau/geojson/URAU_RG_100K_2024_4326_FUA.geojson')
 countries_path=fetch('CNTR_RG_20M_2024_4326.geojson',BASE+'/countries/geojson/CNTR_RG_20M_2024_4326.geojson')
 fuas=[f for f in json.loads(fua_path.read_text())['features'] if f['properties']['CNTR_CODE']=='ES']
 for f in fuas:f['properties']['id']=f['properties']['URAU_CODE'];f['properties']['name']=f['properties']['URAU_NAME']
 save('functional-urban-areas.geojson',fc(fuas));save('countries.geojson',json.loads(countries_path.read_text()))
 indexed=[(bounds(f['geometry']),f) for f in fuas]
 municipalities=json.loads((OUT/'municipalities.json').read_text());members={f['properties']['id']:[] for f in fuas}
 for m in municipalities:
  x,y=m['lon'],m['lat'];ids=[]
  for (x1,y1,x2,y2),f in indexed:
   if x1<=x<=x2 and y1<=y<=y2 and within((x,y),f['geometry']):ids.append(f['properties']['id']);members[f['properties']['id']].append(m['id'])
  m['functionalUrbanAreaIds']=ids
 # These membership links are computed, not a falsely claimed official correspondence table.
 save('functional-urban-areas.json',[dict(id=f['properties']['id'],countryId='ES',name=f['properties']['name'],type='functional-urban-area',referenceYear=2024,municipalityIds=members[f['properties']['id']],membershipMethod='Representative point in official FUA polygon; computed spatial relationship, not official LAU correspondence',sourceId='gisco-urau-2024') for f in fuas])
 nuts3=json.loads((OUT/'nuts3.geojson').read_text())['features']
 island_specs=[
 ('ES-island-mallorca','Mallorca','04','07','ES532','Consell de Mallorca','consell-insular'),('ES-island-menorca','Menorca','04','07','ES533','Consell Insular de Menorca','consell-insular'),('ES-island-eivissa','Eivissa','04','07','ES531','Consell Insular d’Eivissa','consell-insular'),('ES-island-formentera','Formentera','04','07','ES531','Consell Insular de Formentera','consell-insular'),
 ('ES-island-el-hierro','El Hierro','05','38','ES703','Cabildo Insular de El Hierro','cabildo-insular'),('ES-island-fuerteventura','Fuerteventura','05','35','ES704','Cabildo Insular de Fuerteventura','cabildo-insular'),('ES-island-gran-canaria','Gran Canaria','05','35','ES705','Cabildo Insular de Gran Canaria','cabildo-insular'),('ES-island-la-gomera','La Gomera','05','38','ES706','Cabildo Insular de La Gomera','cabildo-insular'),('ES-island-la-palma','La Palma','05','38','ES707','Cabildo Insular de La Palma','cabildo-insular'),('ES-island-lanzarote','Lanzarote and La Graciosa','05','35','ES708','Cabildo Insular de Lanzarote y La Graciosa','cabildo-insular'),('ES-island-tenerife','Tenerife','05','38','ES709','Cabildo Insular de Tenerife','cabildo-insular')]
 nm={f['properties']['NUTS_ID']:f for f in nuts3};im={s[4]:s[0] for s in island_specs}
 island_index=[(bounds(nm[nid]['geometry']),nid,nm[nid]['geometry']) for nid in im]
 unknown=[]
 for m in municipalities:
  if m['regionId'] not in ['04','05']:continue
  if m['id']=='07024':m['islandAdministrativeUnitId']='ES-island-formentera';continue
  found=[];x,y=m['lon'],m['lat']
  for (x1,y1,x2,y2),nid,g in island_index:
   if x1<=x<=x2 and y1<=y<=y2 and within((x,y),g):found.append(nid)
  if len(found)!=1:unknown.append(m['id']);continue
  nid=found[0];m['islandAdministrativeUnitId']='ES-island-eivissa' if nid=='ES531' else im[nid]
 if unknown:raise ValueError('Unresolved island spatial joins '+str(unknown))
 islands=[dict(id=i,name=n,countryId='ES',regionId=r,provinceId=p,nuts3Id=nut,type='island-administrative-unit',institution=inst,institutionType=t,municipalityIds=[m['id'] for m in municipalities if m.get('islandAdministrativeUnitId')==i],sourceIds=['balearic-councils' if r=='04' else 'canary-island-governments-2026']) for i,n,r,p,nut,inst,t in island_specs]
 expected={'ES-island-mallorca':53,'ES-island-menorca':8,'ES-island-eivissa':5,'ES-island-formentera':1,'ES-island-el-hierro':3,'ES-island-fuerteventura':6,'ES-island-gran-canaria':21,'ES-island-la-gomera':6,'ES-island-la-palma':14,'ES-island-lanzarote':7,'ES-island-tenerife':31}
 for i in islands:
  if len(i['municipalityIds'])!=expected[i['id']]:raise ValueError('Island municipal count mismatch '+str(i))
 islands.append(dict(id='ES-island-la-graciosa',name='La Graciosa',countryId='ES',regionId='05',provinceId='35',type='island',administeredById='ES-island-lanzarote',municipalityIds=['35024'],note='A separate inhabited island within Teguise municipality and the shared Lanzarote and La Graciosa cabildo; not a separate municipality or cabildo.',sourceIds=['canary-island-governments-2026']))
 save('islands.json',islands);save('municipalities.json',municipalities)
 # Geographic navigation labels use a stable representative point, never a claim about an urban centre.
 for name,key,gname in [('regions.json','regionId','regions.geojson'),('provinces.json','id','provinces.geojson')]:
  entries=json.loads((OUT/name).read_text());features=json.loads((OUT/gname).read_text())['features'];fm={f['properties'][key]:f for f in features}
  for e in entries:
   e['lon'],e['lat']=representative(fm[e['id']]['geometry'])
   municipal_children=[m for m in municipalities if m['regionId' if name=='regions.json' else 'provinceId']==e['id']]
   e['municipalityCount']=len(municipal_children);e['population']=sum(m['population'] for m in municipal_children);e['populationYear']=2025;e['populationDefinition']='Sum of official municipal Padrón populations at 2025-01-01, total sexes; arithmetic aggregation of INE table 29005'
   e['populationSourceId']='ine-population-29005'
  save(name,entries)
 provenance=json.loads((OUT/'provenance.json').read_text());provenance['additionalSources'].extend([
 {'id':'gisco-urau-2024','publisher':'Eurostat / GISCO','title':'Urban Audit 2024 functional urban areas, scale 1:100,000','url':BASE+'/urau/geojson/'+fua_path.name,'referencePeriod':'2024','sha256':hashlib.sha256(fua_path.read_bytes()).hexdigest()},
 {'id':'gisco-countries-2024','publisher':'Eurostat / GISCO','title':'Countries 2024, scale 1:20 million','url':BASE+'/countries/geojson/'+countries_path.name,'referencePeriod':'2024','sha256':hashlib.sha256(countries_path.read_bytes()).hexdigest()},
 {'id':'balearic-councils','publisher':'Govern de les Illes Balears','title':'Processos electorals: Institucions','url':'https://www.illesbalears.cat/sites/processoselectorals/ca/institucions-64178/'},
 {'id':'canary-island-governments-2026','publisher':'Gobierno de Canarias / Boletín Oficial de Canarias','title':'Ley 3/2026, de 16 de junio, de cabildos insulares','url':'https://www.gobiernodecanarias.org/boc/2026/129/2242.html','publicationDate':'2026-06-29'}])
 provenance['functionalUrbanAreaCount']=len(fuas);provenance['islandAdministrativeUnitCount']=11
 provenance['functionalUrbanAreaMembershipMethod']='Computed point-in-polygon join of municipal representative points to official GISCO FUA2024 polygons. Not an official LAU–FUA correspondence; boundary alignment and enclave cases require review before statistical aggregation.'
 provenance['limitations']=[s for s in provenance['limitations'] if 'Full named functional' not in s]
 provenance['limitations'].extend(['FUA is a commuting-based statistical concept, distinct from a municipal boundary, contiguous built-up area, or legal metropolitan authority.','Spatial FUA memberships are exploratory relationships, not a certified membership roster; do not use these computed links to sum metropolitan statistics without a direct official correspondence.','Island council and cabildo units are additional, overlapping administrative geography; La Graciosa is not modeled as a separate cabildo.'])
 provenance['additionalSources']=list({s['id']:s for s in provenance['additionalSources']}.values())
 provenance['limitations']=list(dict.fromkeys(provenance['limitations']))
 save('provenance.json',provenance)
 print(json.dumps({'fuaCount':len(fuas),'municipalitiesWithFuaLink':sum(bool(m['functionalUrbanAreaIds']) for m in municipalities),'islandUnits':len(islands),'islandMunicipalCounts':{i['name']:len(i['municipalityIds']) for i in islands}}))
if __name__=='__main__':main()
