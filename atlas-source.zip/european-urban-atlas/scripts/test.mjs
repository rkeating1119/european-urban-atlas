import assert from "node:assert/strict";
import worker from "../src/worker.js";
const html = "<h1>Atlas</h1>";
const env = {
  ASSETS: {
    async fetch(request) {
      const path = new URL(request.url).pathname;
      return [
        "/index.html",
        "/spain/places/28079/index.html",
        "/404.html",
      ].includes(path)
        ? new Response(path === "/404.html" ? "Not found" : html, {
            status: 200,
            headers: { "Content-Type": "text/html" },
          })
        : new Response("Missing", { status: 404 });
    },
  },
};
let r = await worker.fetch(
  new Request("https://atlas.test/spain/places/28079/", {
    headers: { Accept: "text/html" },
  }),
  env,
);
assert.equal(r.status, 200);
assert.equal(await r.text(), html);
assert.equal(r.headers.get("X-Content-Type-Options"), "nosniff");
r = await worker.fetch(
  new Request("https://atlas.test/nonexistent/", {
    headers: { Accept: "text/html" },
  }),
  env,
);
assert.equal(r.status, 404);
assert.equal(await r.text(), "Not found");
r = await worker.fetch(
  new Request("https://atlas.test/assets/missing.js"),
  env,
);
assert.equal(r.status, 404);
r = await worker.fetch(
  new Request("https://atlas.test/", { method: "POST" }),
  env,
);
assert.equal(r.status, 405);
console.log(
  "PASS: worker route resolution, real 404, missing assets, method handling and security headers",
);
