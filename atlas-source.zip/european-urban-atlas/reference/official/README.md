# Official reference snapshots

These INE source extractions and the original municipality-code workbook are preserved with the source repository so inventory/population validation does not depend on an untracked cache. The manifest records origin, reference definitions, byte counts and hashes. Public-facing geographic records remain under public/data/geography; these independent reference snapshots are not served as website assets.

The full EU raw geometry and population API downloads can be reacquired by scripts/import-geography.py. Large transient inputs are cached under work/data-downloads and are not part of the source repository. The importer refreshes the preserved extractions only when explicitly run; it does not silently change dates during ordinary builds.
