# European Urban Atlas · geography and architecture update

Public site: https://rkeating1119.github.io/european-urban-atlas/

The same permanent address serves all 161 cities across Spain, France and Italy. GitHub Pages runs independently of this chat, the local preview and open browser tabs.

## Reading changes

Every city now has its concise opening summary without a repeated heading, followed by a two-paragraph general overview before the labelled sections. The overview explains location and urban structure: rivers, hills, old centers, later expansion districts and where the modern city continues. Ten sections now include a dedicated architecture and streets section alongside character, history, work, housing, neighborhoods, culture, food, transport and weather.

The expanded text describes materials, building forms, street widths, views and atmosphere, with specific comparisons to other cities. Local names and terms are explained where introduced. Sample review corrected Madrid's comparison with Barcelona's Eixample, clarified Monte Berico in Vicenza and removed an editorial-instruction echo from Jaén.

The reading sections and overviews contain 135,102 words, an increase of 55,291 over the previous edition. Opening summaries, ratings and useful compromises remain concise. Architecture descriptions also appear in comparisons.

## Map and menu changes

The scattered labels came from overriding MapLibre's absolute marker positioning with relative positioning. City labels also carried a second dot in addition to the map's circles. The revised map uses one circle per city, with radius and stroke interpolated by zoom. Text labels preserve the map's positioning and transform. The ten largest featured municipalities in each country are labelled; other cities open hover and tap cards. Spain's display points now identify central civic locations, with former administrative centroids preserved separately.

The map is larger: 800 pixels high at the tested 1440×1000 desktop viewport, 670 at the tablet breakpoint and 590 on phones. A fullscreen control offers additional room. All country, city, map, browse and compare dropdowns now open in-page. Long lists are searchable; arrow keys, Enter and Escape work. Menus fit the viewport and map menus open upward. Hidden native controls retain form values, including direct country/region filter links and dynamically populated options. Map reset clears both visible menu selections.

A content release key versions the CSS, JavaScript and browser data request so new controls and old cached data do not mix.

## Verification

The build, TypeScript check, worker routing tests and current reader audit passed. The audit checks all 161 overviews, ten sections per city, ratings, bibliography references, top-ten labels and direct routes. It found no exact or near-duplicate reading paragraphs. Mean sentence lengths remain about 17 words. It checked 291 HTML pages, 8,205 internal targets and 2,498 section links.

Local browser checks covered all three country maps, label anchoring and zoom, searchable menus, keyboard country switching, accent-free city search, dependent and direct-link filters, tablet reading and phone comparisons. The zoom check approximately doubled Madrid–Barcelona label separation from 328×69 to 655×139 pixels for a one-level increase, matching geographic scaling within rounded pixels. A hover card was observed on Madrid and Salamanca opened from its unlabelled dot. No horizontal overflow appeared in the tested samples; no console errors were captured in the final country-map checks.

All 538 current source URLs were requested: 443 accessible, 73 inconclusive network errors, 17 blocked, four transient/server errors and one DNS failure. Stale Brest and Girona links were replaced; the final report contains no confirmed 404/410. Availability does not certify every source's substantive content. The reader audit retains five notes: four accurate coastal city centers fall outside simplified regional shorelines, and Mamoudzou omits an unknown current population. Spanish display points were independently checked against the more detailed preserved municipal boundaries.

Responsive viewports were tested, not physical iPad hardware. Safari, physical pinch gestures and a full screen-reader conformance audit were not performed. The browser audit records actual samples and public verification separately.

## Publication

Release key: 9d006fb6e621. Static archive: 5,436,658 bytes; SHA-256 827ae67901e4f6b05b808789a8a588de53741270de5c026f0c8f9a892f9610ff. Publication commit: 67acb64847d52960c08df3d80613a37118b8765e. GitHub Pages run: 42439979170, completed successfully. Public HTML release keys and the complete client data match the validated local build. Live country/city menus, France map, Bergamo reading page and phone comparisons were checked after deployment.

The saved deployment workflow publishes atlas-site.zip on the existing repository. Current source and audit records are exported locally and preserved in atlas-source.zip online; local Git history is also exported for recovery. No paid service, new hosting identity or domain purchase is involved.
