# European Urban Atlas · published reader edition

Live site: https://rkeating1119.github.io/european-urban-atlas/

The revised atlas is complete and publicly available: 60 Spanish cities, 51 French cities and 50 Italian cities. It runs on GitHub Pages independently of this chat, the local browser and the preview server. The public repository is https://github.com/rkeating1119/european-urban-atlas.

## What changed

Every city opens with a short, direct summary. Nine sections cover character, history, work, housing, neighborhoods, culture, food, transport and weather. Named neighborhoods, local dishes, employers and practical compromises replace the old abstract descriptions. The selection covers major cities, regional centers and selected substantial suburbs; the earlier exhaustive municipality directory is preserved in source history rather than presented as the reader's catalog.

France and Italy use the same templates and editorial standards as Spain. All 57 regional jurisdictions have featured cities. Country maps label principal regional cities before a region is selected, with island and overseas views where needed. The Europe overview starts with country labels; city labels appear as the reader zooms in. Country and city dropdowns, search and curated filters provide direct navigation.

Comparisons show city summaries, good points, compromises, food, neighborhoods and seven explained ratings: affordability, careers, transport, culture, social life, outdoors and climate. The 1–5 ratings are editorial judgments, with short reasons and no overall ranking. Sources and rating notes remain available through compact disclosures. Research-coverage badges and further-reading clutter have been removed from the main reading flow.

## Editorial and technical audit

The reader audit passed with zero material errors. It checked all 161 profiles, their nine sections and seven ratings, all regional representation, source references, coordinates and map priorities. No exact or near-duplicate reading paragraphs were found. Mean sentence lengths are 15.1 words in Spain, 16.0 in France and 16.2 in Italy. These measurements support, rather than replace, editorial review.

The reader-interest checklist covers quick impressions, neighborhoods, housing, work, culture, food, history, transport, weather, nature, student life, families, nightlife, language, suburbs and compromises. The matrix in docs/READER-AUDIT.md reports where each topic appears; it does not imply that every city contains a school guide or relocation dossier.

The built-site audit checked 291 HTML pages, 7,984 internal targets and 2,277 fragment links, including the GitHub Pages project path and split JavaScript assets. TypeScript and the asset-worker routing tests passed. The public check fetched 11 representative pages and assets without authentication, all returning HTTP 200. The main city text is pre-rendered and essential map boundaries are packaged locally.

The bibliography check requested 414 unique source URLs: 349 accessible, 46 inconclusive network errors, 15 access-blocked and four transient/server errors. None returned a confirmed 404 or 410. HTTP availability is not certification that every page was substantively reviewed. Results are retained in docs/READER-SOURCE-LINKS.json.

Two disclosed data notes remain: Mamoudzou omits a population rather than presenting an older census as current; Ajaccio's real coastal center falls slightly outside the simplified regional shoreline. Neither prevents navigation or reading. Current rents and wages have not been fabricated to fill data gaps.

## Browser verification

Local and public checks used the in-app Chromium browser. Desktop (1440×1000), tablet portrait (768×1024), tablet landscape (1024×768) and phone (390×844) samples had no horizontal overflow. The public Rome article showed all nine sections, a roughly 707-pixel prose column at tablet portrait and initially closed sources. Public three-city comparisons showed 21 explained ratings; the phone layout stacked the cities cleanly. The public Italy map rendered principal labels across all 20 regions, with no captured console errors in that check.

Country switching, city menus, searches, maps, reading sections and cross-country comparisons were exercised. Actual iPad hardware, Safari, physical pinch gestures and a full screen-reader conformance audit were not performed. docs/BROWSER-QA-READER.json records the sample checks. Saved screenshots show the actual public site.

## Publication and preservation

GitHub Pages deployment run 42436817375 succeeded for commit 92c3a0f1dc762e8ca41c6f03f67525eee83f7dc8. The uploaded static archive is 5,182,339 bytes, SHA-256 3289f5b708f61e208409eaddcf1dad3cfd124a4b704e5ddfd787c6d5919503a9. The workflow is saved in .github/workflows/pages.yml; a push updating atlas-site.zip publishes the next validated static release. No domain purchase, subscription, tunnel or locally running process is required for the public site.

The maintained source, editorial files, geography, build scripts, audit evidence and deployment instructions are saved in this workspace and exported with the release. A source archive accompanies the static archive in the public repository. Local Git history is also exported separately for recovery. Historical foundation reports are retained under docs/archive/ and describe an earlier scope, not the current public edition.

Future work is ordinary maintenance: update dated facts, replace inaccessible sources, improve individual descriptions from reader feedback and add places when useful. The current site needs no further user action to stay online.
