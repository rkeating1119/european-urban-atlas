# Third-party software notices

Geographic datasets and photographs retain their separate source-specific terms; see `/credits/` and the provenance manifests. Original atlas content is not automatically licensed under a dependency’s licence.

- @esbuild/darwin-arm64 0.25.12: MIT
- @mapbox/jsonlint-lines-primitives 2.0.3: MIT
- @mapbox/point-geometry 1.1.0: ISC
- @mapbox/tiny-sdf 2.3.0: BSD-2-Clause
- @mapbox/unitbezier 0.0.1: BSD-2-Clause
- @mapbox/unitbezier 1.0.0: BSD-2-Clause
- @mapbox/vector-tile 2.0.5: BSD-3-Clause
- @mapbox/whoots-js 3.1.0: ISC
- @maplibre/geojson-vt 6.3.0: ISC
- @maplibre/maplibre-gl-style-spec 24.10.0: ISC
- @maplibre/mlt 1.3.0: (MIT OR Apache-2.0)
- @maplibre/vt-pbf 4.3.3: MIT
- @types/geojson 7946.0.16: MIT
- earcut 3.2.4: ISC
- esbuild 0.25.12: MIT
- gl-matrix 3.4.4: MIT
- json-stringify-pretty-compact 4.0.0: MIT
- kdbush 4.1.0: ISC
- maplibre-gl 5.24.0: BSD-3-Clause
- minimist 1.2.8: MIT
- murmurhash-js 1.0.0: MIT
- pbf 4.0.2: BSD-3-Clause
- pbf 5.1.2: BSD-3-Clause
- potpack 2.1.0: ISC
- prettier 3.6.2: MIT
- protocol-buffers-schema 3.6.1: MIT
- quickselect 3.0.0: ISC
- resolve-protobuf-schema 2.1.0: MIT
- tinyqueue 3.0.0: ISC
- typescript 5.9.3: Apache-2.0

Available full package licences are preserved in `docs/licenses/`. Dependency package notices remain in the locked installed packages. MapLibre is distributed under BSD 3-Clause.
