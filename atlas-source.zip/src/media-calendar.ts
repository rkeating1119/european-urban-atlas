import {tr} from "./feature-core";
export function mountMediaCalendar() {
  const audios=[...document.querySelectorAll<HTMLAudioElement>("audio[data-recording-src]")];
  for(const audio of audios) {
    const card=audio.closest<HTMLElement>(".recording-card")!,button=card.querySelector<HTMLButtonElement>(".recording-play")!,status=card.querySelector<HTMLElement>(".recording-status")!;
    function chooseSource() {return audio.canPlayType('audio/ogg; codecs="opus"') ? audio.dataset.recordingSrc! : audio.dataset.fallbackSrc || audio.dataset.recordingSrc!;}
    button.addEventListener("click",()=>{
      for(const other of audios)if(other!==audio)other.pause();
      if(!audio.getAttribute("src")){audio.src=chooseSource();audio.hidden=false;audio.volume=.65;}
      status.textContent="";
      void audio.play().then(()=>button.hidden=true).catch(()=>{status.textContent=tr("Press play on the player to listen. If it cannot load, the original is linked below.","Pulsa reproducir en el reproductor. Si no carga, puedes abrir el original enlazado abajo.");});
    });
    audio.addEventListener("play",()=>{for(const other of audios)if(other!==audio)other.pause();});
    audio.addEventListener("error",()=>{const fallback=audio.dataset.fallbackSrc;if(fallback && !audio.src.endsWith(fallback)){audio.src=fallback;audio.load();}else status.textContent=tr("This browser could not play the file. Open the original recording below.","Este navegador no pudo reproducir el archivo. Abre la grabación original enlazada abajo.");});
  }
  const form=document.querySelector<HTMLFormElement>("#calendar-filter");
  if(form) {
    const country=form.elements.namedItem("country")as HTMLSelectElement,month=form.elements.namedItem("month")as HTMLSelectElement,cards=[...document.querySelectorAll<HTMLElement>(".calendar-grid .calendar-card")],status=document.querySelector<HTMLElement>("#calendar-status")!;
    const params=new URLSearchParams(location.search);country.value=params.get("country")||"";month.value=params.get("month")||"";
    for(const s of[country,month])s.dispatchEvent(new Event("atlas-select-refresh"));
    function filter(){let count=0;for(const card of cards){const show=(!country.value||card.dataset.countries?.split(" ").includes(country.value))&&(!month.value||card.dataset.month===month.value);card.hidden=!show;if(show)count++;}status.textContent=`${count} ${tr("calendar entries","fechas y celebraciones")}`;const u=new URL(location.href);for(const[k,v]of Object.entries({country:country.value,month:month.value})){if(v)u.searchParams.set(k,v);else u.searchParams.delete(k);}history.replaceState(null,"",u);}
    form.addEventListener("change",filter);form.addEventListener("submit",e=>e.preventDefault());filter();
  }
}
