import type {
  Map as LibreMap,
  LayerSpecification,
  SourceSpecification,
  StyleSpecification,
  MapMouseEvent,
  GeoJSONSourceSpecification,
} from "maplibre-gl";
import { asset, base, loadJSON, local, tr, escapeHTML as esc } from "./feature-core";

type Context = { countryId?: string; countrySlug?: string; countrySelection: boolean };
type Layer = {
  id: string;
  label: { en: string; es: string };
  type: "fill" | "line" | "circle";
  color: string;
  countries: Record<string, number>;
  source: string;
  date: string;
  url: string;
  rights: string;
  legend: { en: string; es: string };
};
type NightImage = {
  url: string;
  coordinates: [[number, number], [number, number], [number, number], [number, number]];
};
type Manifest = {
  layers: Layer[];
  nightlights: Record<string, Record<string, NightImage[]>>;
  limitations: { en: string; es: string };
};
type Basemap = "atlas" | "topographic" | "satellite" | "dark";
type Settings = {
  basemap?: Basemap;
  layers?: Record<string, { checked?: boolean; opacity?: number }>;
  night?: { enabled?: boolean; year?: string; opacity?: number };
};
const namespace = "atlas-tools-";
const css = `
.atlas-map-tools{position:absolute;z-index:4;top:10px;left:10px;max-width:calc(100% - 70px);font:13px/1.4 system-ui,sans-serif;color:#263d35;}
.atlas-map-tools>summary{list-style:none;cursor:pointer;border:1px solid #b8c9bd;border-radius:8px;padding:8px 12px;background:#fffdf7;box-shadow:0 2px 8px #162b2820;font-weight:700;width:max-content;}
.atlas-map-tools>summary::-webkit-details-marker{display:none}
.atlas-map-tools[open]{width:320px;max-height:calc(100% - 55px);overflow:auto;background:#fffdf7;border:1px solid #b8c9bd;border-radius:8px;box-shadow:0 4px 20px #162b2830;}
.atlas-map-tools[open]>summary{position:sticky;top:0;width:auto;border:0;border-bottom:1px solid #d8e0d5;border-radius:0;z-index:1}
.atlas-map-tools .map-tools-content{padding:12px}.atlas-map-tools label{display:block;margin:0 0 8px}.atlas-map-tools select{width:100%;min-height:36px;background:#fff;color:#263d35;border:1px solid #a6baad;border-radius:5px;padding:5px;font:inherit}
.atlas-map-tools p{margin:8px 0;font-size:12px;line-height:1.45}.atlas-map-tools a{color:#1b6555;text-decoration:underline}.atlas-map-tools button{font:inherit;min-height:34px;padding:5px 9px;border:1px solid #a6baad;background:white;color:#263d35;border-radius:5px;cursor:pointer}.atlas-map-tools button[aria-pressed=true]{background:#dce9e0}
.atlas-map-tools fieldset{border:0;border-top:1px solid #d4ded5;padding:10px 0 0;margin:10px 0}.atlas-map-tools legend{padding:0 4px 0 0;font-weight:700}.atlas-map-tools .map-layer-row{border-bottom:1px solid #dce3da;padding:8px 0}.atlas-map-tools .map-layer-row>label{display:flex;align-items:center;gap:7px;margin:0}.atlas-map-tools input[type=checkbox]{width:17px;height:17px;accent-color:#2d6b55;flex-shrink:0}.atlas-map-tools input[type=range]{width:100%;accent-color:#2d6b55;min-height:26px}.atlas-map-tools .map-layer-meta{padding-left:24px}.atlas-map-tools .map-layer-meta summary{cursor:pointer;font-size:12px}.atlas-map-tools .map-swatch{display:inline-block;width:10px;height:10px;flex-shrink:0;border:1px solid #566b5e}.atlas-map-tools .map-inspection{padding:8px;border:1px solid #bdcbbb;border-radius:5px;margin-top:8px;background:#eef3e9;overflow-wrap:anywhere}.atlas-map-tools .map-tools-status{font-weight:600}.atlas-map-tools .map-night-buttons{display:flex;align-items:center;gap:8px}.atlas-map-tools .map-night-buttons output{font-weight:700}.atlas-map-tools [hidden]{display:none!important}
@media(max-width:600px){.atlas-map-tools{font-size:12px;left:7px;top:7px}.atlas-map-tools[open]{width:280px;max-height:calc(100% - 55px)}.atlas-map-tools .map-tools-content{padding:9px}}
`;

/** Add sources and basemap groups without resetting the map, camera or handlers. */
export async function mountMapTools(m: LibreMap, node: HTMLElement, context: Context) {
  if (node.querySelector(".atlas-map-tools")) return;
  const root = document.createElement("details");
  root.className = "atlas-map-tools";
  root.innerHTML = `<summary>${tr("Map layers", "Capas del mapa")}</summary><div class="map-tools-content"><label>${tr("Basemap", "Mapa base")}<select id="map-basemap" aria-label="${tr("Basemap", "Mapa base")}"><option value="atlas">Atlas</option><option value="topographic">${tr("Topographic · shaded relief", "Topográfico · relieve sombreado")}</option><option value="satellite">${tr("Satellite · coarse Blue Marble", "Satélite · Blue Marble generalizado")}</option><option value="dark">${tr("Dark · streets", "Oscuro · calles")}</option></select></label><p class="map-basemap-note" aria-live="polite"></p><p class="map-tools-status" role="status"></p><div class="map-thematic-tools"></div></div>`;
  const style = document.createElement("style");
  style.textContent = css;
  root.prepend(style);
  node.append(root);
  // Controls must not start a map pan, zoom or geography click.
  for (const event of ["pointerdown", "mousedown", "dblclick", "click", "wheel", "touchstart"])
    root.addEventListener(event, (e) => e.stopPropagation());
  const status = root.querySelector<HTMLElement>(".map-tools-status")!;
  const note = root.querySelector<HTMLElement>(".map-basemap-note")!;
  const select = root.querySelector<HTMLSelectElement>("#map-basemap")!;
  const thematic = root.querySelector<HTMLElement>(".map-thematic-tools")!;
  const canonicalPath = location.pathname.startsWith(base + "/es/")
    ? base + location.pathname.slice(base.length + 3)
    : location.pathname;
  const settingsKey = "atlas-map-tools:" + canonicalPath;
  let restored: Settings = {};
  try {
    if (new URLSearchParams(location.search).get("map") === "restore")
      restored = JSON.parse(sessionStorage.getItem(settingsKey) || "{}") || {};
  } catch { /* Map controls remain available when session storage is blocked. */ }
  const validOpacity = (value: unknown, fallback: number) =>
    typeof value === "number" && Number.isFinite(value) ? Math.min(100, Math.max(10, value)) : fallback;
  function saveSettings() {
    const layers: NonNullable<Settings["layers"]> = {};
    for (const checkbox of root.querySelectorAll<HTMLInputElement>("[data-map-layer]")) {
      const slider = checkbox.closest(".map-layer-row")?.querySelector<HTMLInputElement>("input[type=range]");
      layers[checkbox.dataset.mapLayer!] = { checked: checkbox.checked, opacity: Number(slider?.value || 75) };
    }
    const enabled = root.querySelector<HTMLInputElement>(".map-night-enabled");
    try {
      sessionStorage.setItem(settingsKey, JSON.stringify({
        basemap: select.value as Basemap,
        layers,
        ...(enabled ? { night: {
          enabled: enabled.checked,
          year: root.querySelector<HTMLInputElement>(".map-night-scrub")?.value === "1" ? "2016" : "2012",
          opacity: Number(root.querySelector<HTMLInputElement>(".map-night-opacity")?.value || 85),
        } } : {}),
      } satisfies Settings));
    } catch { /* Saved state is optional; geographic exploration still works. */ }
  }
  let removed = false;
  let mode: Basemap = ["atlas", "topographic", "satellite", "dark"].includes(restored.basemap || "")
    ? restored.basemap! : "atlas";
  select.value = mode;
  node.dataset.mapInspect = "false";
  let interval: ReturnType<typeof setInterval> | undefined;
  const lifecycle = new AbortController();
  m.once("remove", () => {
    removed = true;
    if (interval) clearInterval(interval);
    lifecycle.abort();
    delete node.dataset.mapInspect;
    root.remove();
  });
  let inspect = false;
  let inspectOutput: HTMLElement | undefined;
  const active = new Map<string, { layer: Layer; opacity: number }>();
  const libLayers: { id: string; min: number; max: number; type: string }[] = [];
  const darkLayers: string[] = [];
  const terrainId = namespace + "terrain";
  const satelliteId = namespace + "satellite";
  const layerIds = (id: string) => namespace + "overlay-" + id;
  const savedFill = new Map<string, unknown>();
  for (const layer of m.getStyle().layers || []) {
    if (layer.id.startsWith("region-fill-")) savedFill.set(layer.id, m.getPaintProperty(layer.id, "fill-opacity") ?? 0);
  }
  const visible = (id: string, show: boolean) => {
    if (m.getLayer(id)) m.setLayoutProperty(id, "visibility", show ? "visible" : "none");
  };
  function updateBasemap() {
    if (removed) return;
    for (const layer of libLayers) {
      const detail = mode === "topographic"
        ? layer.type === "line" || layer.type === "symbol" || layer.id.includes("building")
        : mode === "satellite" ? layer.type === "line" || layer.type === "symbol" : mode === "atlas";
      // Atlas preserves its national palette, then reveals real streets as it zooms.
      const min = Math.max(layer.min, mode === "atlas" ? 6 : mode === "satellite" ? 9 : 0);
      visible(layer.id, detail && min < layer.max);
      if (min < layer.max) m.setLayerZoomRange(layer.id, min, layer.max);
    }
    for (const id of darkLayers) visible(id, mode === "dark");
    visible(terrainId, mode === "topographic");
    visible(satelliteId, mode === "satellite");
    if (m.getLayer("land")) m.setPaintProperty("land", "fill-opacity", mode === "atlas" ? ["interpolate", ["linear"], ["zoom"], 6, 1, 9, 0] : 0);
    for (const [id, opacity] of savedFill) if (m.getLayer(id)) m.setPaintProperty(id, "fill-opacity", mode === "atlas" ? opacity : 0);
    note.innerHTML = mode === "atlas"
      ? tr("Country colours at overview scale; real OpenStreetMap streets and buildings appear as you zoom in. Detail is live and varies by location.", "Colores nacionales a escala general; al acercar aparecen calles y edificios reales de OpenStreetMap. El detalle es en línea y varía según el lugar.")
      : mode === "dark"
        ? tr("Live OpenFreeMap / OpenStreetMap detail. Street and building coverage varies; this is not a dated historical map.", "Detalle en línea de OpenFreeMap / OpenStreetMap. La cobertura de calles y edificios varía; no es un mapa histórico fechado.")
        : mode === "topographic"
          ? tr("NASA Blue Marble shaded relief with live OpenStreetMap streets. Coarse relief (maximum native zoom 8), not surveyed contours or a 3D terrain model.", "Relieve sombreado NASA Blue Marble con calles de OpenStreetMap. Relieve generalizado (zoom nativo máximo 8), sin curvas de nivel topográficas ni modelo 3D.")
          : tr("NASA MODIS Blue Marble Next Generation (2004 composite). Coarse imagery, maximum native zoom 8; enlarging does not add aerial detail. Streets appear at close zoom.", "NASA MODIS Blue Marble Next Generation (compuesto de 2004). Imagen generalizada, zoom nativo máximo 8; ampliarla no añade detalle aéreo. Las calles aparecen al acercar.");
    note.innerHTML += ` <a href="${mode === "atlas" || mode === "dark" ? "https://openfreemap.org/quick_start/" : "https://www.earthdata.nasa.gov/data/imagery/gibs"}" target="_blank" rel="noopener">${tr("Source", "Fuente")}</a>`;
  }
  select.addEventListener("change", () => {
    mode = select.value as Basemap;
    updateBasemap();
  });
  updateBasemap();
  status.textContent = tr("Loading map sources…", "Cargando fuentes del mapa…");
  let manifest: Manifest;
  try {
    const [liberty, dark, registry] = await Promise.all([
      loadJSON<StyleSpecification>("/data/features/maps/liberty.json"),
      loadJSON<StyleSpecification>("/data/features/maps/dark.json"),
      loadJSON<Manifest>("/data/features/maps/manifest.json"),
    ]);
    if (removed) return;
    manifest = registry;
    // Both saved styles use the same OpenFreeMap sources, glyphs and sprite.
    for (const [id, source] of Object.entries(liberty.sources)) {
      if (!m.getSource(namespace + id)) {
        const spec = structuredClone(source) as SourceSpecification;
        if ("attribution" in spec || spec.type === "vector" || spec.type === "raster")
          (spec as any).attribution = '<a href="https://openfreemap.org/">OpenFreeMap</a> © <a href="https://www.openmaptiles.org/">OpenMapTiles</a> © <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>';
        m.addSource(namespace + id, spec);
      }
    }
    for (const [kind, sourceLayer] of [["terrain", "BlueMarble_ShadedRelief"], ["satellite", "BlueMarble_NextGeneration"]]) {
      m.addSource(namespace + kind, { type: "raster", tiles: [`https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/${sourceLayer}/default/GoogleMapsCompatible_Level8/{z}/{y}/{x}.jpeg`], tileSize: 256, maxzoom: 8, attribution: '<a href="https://www.earthdata.nasa.gov/data/imagery/gibs">NASA Earth Observatory / MODIS Blue Marble</a>' });
      m.addLayer({ id: namespace + kind, type: "raster", source: namespace + kind, layout: { visibility: "none" }, paint: { "raster-opacity": 1 } }, "land");
    }
    for (const [kind, sourceStyle] of [["liberty", liberty], ["dark", dark]] as const) {
      for (const sourceLayer of sourceStyle.layers) {
        // The atlas keeps its country/region labels and all city hit targets.
        // Avoid repeating coarse city/country names from the basemap.
        if ("source-layer" in sourceLayer && sourceLayer["source-layer"] === "place") continue;
        const layer = structuredClone(sourceLayer) as LayerSpecification;
        layer.id = namespace + kind + "-" + layer.id;
        if ("source" in layer && typeof layer.source === "string") layer.source = namespace + layer.source;
        layer.layout = { ...layer.layout, visibility: "none" };
        m.addLayer(layer, "land");
        if (kind === "liberty") libLayers.push({ id: layer.id, min: layer.minzoom || 0, max: layer.maxzoom || 24, type: layer.type });
        else darkLayers.push(layer.id);
      }
    }
    updateBasemap();
    status.textContent = "";
  } catch {
    status.textContent = tr("Detailed map sources could not load. The atlas map remains available; reload to retry.", "No se pudieron cargar las fuentes detalladas. El atlas sigue disponible; recarga para reintentar.");
    select.disabled = true;
    return;
  }
  if (context.countrySelection) {
    thematic.innerHTML = `<p>${tr("Select a country to explore sourced geographic layers. This overview selects countries only.", "Selecciona un país para explorar sus capas geográficas. Este mapa general solo selecciona países.")}</p>`;
  } else if (!context.countryId) {
    thematic.innerHTML = `<p>${tr("Open a country map to explore layers with explicit national coverage.", "Abre el mapa de un país para explorar capas con cobertura nacional explícita.")}</p>`;
  } else {
    const cc = context.countryId;
    thematic.innerHTML = `<fieldset><legend>${tr("Independent layers", "Capas independientes")}</legend><div class="map-layer-list"></div></fieldset><p>${esc(local(manifest.limitations))}</p><button type="button" class="map-inspect-toggle" aria-pressed="false">${tr("Inspect layers", "Consultar capas")}</button><div class="map-inspection" aria-live="polite" hidden></div>`;
    inspectOutput = thematic.querySelector<HTMLElement>(".map-inspection")!;
    const button = thematic.querySelector<HTMLButtonElement>(".map-inspect-toggle")!;
    button.addEventListener("click", () => {
      inspect = !inspect;
      node.dataset.mapInspect = String(inspect);
      button.setAttribute("aria-pressed", String(inspect));
      inspectOutput!.hidden = !inspect;
      inspectOutput!.textContent = tr("Enable a layer, then click its geography to inspect its saved attributes.", "Activa una capa y pulsa sobre su geografía para consultar sus atributos guardados.");
    });
    const list = thematic.querySelector<HTMLElement>(".map-layer-list")!;
    for (const layer of manifest.layers) {
      const count = layer.countries[cc] || 0;
      const row = document.createElement("div");
      row.className = "map-layer-row";
      row.innerHTML = `<label><input type="checkbox" ${count ? "" : "disabled"} data-map-layer="${esc(layer.id)}"><span class="map-swatch" style="background:${layer.color}"></span>${esc(local(layer.label))}</label><div class="map-layer-meta"><details><summary>${count ? tr("Legend, source & opacity", "Leyenda, fuente y opacidad") : tr("Unavailable for this country", "Sin datos para este país")}</summary><p>${esc(local(layer.legend))}</p><p><a href="${esc(layer.url)}" target="_blank" rel="noopener">${esc(layer.source)}</a> · ${esc(layer.date)}<br>${esc(layer.rights)} · ${count} ${tr("clipped features", "elementos recortados")}</p><label>${tr("Opacity", "Opacidad")} <output>75%</output><input type="range" min="10" max="100" value="75" aria-label="${tr("Opacity", "Opacidad")} ${esc(local(layer.label))}" ${count ? "" : "disabled"}></label></details></div>`;
      list.append(row);
      const checkbox = row.querySelector<HTMLInputElement>("input[type=checkbox]")!;
      const slider = row.querySelector<HTMLInputElement>("input[type=range]")!;
      const opacityName = layer.type + "-opacity";
      const setOpacity = () => {
        const value = Number(slider.value) / 100;
        row.querySelector("output")!.textContent = slider.value + "%";
        if (m.getLayer(layerIds(layer.id))) m.setPaintProperty(layerIds(layer.id), opacityName, value);
        const state = active.get(layer.id);
        if (state) state.opacity = value;
      };
      slider.addEventListener("input", setOpacity);
      checkbox.addEventListener("change", async () => {
        const id = layerIds(layer.id);
        if (!checkbox.checked) {
          visible(id, false);
          active.delete(layer.id);
          return;
        }
        checkbox.disabled = true;
        status.textContent = tr("Loading selected layer…", "Cargando la capa seleccionada…");
        try {
          if (!m.getSource(id)) {
            const geo = await loadJSON<Exclude<GeoJSONSourceSpecification["data"], string>>(`/data/features/maps/${cc}/${layer.id}.geojson`);
            if (removed) return;
            m.addSource(id, { type: "geojson", data: geo, attribution: esc(layer.source) });
            const paint = layer.type === "fill"
              ? { "fill-color": layer.id === "density" ? ["step", ["get", "density"], "#f1eafa", 25, "#dfc6ea", 75, "#c99bd5", 150, "#aa71bb", 300, "#85529b", 750, "#552d70"] : layer.color, "fill-opacity": .75, "fill-outline-color": layer.color }
              : layer.type === "circle" ? { "circle-color": layer.color, "circle-radius": 4.5, "circle-stroke-color": "#fff", "circle-stroke-width": 1, "circle-opacity": .75 }
                : { "line-color": layer.color, "line-width": ["interpolate", ["linear"], ["zoom"], 3, 1.2, 9, 2.5], "line-opacity": .75, ...(layer.id === "rail" ? { "line-dasharray": [3, 1.5] } : {}) };
            const before = m.getStyle().layers?.find(l => l.id.startsWith("region-lines-") || l.id === "city-points")?.id;
            m.addLayer({ id, type: layer.type, source: id, paint } as LayerSpecification, before);
          }
          visible(id, checkbox.checked);
          if (checkbox.checked) active.set(layer.id, { layer, opacity: Number(slider.value) / 100 });
          setOpacity();
          status.textContent = "";
        } catch {
          checkbox.checked = false;
          status.textContent = tr("The layer could not load. Try selecting it again.", "No se pudo cargar la capa. Vuelve a seleccionarla.");
        } finally { checkbox.disabled = false; }
      });
      const prior = restored.layers?.[layer.id];
      slider.value = String(validOpacity(prior?.opacity, 75));
      setOpacity();
      if (prior?.checked && count) {
        checkbox.checked = true;
        checkbox.dispatchEvent(new Event("change"));
      }
    }
    const images = manifest.nightlights[cc];
    if (images?.["2012"]?.length && images?.["2016"]?.length) {
      const night = document.createElement("fieldset");
      night.innerHTML = `<legend>${tr("Night illumination · NASA", "Iluminación nocturna · NASA")}</legend><label><input type="checkbox" class="map-night-enabled"> ${tr("Show historical night lights", "Mostrar iluminación histórica")}</label><p>${tr("VIIRS Black Marble composites: 2012 and 2016 only. Coarse saved imagery (~4.9 km/pixel at equator), clipped to this country. Brightness is not a population measurement. No intermediate years are implied.", "Compuestos VIIRS Black Marble: solo 2012 y 2016. Imagen guardada generalizada (~4,9 km/píxel en el ecuador), recortada al país. El brillo no mide población. No se presentan años intermedios.")}</p><div class="map-night-buttons"><button type="button" class="map-night-play" aria-pressed="false">${tr("Play", "Reproducir")}</button><output class="map-night-year">2012</output></div><input type="range" class="map-night-scrub" min="0" max="1" step="1" value="0" aria-label="${tr("Night illumination year: 2012 or 2016", "Año de iluminación nocturna: 2012 o 2016")}"><label>${tr("Opacity", "Opacidad")} <input type="range" class="map-night-opacity" min="10" max="100" value="85"></label><p><a href="https://svs.gsfc.nasa.gov/30886/" target="_blank" rel="noopener">NASA GIBS · VIIRS Black Marble</a></p>`;
      thematic.insertBefore(night, button);
      const enabled = night.querySelector<HTMLInputElement>(".map-night-enabled")!;
      const scrub = night.querySelector<HTMLInputElement>(".map-night-scrub")!;
      const opacity = night.querySelector<HTMLInputElement>(".map-night-opacity")!;
      const play = night.querySelector<HTMLButtonElement>(".map-night-play")!;
      const yearOutput = night.querySelector<HTMLOutputElement>(".map-night-year")!;
      enabled.checked = restored.night?.enabled === true;
      scrub.value = restored.night?.year === "2016" ? "1" : "0";
      opacity.value = String(validOpacity(restored.night?.opacity, 85));
      const ids = new Map<string, string[]>();
      function showYear() {
        const year = scrub.value === "0" ? "2012" : "2016";
        yearOutput.value = year;
        scrub.setAttribute("aria-valuetext", year);
        if (enabled.checked && !ids.has(year)) {
          ids.set(year, []);
          for (const [i, image] of images[year].entries()) {
            const id = namespace + "night-" + year + "-" + i;
            m.addSource(id, { type: "image", url: asset("/data/features/maps/" + image.url), coordinates: image.coordinates });
            const before = m.getStyle().layers?.find(l => l.id.startsWith("region-lines-") || l.id === "city-points")?.id;
            m.addLayer({ id, type: "raster", source: id, paint: { "raster-opacity": Number(opacity.value) / 100, "raster-fade-duration": 0 } }, before);
            ids.get(year)!.push(id);
          }
        }
        for (const [date, layers] of ids) for (const id of layers) {
          visible(id, enabled.checked && date === year);
          m.setPaintProperty(id, "raster-opacity", Number(opacity.value) / 100);
        }
        saveSettings();
      }
      function pause() {
        if (interval) clearInterval(interval);
        interval = undefined;
        play.textContent = tr("Play", "Reproducir");
        play.setAttribute("aria-pressed", "false");
      }
      enabled.addEventListener("change", () => { if (!enabled.checked) pause(); showYear(); });
      scrub.addEventListener("input", () => { pause(); showYear(); });
      opacity.addEventListener("input", showYear);
      play.addEventListener("click", () => {
        if (interval) { pause(); return; }
        enabled.checked = true;
        showYear();
        interval = setInterval(() => { scrub.value = scrub.value === "0" ? "1" : "0"; showYear(); }, 1800);
        play.textContent = tr("Pause", "Pausar");
        play.setAttribute("aria-pressed", "true");
      });
      root.addEventListener("toggle", () => { if (!root.open) pause(); });
      document.addEventListener("visibilitychange", () => { if (document.hidden) pause(); }, { signal: lifecycle.signal });
      showYear();
    } else {
      const missing = document.createElement("p");
      missing.textContent = tr("Historical night-light imagery is not packaged for this country.", "Las imágenes históricas de iluminación nocturna no están disponibles para este país.");
      thematic.insertBefore(missing, button);
    }
  }
  function inspectClick(e: MapMouseEvent) {
    if (!inspect || !inspectOutput || !active.size) return;
    const ids = [...active.keys()].map(layerIds).filter(id => !!m.getLayer(id));
    const box: [[number, number], [number, number]] = [[e.point.x - 7, e.point.y - 7], [e.point.x + 7, e.point.y + 7]];
    const features = m.queryRenderedFeatures(box, { layers: ids }).slice(0, 4);
    inspectOutput.hidden = false;
    inspectOutput.innerHTML = features.length ? features.map(f => {
      const id = f.layer.id.replace(namespace + "overlay-", "");
      const layer = active.get(id)?.layer;
      const p = f.properties;
      const title = p.name_es && document.documentElement.lang === "es" ? p.name_es : p.name || p.name_en || layer && local(layer.label);
      const elevation = p.elevation ?? p.elev;
      const details = id === "density" ? `${Number(p.density).toLocaleString()} ${tr("people/km²", "hab./km²")} · ${Number(p.population).toLocaleString()} (2025)` : [p.featurecla, elevation != null ? `${elevation} m` : "", p.status].filter(Boolean).join(" · ");
      return `<p><strong>${esc(title)}</strong><br>${esc(details)}<br>${esc(layer?.source)} · ${esc(layer?.date)}</p>`;
    }).join("") : tr("No enabled layer feature at this point. Generalized layers omit small/local features.", "No hay elementos de las capas activas en este punto. Las capas generalizadas omiten elementos pequeños y locales.");
  }
  m.on("click", inspectClick);
  root.addEventListener("change", saveSettings);
  root.addEventListener("input", saveSettings);
}
