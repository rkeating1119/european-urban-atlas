export type LabelBox = { x: number; y: number; width: number; height: number };
export type CityLabel = LabelBox & { key: string };
export type RegionLabel = LabelBox & { key: string };
export type PlacedLabel = CityLabel & { dx: number; dy: number };

function overlap(a: LabelBox, b: LabelBox, gap = 4) {
  return (
    Math.max(
      0,
      Math.min(a.x + a.width + gap, b.x + b.width) - Math.max(a.x - gap, b.x),
    ) *
    Math.max(
      0,
      Math.min(a.y + a.height + gap, b.y + b.height) - Math.max(a.y - gap, b.y),
    )
  );
}

/**
 * Place centered region text before city text. x/y remain the projected geographic
 * anchor; dx/dy are pixel offsets for a Marker with its default center anchor.
 * Callers supply visible anchors and dot rectangles in the same viewport space.
 */
export function placeRegionLabels(
  labels: RegionLabel[],
  width: number,
  height: number,
  dots: LabelBox[] = [],
  controls: LabelBox[] = [],
): PlacedLabel[] {
  if (width <= 0 || height <= 0) return [];
  const padding = 5;
  const maxOffset = controls.length ? 96 : 72;
  const candidates = labels.map((label) => {
    const positions: {
      placed: PlacedLabel;
      box: LabelBox;
      distance: number;
    }[] = [];
    const seen = new Set<string>();
    for (let dy = -maxOffset; dy <= maxOffset; dy += 12) {
      for (let dx = -maxOffset; dx <= maxOffset; dx += 12) {
        if (Math.hypot(dx, dy) > maxOffset) continue;
        // At viewport edges, use the smallest additional correction needed to
        // keep the text inside. A wide label right on an edge can need >72px.
        const x = Math.max(
          padding,
          Math.min(
            width - label.width - padding,
            label.x + dx - label.width / 2,
          ),
        );
        const y = Math.max(
          padding,
          Math.min(
            height - label.height - padding,
            label.y + dy - label.height / 2,
          ),
        );
        const key = `${x}:${y}`;
        if (seen.has(key)) continue;
        seen.add(key);
        const placed = {
          ...label,
          dx: x + label.width / 2 - label.x,
          dy: y + label.height / 2 - label.y,
        };
        positions.push({
          placed,
          box: { x, y, width: label.width, height: label.height },
          distance: Math.hypot(placed.dx, placed.dy),
        });
      }
    }
    // Prefer the original anchor, then modest moves; ties are deterministic.
    return positions.sort((a, b) => a.distance - b.distance);
  });
  const selected: (typeof candidates)[number][number][] = [];
  const cost = (
    position: (typeof candidates)[number][number],
    occupied: LabelBox[],
  ) =>
    occupied.reduce((n, box) => n + overlap(position.box, box), 0) * 1000 +
    dots.reduce((n, box) => n + overlap(position.box, box, 2), 0) * 1000 +
    controls.reduce((n, box) => n + overlap(position.box, box, 2), 0) *
      1000000 +
    position.distance;
  for (const positions of candidates) {
    let best = positions[0];
    let bestCost = Infinity;
    for (const position of positions) {
      const nextCost = cost(
        position,
        selected.map((p) => p.box),
      );
      if (nextCost < bestCost) {
        best = position;
        bestCost = nextCost;
      }
    }
    selected.push(best);
  }
  // A later label can have fewer choices near an edge. Revisit earlier choices
  // against the full set so the first label does not permanently block its way.
  for (let pass = 0; pass < 3; pass++) {
    let changed = false;
    for (let i = 0; i < selected.length; i++) {
      const occupied = selected.filter((_, j) => j !== i).map((p) => p.box);
      let best = selected[i];
      let bestCost = cost(best, occupied);
      for (const position of candidates[i]) {
        const nextCost = cost(position, occupied);
        if (nextCost < bestCost) {
          best = position;
          bestCost = nextCost;
        }
      }
      if (best !== selected[i]) {
        selected[i] = best;
        changed = true;
      }
    }
    if (!changed) break;
  }
  return selected.map((p) => p.placed);
}

/** Move text labels only. Their geographic dots stay in the map circle layer. */
export function placeCityLabels(
  labels: CityLabel[],
  width: number,
  height: number,
  regions: LabelBox[] = [],
  dots: LabelBox[] = [],
  offset = 8,
): PlacedLabel[] {
  const candidates = labels.map((label) => {
    const positions: {
      placed: PlacedLabel;
      box: LabelBox;
      distance: number;
    }[] = [];
    const seen = new Set<string>();
    const step = label.height + 5;
    // Horizontal callouts preserve latitude in dense clusters. Dots never move.
    for (const row of [0, -1, 1, -2, 2]) {
      for (const column of [0, 1, 2]) {
        for (const right of [true, false]) {
          const distance = offset + column * (label.width + 12);
          const left = Math.max(
            5,
            Math.min(
              width - label.width - 5,
              label.x + (right ? distance : -label.width - distance),
            ),
          );
          const top = Math.max(
            5,
            Math.min(
              height - label.height - 5,
              label.y + row * step - label.height / 2,
            ),
          );
          const key = `${left}:${top}`;
          if (seen.has(key)) continue;
          seen.add(key);
          const dx = left - label.x,
            dy = top + label.height / 2 - label.y;
          positions.push({
            placed: { ...label, dx, dy },
            box: { x: left, y: top, width: label.width, height: label.height },
            distance: Math.hypot(dx, dy * 2) + (right ? 0 : 2),
          });
        }
      }
    }
    return positions;
  });
  const cost = (
    position: (typeof candidates)[number][number],
    occupied: LabelBox[],
  ) =>
    occupied.reduce((n, box) => n + overlap(position.box, box), 0) * 200 +
    dots.reduce((n, box) => n + overlap(position.box, box, 1), 0) * 200 +
    regions.reduce((n, box) => n + overlap(position.box, box, 1), 0) * 0.2 +
    position.distance;
  const selected: (typeof candidates)[number][number][] = [];
  for (const positions of candidates) {
    let best = positions[0],
      bestCost = Infinity;
    for (const position of positions) {
      const nextCost = cost(
        position,
        selected.map((p) => p.box),
      );
      if (nextCost < bestCost) {
        best = position;
        bestCost = nextCost;
      }
    }
    if (best) selected.push(best);
  }
  // A later city may have fewer free positions. Let earlier names yield space
  // after the full set is known, instead of locking in a greedy obstruction.
  for (let pass = 0; pass < 4; pass++) {
    let changed = false;
    for (let i = 0; i < selected.length; i++) {
      const occupied = selected.filter((_, j) => j !== i).map((p) => p.box);
      let best = selected[i],
        bestCost = cost(best, occupied);
      for (const position of candidates[i]) {
        const nextCost = cost(position, occupied);
        if (nextCost < bestCost) {
          best = position;
          bestCost = nextCost;
        }
      }
      if (best !== selected[i]) {
        selected[i] = best;
        changed = true;
      }
    }
    if (!changed) break;
  }
  return selected.map((p) => p.placed);
}
