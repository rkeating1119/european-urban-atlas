import type { Map as LibreMap } from "maplibre-gl";
import {
  asset,
  base,
  route,
  tr,
  language,
  escapeHTML as esc,
  normalize,
  loadJSON,
} from "./feature-core";
type Place = {
  id: string;
  countryId: string;
  kind: string;
  name: string;
  nameEs?: string;
  aliases?: string[];
  regionId: string;
  provinceId?: string;
  lat: number;
  lon: number;
  profile?: string;
  population?: { value: number; year: number; unit: string };
  referenceYear?: number;
  geometryYear?: number;
  note?: {en:string;es:string};
};
type Directory = {
  entries: Place[];
  provinces: { id: string; name: string; regionId: string }[];
  sources: { title: string; url: string }[];
};
type Context = {
  countries: {
    id: string;
    name: string;
    regions: { id: string; name: string }[];
  }[];
};
const name = (p: Place) => (language === "es" && p.nameEs ? p.nameEs : p.name);
const kindName = (p: Place) =>
  ({
    city: tr("City", "Ciudad"),
    municipality: tr("Municipality", "Municipio"),
    region: tr("Region", "Región"),
    province: tr("Province", "Provincia"),
    "functional-urban-area":tr("Functional urban area", "Área urbana funcional"),
  })[p.kind] || p.kind;
export async function directoryMatches(
  query: string,
  excluded: Set<string>,
): Promise<Place[]> {
  const d = await loadJSON<Directory>("/data/directory.json"),
    q = normalize(query);
  return d.entries
    .filter(
      (p) =>
        !excluded.has(p.profile || "") &&
        normalize([p.name, p.nameEs, ...(p.aliases || [])].join(" ")).includes(
          q,
        ),
    )
    .sort(
      (a, b) =>
        Number(normalize(name(b)) === q) - Number(normalize(name(a)) === q),
    )
    .slice(0, 5);
}
export async function mountExplorer(
  m: LibreMap,
  node: HTMLElement,
  context: Context,
) {
  const form = document.querySelector<HTMLFormElement>("#explorer-form");
  if (!form) return;
  const status = document.querySelector<HTMLElement>("#explorer-status")!,
    results = document.querySelector<HTMLElement>("#explorer-results")!,
    preview = document.querySelector<HTMLElement>("#explorer-preview")!,
    more = document.querySelector<HTMLButtonElement>("#explorer-more")!;
  status.textContent = tr("Loading places…", "Cargando lugares…");
  const d = await loadJSON<Directory>("/data/directory.json"),
    country = form.elements.namedItem("country") as HTMLSelectElement,
    kind = form.elements.namedItem("kind") as HTMLSelectElement,
    region = form.elements.namedItem("region") as HTMLSelectElement,
    province = form.elements.namedItem("province") as HTMLSelectElement,
    q = form.elements.namedItem("q") as HTMLInputElement;
  const params = new URLSearchParams(location.search);
  country.value = params.get("country") || form.dataset.country || "";
  kind.value = params.get("kind") || "";
  q.value = params.get("q") || "";
  let matches: Place[] = [],
    limit = 40,
    selected: Place | undefined;
  let recent: string[] = [];
  try { recent = JSON.parse(sessionStorage.getItem("atlas-explorer-recent") || "[]"); } catch {}
  const searchNames = new Map(d.entries.map(p => [p.id,normalize([p.name,p.nameEs,...(p.aliases||[]),d.provinces.find(v => v.id === p.provinceId)?.name || ""].join(" "))]));
  const stateKey = "atlas-explore-selected:" + location.pathname.replace(base+"/es/",base+"/");
  m.addSource("explorer-selection", {
    type: "geojson",
    data: { type: "FeatureCollection", features: [] },
  });
  m.addLayer({
    id: "explorer-selection",
    type: "circle",
    source: "explorer-selection",
    paint: {
      "circle-radius": 7,
      "circle-color": "#a64e39",
      "circle-stroke-color": "#fffef9",
      "circle-stroke-width": 2,
    },
  });
  function regionOptions() {
    const c = context.countries.find((c) => c.id === country.value);
    region.innerHTML =
      `<option value="">${tr("All regions", "Todas las regiones")}</option>` +
      (c?.regions || [])
        .map((r) => `<option value="${esc(r.id)}">${esc(r.name)}</option>`)
        .join("");
    province.innerHTML =
      `<option value="">${tr("All provinces", "Todas las provincias")}</option>` +
      d.provinces
        .filter((p) => !region.value || p.regionId === region.value)
        .map((p) => `<option value="${esc(p.id)}">${esc(p.name)}</option>`)
        .join("");
    province.disabled = country.value !== "ES";
    refreshMenus();
  }
  function refreshMenus() {
    for (const s of [country, kind, region, province])
      s.dispatchEvent(new Event("atlas-select-refresh"));
  }
  regionOptions();
  region.value = params.get("region") || "";
  province.value = params.get("province") || "";
  refreshMenus();
  function updateURL(p?: Place) {
    const u = new URL(location.href);
    for (const [k, v] of Object.entries({
      country: country.value,
      kind: kind.value,
      region: region.value,
      province: province.disabled ? "" : province.value,
      q: q.value,
      place: p?.id || "",
    })) {
      if (v) u.searchParams.set(k, v);
      else u.searchParams.delete(k);
    }
    history.replaceState(null, "", u);
  }
  function drawResults() {
    results.innerHTML = matches
      .slice(0, limit)
      .map(
        (p) =>
          `<button type="button" class="place-result" data-place="${esc(p.id)}"><strong>${esc(name(p))}</strong><small>${esc(kindName(p))} · ${esc(context.countries.find((c) => c.id === p.countryId)?.name)}</small></button>`,
      )
      .join("");
    more.hidden = limit >= matches.length;
    status.textContent = `${matches.length.toLocaleString(language)} ${tr("places", "lugares")}`;
  }
  function filter(reset = true) {
    if (reset) limit = 40;
    const query = normalize(q.value);
    matches = d.entries.filter(
      (p) =>
        (!country.value || p.countryId === country.value) &&
        (!kind.value ||
          (kind.value === "profile"
            ? !!p.profile && p.kind !== "region"
            : p.kind === kind.value)) &&
        (!region.value || p.regionId === region.value) &&
        (province.disabled ||
          !province.value ||
          p.provinceId === province.value) &&
        (!query ||
          searchNames.get(p.id)!.includes(query)),
    );
    if(query) matches.sort((a,b)=>Number(normalize(name(b))===query)-Number(normalize(name(a))===query));
    drawResults();
    updateURL(selected);
  }
  function select(p: Place, animate = true) {
    selected = p;
    const c = context.countries.find((c) => c.id === p.countryId),
      r = c?.regions.find((r) => r.id === p.regionId),
      prov = d.provinces.find((v) => v.id === p.provinceId);
    const source = m.getSource(
      "explorer-selection",
    ) as import("maplibre-gl").GeoJSONSource;
    source.setData({
      type: "FeatureCollection",
      features: [
        {
          type: "Feature",
          properties: { id: p.id },
          geometry: { type: "Point", coordinates: [p.lon, p.lat] },
        },
      ],
    });
    if (animate)
      m.flyTo({
        center: [p.lon, p.lat],
        zoom: p.kind === "region" || p.kind === "province" ? 6 : p.kind === "functional-urban-area" ? 8 : 10,
        duration: matchMedia("(prefers-reduced-motion: reduce)").matches
          ? 0
          : 650,
      });
    preview.innerHTML = `<p class="eyebrow">${esc(kindName(p))} · ${esc(c?.name)}</p><h2>${esc(name(p))}</h2><p>${[r?.name, p.kind !== "province" && prov?.name].filter(Boolean).map(esc).join(" · ")}</p>${p.population ? `<p>${p.population.value.toLocaleString(language)} ${tr("residents", "habitantes")} · ${p.population.year} · ${esc(p.population.unit === "municipality" ? tr("municipality", "municipio") : p.population.unit === "province" ? tr("province", "provincia") : p.population.unit)}</p>` : ""}${p.profile ? `<a class="button light" href="${esc(route(p.profile))}">${tr("Read the profile", "Leer el artículo")} →</a>` : `<p>${tr("This directory entry provides geographic facts; there is no long city article for this place.", "Esta entrada reúne datos geográficos; este lugar no tiene un artículo extenso.")}</p>`}${p.note ? `<p>${esc(p.note[language])}</p>` : ""}${p.countryId === "ES" ? `<details><summary>${tr("Geographic sources", "Fuentes geográficas")}</summary><p>${tr("Municipal names: 2026. Municipal population: Padrón, 1 January 2025. Boundaries: GISCO 2024. The point identifies the municipality, not a surveyed town-center address.", "Nombres municipales: 2026. Población municipal: padrón del 1 de enero de 2025. Límites: GISCO 2024. El punto identifica el municipio, no una dirección levantada en su centro.")}</p>${d.sources.map((s) => `<p><a href="${esc(s.url)}" target="_blank" rel="noopener noreferrer">${esc(s.title)}</a></p>`).join("")}</details>` : ""}`;
    updateURL(p);
    try {
      sessionStorage.setItem(stateKey, p.id);
      sessionStorage.setItem("atlas-map-origin", location.pathname+location.search);
    } catch {}
    preview.querySelector("a.button")?.addEventListener("click", () => {
      try {
        sessionStorage.setItem("atlas-map-origin", location.pathname+location.search);
      } catch {}
    });
  }
  results.addEventListener("click", (e) => {
    const button = (e.target as Element).closest<HTMLElement>("[data-place]");
    const p = d.entries.find((p) => p.id === button?.dataset.place);
    if (p) select(p);
  });
  more.addEventListener("click", () => {
    limit += 40;
    drawResults();
  });
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    filter();
  });
  country.addEventListener("change", () => {
    regionOptions();
    selected = undefined;
    (m.getSource("explorer-selection") as import("maplibre-gl").GeoJSONSource).setData({type:"FeatureCollection",features:[]});
    preview.innerHTML = `<h2>${tr("Choose a place", "Elige un lugar")}</h2><p>${tr("Select a result or try the random button.","Selecciona un resultado o prueba el botón de azar.")}</p>`;
    try { sessionStorage.removeItem(stateKey); } catch {}
    filter();
  });
  region.addEventListener("change", () => {
    province.value = "";
    province.innerHTML =
      `<option value="">${tr("All provinces", "Todas las provincias")}</option>` +
      d.provinces
        .filter((p) => !region.value || p.regionId === region.value)
        .map((p) => `<option value="${esc(p.id)}">${esc(p.name)}</option>`)
        .join("");
    refreshMenus();
    filter();
  });
  for (const input of [kind, province])
    input.addEventListener("change", () => filter());
  let timer: ReturnType<typeof setTimeout>;
  q.addEventListener("input", () => {
    clearTimeout(timer);
    timer = setTimeout(() => filter(), 120);
  });
  document.querySelector("#explore-random")!.addEventListener("click", () => {
    filter();
    let pool = matches.filter((p) => !recent.includes(p.id));
    if (!pool.length) {
      recent.length = 0;
      pool = matches;
    }
    if (!pool.length) return;
    const p = pool[Math.floor(Math.random() * pool.length)];
    recent.push(p.id);
    if (recent.length > 50) recent.shift();
    try { sessionStorage.setItem("atlas-explorer-recent",JSON.stringify(recent)); } catch {}
    select(p);
    preview.focus({ preventScroll: true });
  });
  filter();
  let id = params.get("place");
  if (!id && params.get("map") === "restore")
    try {
      id = sessionStorage.getItem(stateKey);
    } catch {}
  const initial = d.entries.find((p) => p.id === id);
  if (initial) select(initial, params.get("map") !== "restore");
}
