export type Bilingual = { en: string; es: string };
export const base = document.documentElement.dataset.base || "";
export const language = document.documentElement.lang === "es" ? "es" : "en";
export const release = document.documentElement.dataset.release || "current";
export const tr = (en: string, es: string) => (language === "es" ? es : en);
export const local = (s: string | Bilingual) =>
  typeof s === "string" ? s : s[language];
export const asset = (p: string) => base + p;
export const route = (p: string) => base + (language === "es" ? "/es" : "") + p;
export const escapeHTML = (v: unknown) =>
  String(v ?? "").replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ]!,
  );
export const normalize = (s: string) =>
  s
    .normalize("NFD")
    .replace(/\p{Diacritic}/gu, "")
    .toLowerCase()
    .replace(/[’'.,/–-]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
const requests = new Map<string, Promise<any>>();
export function loadJSON<T>(path: string): Promise<T> {
  if (!requests.has(path))
    requests.set(
      path,
      fetch(asset(path) + `?v=${release}`)
        .then((r) => {
          if (!r.ok)
            throw Error(
              tr("Data could not load", "No se pudieron cargar los datos"),
            );
          return r.json();
        })
        .catch((e) => {
          requests.delete(path);
          throw e;
        }),
    );
  return requests.get(path)!;
}
