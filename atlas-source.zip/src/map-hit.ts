/** Pick city geography in screen pixels; region polygons never participate. */
export const CITY_RADIUS_STOPS = [2, 0.8, 4, 2, 5, 3, 7, 5, 10, 7, 14, 9];

/** The visible circle, its outline, and a small allowance for its edge. */
export function cityDotHitRadius(zoom: number): number {
  function interpolate(stops: number[]) {
    for (let i = 2; i < stops.length; i += 2) {
      if (zoom <= stops[i]) {
        const t = Math.max(
          0,
          (zoom - stops[i - 2]) / (stops[i] - stops[i - 2]),
        );
        return stops[i - 1] + t * (stops[i + 1] - stops[i - 1]);
      }
    }
    return stops[stops.length - 1];
  }
  return (
    interpolate(CITY_RADIUS_STOPS) + interpolate([2, 0.3, 5, 1, 10, 1.8]) + 2
  );
}

export function nearestCity<T extends { lon: number; lat: number }>(
  cities: T[],
  project: (position: [number, number]) => { x: number; y: number },
  point: { x: number; y: number },
  radius: number,
): T | undefined {
  let closest: T | undefined;
  let distance = radius * radius;
  for (const city of cities) {
    const p = project([city.lon, city.lat]);
    const next = (p.x - point.x) ** 2 + (p.y - point.y) ** 2;
    if (Number.isFinite(next) && next <= distance) {
      closest = city;
      distance = next;
    }
  }
  return closest;
}
