import type { Map as LibreMap, Marker } from "maplibre-gl";
import { nearestCity, CITY_RADIUS_STOPS, cityDotHitRadius } from "./map-hit";
import { placeCityLabels, placeRegionLabels } from "./map-labels";

type Rating = { score: number; summary: string };
type City = {
  id: string;
  name: string;
  aliases: string[];
  countryId: string;
  regionId: string;
  regionName: string;
  lat: number;
  lon: number;
  summary: string;
  goodFor: string[];
  tradeoffs: string[];
  population: { value: number; year: number; unit: string } | null;
  size: string;
  ratings: Record<string, Rating>;
  countryName: string;
  details: Record<string, string>;
  url: string;
  mapLabel: boolean;
};
type Country = {
  id: string;
  slug: string;
  name: string;
  summary: string;
  url: string;
  regions: {
    id: string;
    name: string;
    summary: string;
    url: string;
    cityIds: string[];
  }[];
  cities: { id: string; name: string }[];
  color: string;
  view: {
    center: [number, number];
    zoom: number;
    bounds?: [number, number, number, number];
    insets: { name: string; center: [number, number]; zoom: number }[];
  };
};
type Atlas = {
  language: string;
  overview: { center: [number, number]; zoom: number };
  countries: Country[];
  cities: City[];
  categories: { id: string; name: string; description: string }[];
};
const base = document.documentElement.dataset.base ?? "";
const release = document.documentElement.dataset.release ?? "current";
const lang = document.documentElement.lang === "es" ? "es" : "en";
const text = (en: string, es: string) => (lang === "es" ? es : en);
const canonicalMapPath = (path: string) =>
  path.startsWith(base + "/es/") ? base + path.slice(base.length + 3) : path;
const mapStorageKey = (path = location.pathname) =>
  `atlas-map-view:${canonicalMapPath(path)}`;
const route = (path: string) => base + (lang === "es" ? "/es" : "") + path;
const asset = (path: string) => base + path;
const $ = <T extends HTMLElement>(selector: string) =>
  document.querySelector<T>(selector);
const esc = (v: unknown) =>
  String(v ?? "").replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ]!,
  );
const norm = (v: string) =>
  v
    .normalize("NFD")
    .replace(/\p{Diacritic}/gu, "")
    .toLowerCase()
    .replace(/[’'.,/-]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
let dataPromise: Promise<Atlas> | undefined;
const data = (): Promise<Atlas> =>
  (dataPromise ??= fetch(
    asset(`/data/atlas${lang === "es" ? "-es" : ""}.json?v=${release}`),
  ).then((r) => {
    if (!r.ok)
      throw Error(
        text("City data could not load", "No se pudieron cargar las ciudades"),
      );
    return r.json();
  }));
let indexPromise: Promise<Atlas> | undefined;
const indexData = (): Promise<Atlas> =>
  (indexPromise ??= fetch(
    asset(`/data/atlas-index${lang === "es" ? "-es" : ""}.json?v=${release}`),
  ).then((r) => {
    if (!r.ok) throw Error("Index unavailable");
    return r.json();
  }));
function cityMatches(c: City, q: string) {
  return norm([c.name, ...c.aliases, c.regionName].join(" ")).includes(q);
}
function stars(score: number) {
  return `<span class="rating-value" aria-label="${score} ${text("out of 5", "de 5")}"><b>${score}</b><small>/5</small><span class="rating-dots" aria-hidden="true">${"●".repeat(score)}${"○".repeat(5 - score)}</span></span>`;
}
function card(c: City) {
  return `<a class="browse-city" href="${esc(c.url)}"><span class="eyebrow">${esc(c.regionName)} · ${esc(c.countryName || c.countryId)}</span><h3>${esc(c.name)} <span aria-hidden="true">↗</span></h3><p>${esc(c.summary)}</p><div class="city-tags">${c.goodFor
    .slice(0, 3)
    .map((x) => `<span>${esc(x)}</span>`)
    .join("")}</div></a>`;
}
function soundControls() {
  const nav = document.querySelector(".main-nav");
  if (!nav) return;
  let enabled = true;
  try {
    enabled = localStorage.getItem("atlas-sounds") !== "off";
  } catch {}
  let context: AudioContext | undefined;
  let last = 0;
  let toggle = $<HTMLButtonElement>("#sound-toggle");
  if (!toggle) {
    toggle = document.createElement("button");
    toggle.id = "sound-toggle";
    toggle.type = "button";
    toggle.className = "sound-control";
    nav.append(toggle);
  }
  function update() {
    toggle!.innerHTML = enabled ? "♪" : "♩";
    toggle!.setAttribute("aria-pressed", String(enabled));
    toggle!.setAttribute(
      "aria-label",
      enabled
        ? text("Turn off sounds", "Desactivar sonidos")
        : text("Turn on sounds", "Activar sonidos"),
    );
    toggle!.title = enabled
      ? text("Sound on", "Sonido activado")
      : text("Sound off", "Sonido desactivado");
  }
  function tick(language = false) {
    if (!enabled || performance.now() - last < 65) return;
    last = performance.now();
    try {
      context ??= new AudioContext();
      if (context.state === "suspended") void context.resume();
      const oscillator = context.createOscillator(),
        gain = context.createGain(),
        now = context.currentTime;
      oscillator.type = "sine";
      oscillator.frequency.setValueAtTime(language ? 720 : 590, now);
      oscillator.frequency.exponentialRampToValueAtTime(
        language ? 920 : 530,
        now + 0.045,
      );
      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.018, now + 0.005);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.065);
      oscillator.connect(gain);
      gain.connect(context.destination);
      oscillator.start(now);
      oscillator.stop(now + 0.07);
    } catch {
      /* Sound is optional; controls must still work. */
    }
  }
  toggle.addEventListener("click", (event) => {
    event.stopPropagation();
    enabled = !enabled;
    try {
      localStorage.setItem("atlas-sounds", enabled ? "on" : "off");
    } catch {}
    update();
    tick();
  });
  document.addEventListener(
    "click",
    (event) => {
      if ((event.target as Element).closest("a,button,summary"))
        tick(!!(event.target as Element).closest("[data-language-toggle]"));
    },
    { capture: true },
  );
  document.addEventListener("atlas-map-click", () => tick());
  update();
}
function carousels() {
  for (const rail of document.querySelectorAll<HTMLElement>(
    "[data-city-carousel]",
  )) {
    const track = rail.querySelector<HTMLElement>(".city-carousel-track")!;
    const previous =
      rail.querySelector<HTMLButtonElement>(".carousel-previous")!;
    const next = rail.querySelector<HTMLButtonElement>(".carousel-next")!;
    const status = rail.querySelector<HTMLElement>(".carousel-position");
    const cards = [...track.children] as HTMLElement[];
    function update() {
      previous.disabled = track.scrollLeft < 3;
      next.disabled =
        track.scrollLeft + track.clientWidth >= track.scrollWidth - 3;
      const width = cards[0]?.getBoundingClientRect().width || 1;
      const gap = Number.parseFloat(getComputedStyle(track).columnGap) || 0;
      const first = Math.min(
        cards.length,
        Math.round(track.scrollLeft / (width + gap)) + 1,
      );
      const count = Math.max(
        1,
        Math.round((track.clientWidth + gap) / (width + gap)),
      );
      if (status)
        status.textContent = `${first}–${Math.min(cards.length, first + count - 1)} / ${cards.length}`;
    }
    const move = (direction: number) =>
      track.scrollBy({
        left: direction * (track.clientWidth + 24),
        behavior: matchMedia("(prefers-reduced-motion: reduce)").matches
          ? "instant"
          : "smooth",
      });
    previous.addEventListener("click", () => move(-1));
    next.addEventListener("click", () => move(1));
    track.addEventListener("scroll", update, { passive: true });
    new ResizeObserver(update).observe(track);
    update();
  }
}
async function search() {
  const input = $<HTMLInputElement>("#global-search"),
    out = $("#search-results");
  if (!input || !out) return;
  let sequence = 0;
  input.addEventListener("input", async () => {
    const s = ++sequence,
      q = norm(input.value);
    if (!q) {
      out.hidden = true;
      return;
    }
    out.hidden = false;
    try {
      const atlas = await indexData();
      if (s !== sequence) return;
      const cs = atlas.cities
        .filter((c) => cityMatches(c, q))
        .sort(
          (a, b) =>
            Number(norm(b.name) === q) - Number(norm(a.name) === q) ||
            (b.population?.value ?? 0) - (a.population?.value ?? 0),
        );
      const countries = atlas.countries.filter((c) => norm(c.name).includes(q));
      const regions = atlas.countries
        .flatMap((c) => c.regions.map((r) => ({ ...r, country: c.name })))
        .filter((r) => norm(r.name).includes(q));
      const extra = cs.length < 8 && q.length >= 2
        ? await import("./directory").then(({directoryMatches}) => directoryMatches(input.value,new Set(cs.map(c => c.url.replace(base, "").replace(/^\/es\//,"/"))))) : [];
      if(s !== sequence) return;
      out.innerHTML =
        countries
          .map(
            (c) =>
              `<a href="${esc(c.url)}"><strong>${esc(c.name)}</strong><small>${text("Country", "País")}</small></a>`,
          )
          .join("") +
        regions
          .slice(0, 3)
          .map(
            (r) =>
              `<a href="${esc(r.url)}"><strong>${esc(r.name)}</strong><small>${esc(r.country)}</small></a>`,
          )
          .join("") +
        cs
          .slice(0, 8)
          .map(
            (c) =>
              `<a href="${esc(c.url)}"><strong>${esc(c.name)}</strong><small>${esc(c.regionName)} · ${esc(c.countryId)}</small></a>`,
          )
          .join("") +
        extra.map(p => `<a href="${route("/explore/")}?place=${encodeURIComponent(p.id)}"><strong>${esc(lang === "es" && p.nameEs ? p.nameEs : p.name)}</strong><small>${text("Geographic directory", "Directorio geográfico")} · ${esc(p.countryId)}</small></a>`).join("") +
        `<a href="${route("/cities/")}?q=${encodeURIComponent(input.value)}">${cs.length ? `${text("See", "Ver")} ${cs.length} ${text("matching cities", "ciudades encontradas")}` : text("Explore all cities", "Explorar todas las ciudades")} →</a>`;
    } catch {
      out.innerHTML = `<a href="${route("/cities/")}">${text("Explore cities", "Explorar ciudades")} →</a>`;
    }
  });
  input.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      out.hidden = true;
      input.blur();
    }
    if (e.key === "ArrowDown") {
      e.preventDefault();
      out.querySelector<HTMLAnchorElement>("a")?.focus();
    }
  });
  document.addEventListener("click", (e) => {
    if (!(e.target as Element).closest(".search-wrap")) out.hidden = true;
  });
}
function languageControl() {
  const toggle = document.querySelector<HTMLAnchorElement>(
    "[data-language-toggle]",
  );
  toggle?.addEventListener("click", (event) => {
    if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey)
      return;
    event.preventDefault();
    const target = new URL(toggle.href);
    target.search = location.search;
    target.hash = location.hash;
    try {
      const map = document.querySelector<HTMLElement>("#atlas-map");
      if (map && !map.dataset.city && sessionStorage.getItem(mapStorageKey()))
        target.searchParams.set("map", "restore");
    } catch {}
    try {
      localStorage.setItem("atlas-language", lang === "es" ? "en" : "es");
    } catch {}
    setTimeout(() => {
      location.href = target.href;
    }, 75);
  });
}
function mapReturnLinks() {
  let path: string | null = null;
  try {
    path = sessionStorage.getItem("atlas-map-origin");
  } catch {
    /* Optional continuity. */
  }
  for (const link of document.querySelectorAll<HTMLAnchorElement>(
    ".map-return",
  )) {
    if(path && path.startsWith(base + "/")) {
      const target = new URL(path,location.origin);
      if(target.origin !== location.origin) continue;
      if(lang === "es" && !target.pathname.startsWith(base + "/es/")) target.pathname=base + "/es" + target.pathname.slice(base.length);
      if(lang === "en" && target.pathname.startsWith(base + "/es/")) target.pathname=base + target.pathname.slice(base.length+3);
      if(target.pathname === location.pathname) continue;
      target.searchParams.set("map","restore");target.hash="atlas-map";link.href=target.href;
    }
  }
}
function navigation() {
  document.querySelectorAll<HTMLSelectElement>(".country-switch").forEach((s) =>
    s.addEventListener("change", () => {
      location.href = s.value;
    }),
  );
  document.querySelectorAll<HTMLSelectElement>(".city-switch").forEach((s) =>
    s.addEventListener("change", () => {
      if (s.value) {
        try {
          sessionStorage.setItem("atlas-map-origin", location.pathname);
        } catch {}
        location.href = s.value;
      }
    }),
  );
}
// Keep form values in the native controls, but render and operate menus in-page.
// This also covers dynamically populated region and comparison choices.
let dropdownSequence = 0;
let closeCurrent: (() => void) | undefined;
function dropdowns() {
  document
    .querySelectorAll<HTMLSelectElement>("select")
    .forEach((select) => {
      if (select.dataset.customized) return;
      const index = dropdownSequence++;
      const label = select.closest("label");
      const name =
        select.getAttribute("aria-label") ||
        (label
          ? [...label.childNodes]
              .filter((n) => n.nodeType === Node.TEXT_NODE)
              .map((n) => n.textContent)
              .join(" ")
              .trim() || label.querySelector(".sr-only")?.textContent
          : "") ||
        text("Choose an option", "Elegir una opción");
      const root = document.createElement("div");
      root.className = "site-select";
      const trigger = document.createElement("button");
      trigger.type = "button";
      trigger.className = "select-trigger";
      trigger.id = `select-trigger-${index}`;
      trigger.setAttribute("aria-label", name);
      trigger.setAttribute("aria-haspopup", "listbox");
      trigger.setAttribute("aria-expanded", "false");
      trigger.setAttribute("aria-controls", `select-options-${index}`);
      const panel = document.createElement("div");
      panel.className = "select-panel";
      panel.hidden = true;
      const filter = document.createElement("input");
      filter.type = "search";
      filter.className = "select-search";
      filter.placeholder = text("Type to find…", "Escribe para buscar…");
      filter.setAttribute(
        "aria-label",
        text(`Search ${name.toLowerCase()}`, `Filtrar opciones: ${name}`),
      );
      filter.autocomplete = "off";
      const list = document.createElement("div");
      list.id = `select-options-${index}`;
      list.className = "select-options";
      list.setAttribute("role", "listbox");
      list.setAttribute("aria-label", name);
      panel.append(filter, list);
      select.before(root);
      root.append(select, trigger, panel);
      select.hidden = true;
      select.dataset.customized = "true";
      select.tabIndex = -1;
      select.setAttribute("aria-hidden", "true");
      if (label) label.htmlFor = trigger.id;
      function sync() {
        const option = select.selectedOptions[0];
        trigger.innerHTML = `<span>${esc(option?.textContent || text("Choose…", "Elegir…"))}</span><span class="select-chevron" aria-hidden="true">⌄</span>`;
        trigger.disabled = select.disabled;
        filter.hidden = select.options.length < 9;
        renderOptions();
      }
      function renderOptions() {
        const query = norm(filter.value);
        let group = "";
        list.innerHTML = "";
        for (const option of select.options) {
          const parent = option.parentElement;
          const heading =
            parent instanceof HTMLOptGroupElement ? parent.label : "";
          if (
            query &&
            !norm(`${option.textContent} ${heading}`).includes(query)
          )
            continue;
          if (heading && heading !== group) {
            const title = document.createElement("p");
            title.className = "select-group";
            title.textContent = heading;
            title.setAttribute("role", "presentation");
            list.append(title);
          }
          group = heading;
          const choice = document.createElement("button");
          choice.type = "button";
          choice.className = "select-option";
          choice.setAttribute("role", "option");
          choice.setAttribute("aria-selected", String(option.selected));
          choice.tabIndex = -1;
          choice.disabled = option.disabled;
          choice.textContent = option.textContent;
          choice.addEventListener("click", () => {
            select.value = option.value;
            close(true);
            select.dispatchEvent(new Event("change", { bubbles: true }));
            sync();
          });
          list.append(choice);
        }
        if (!list.querySelector("button"))
          list.innerHTML = `<p class="select-empty">${text("No matching places.", "No hay coincidencias.")}</p>`;
      }
      function close(focus = false) {
        panel.hidden = true;
        root.classList.remove("is-open");
        trigger.setAttribute("aria-expanded", "false");
        if (focus) trigger.focus();
        if (closeCurrent === dismiss) closeCurrent = undefined;
      }
      const dismiss = () => close();
      function open() {
        closeCurrent?.();
        closeCurrent = dismiss;
        filter.value = "";
        sync();
        panel.hidden = false;
        root.classList.add("is-open");
        trigger.setAttribute("aria-expanded", "true");
        const rect = trigger.getBoundingClientRect();
        const mapBox = root.closest(".map-shell")?.getBoundingClientRect();
        const above = rect.top - Math.max(12, mapBox ? mapBox.top + 12 : 12);
        const below =
          Math.min(
            innerHeight - 12,
            mapBox ? mapBox.bottom - 12 : innerHeight - 12,
          ) - rect.bottom;
        const opensUp = (!!mapBox && !root.closest(".atlas-map-tools")) || (below < 230 && above > below);
        root.classList.toggle("opens-up", opensUp);
        list.style.maxHeight = `${Math.max(85, Math.min(340, (opensUp ? above : below) - (filter.hidden ? 20 : 67)))}px`;
        panel.style.left = "0";
        panel.style.right = "auto";
        if (panel.getBoundingClientRect().right > innerWidth - 12) {
          panel.style.left = "auto";
          panel.style.right = "0";
        }
        if (!filter.hidden) filter.focus();
        else
          list
            .querySelector<HTMLButtonElement>('[aria-selected="true"]')
            ?.focus();
      }
      trigger.addEventListener("click", () =>
        panel.hidden ? open() : close(),
      );
      trigger.addEventListener("keydown", (event) => {
        if (event.key === "Escape") {
          event.preventDefault();
          close(true);
          return;
        }
        if (["ArrowDown", "ArrowUp"].includes(event.key)) {
          event.preventDefault();
          open();
          if (filter.hidden)
            list.querySelector<HTMLButtonElement>("button")?.focus();
        }
      });
      panel.addEventListener("keydown", (event) => {
        const options = [
          ...list.querySelectorAll<HTMLButtonElement>("button:not(:disabled)"),
        ];
        const current = options.indexOf(
          document.activeElement as HTMLButtonElement,
        );
        if (event.key === "Escape") {
          event.preventDefault();
          event.stopPropagation();
          close(true);
        } else if (
          ["ArrowDown", "ArrowUp", "Home", "End"].includes(event.key)
        ) {
          if (event.target === filter && ["Home", "End"].includes(event.key))
            return;
          event.preventDefault();
          const next =
            event.key === "Home"
              ? 0
              : event.key === "End"
                ? options.length - 1
                : event.key === "ArrowDown"
                  ? Math.min(current + 1, options.length - 1)
                  : Math.max(current - 1, 0);
          options[next]?.focus();
        } else if (event.key === "Tab") close();
      });
      filter.addEventListener("input", (event) => {
        event.stopPropagation();
        renderOptions();
      });
      filter.addEventListener("keydown", (event) => {
        if (event.key === "Enter") {
          event.preventDefault();
          list.querySelector<HTMLButtonElement>("button")?.click();
        }
      });
      root.addEventListener("focusout", (event) => {
        if (!root.contains(event.relatedTarget as Node)) close();
      });
      document.addEventListener("pointerdown", (event) => {
        if (!root.contains(event.target as Node)) close();
      });
      select.addEventListener("change", sync);
      select.addEventListener("atlas-select-refresh", sync);
      new MutationObserver(sync).observe(select, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ["disabled", "selected", "label"],
      });
      sync();
    });
}
async function browse() {
  const form = $<HTMLFormElement>("#browse-form");
  if (!form) return;
  const atlas = await data(),
    out = $("#browse-results")!,
    count = $("#browse-count")!,
    country = $<HTMLSelectElement>("#browse-country")!,
    region = $<HTMLSelectElement>("#browse-region")!;
  const q = $<HTMLInputElement>("#browse-query")!,
    params = new URLSearchParams(location.search);
  q.value = params.get("q") ?? "";
  country.value = params.get("country") ?? form.dataset.country ?? "";
  country.dispatchEvent(new Event("atlas-select-refresh"));
  let initialRegion = params.get("region") ?? form.dataset.region ?? "";
  function regions() {
    const keep = region.value || initialRegion;
    initialRegion = "";
    region.innerHTML =
      `<option value="">${text("All regions", "Todas las regiones")}</option>` +
      atlas.countries
        .filter((c) => !country.value || c.id === country.value)
        .flatMap((c) =>
          c.regions.map(
            (r) =>
              `<option value="${c.id}:${esc(r.id)}">${esc(r.name)}${!country.value ? " · " + c.name : ""}</option>`,
          ),
        )
        .join("");
    region.value = keep;
  }
  function render() {
    const fd = new FormData(form!),
      query = norm(q.value),
      r = String(fd.get("region") ?? ""),
      theme = String(fd.get("theme") ?? ""),
      order = String(fd.get("sort") ?? "name");
    const cities = atlas.cities.filter(
      (c) =>
        (!country.value || c.countryId === country.value) &&
        (!r || `${c.countryId}:${c.regionId}` === r) &&
        (!query || cityMatches(c, query)) &&
        (!theme || (c.ratings[theme]?.score ?? 0) >= 4),
    );
    if (order === "population")
      cities.sort(
        (a, b) => (b.population?.value ?? 0) - (a.population?.value ?? 0),
      );
    else if (order === "affordability")
      cities.sort(
        (a, b) => b.ratings.affordability.score - a.ratings.affordability.score,
      );
    else cities.sort((a, b) => a.name.localeCompare(b.name));
    out.innerHTML =
      cities.map(card).join("") ||
      `<p class="empty">${text("No cities match. Try a different filter or spelling.", "No hay ciudades que coincidan. Prueba con otro filtro o nombre.")}</p>`;
    count.textContent = `${cities.length} ${cities.length === 1 ? text("city", "ciudad") : text("cities", "ciudades")}`;
  }
  regions();
  country.addEventListener("change", () => {
    region.value = "";
    regions();
    render();
  });
  form.addEventListener("input", render);
  form.addEventListener("change", render);
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    render();
  });
  render();
}
function compareMarkup(cities: City[], atlas: Atlas) {
  return `<div class="comparison-leads" style="--columns:${cities.length}">${cities.map((c) => `<article><p class="eyebrow">${esc(c.regionName)} · ${esc(atlas.countries.find((k) => k.id === c.countryId)?.name)}</p><h2><a href="${esc(c.url)}">${esc(c.name)} ↗</a></h2><p>${esc(c.summary)}</p><p class="compare-fit"><strong>${text("Distinctive features:", "Rasgos destacados:")}</strong> ${c.goodFor.map(esc).join(", ")}.</p></article>`).join("")}</div>${atlas.categories.map((category) => `<section class="compare-category"><div class="compare-category-title"><h3>${esc(category.name)}</h3><p>${esc(category.description)}</p></div><div class="comparison-values" style="--columns:${cities.length}">${cities.map((c) => `<article><p class="compare-city-label">${esc(c.name)}</p>${stars(c.ratings[category.id].score)}<p>${esc(c.ratings[category.id].summary)}</p></article>`).join("")}</div></section>`).join("")}${[
    {
      id: "food",
      name: text(
        "Food and everyday habits",
        "Gastronomía y hábitos cotidianos",
      ),
    },
    {
      id: "neighborhoods",
      name: text("Neighborhoods and contrasts", "Barrios y contrastes"),
    },
    {
      id: "architecture",
      name: text(
        "Architecture and street life",
        "Arquitectura y paisaje urbano",
      ),
    },
    {
      id: "education",
      name: text("Universities and schools", "Universidades y escuelas"),
    },
    {
      id: "people",
      name: text("People and everyday life", "Población y vida cotidiana"),
    },
    { id: "lgbtq", name: text("LGBT life", "Vida LGBT") },
    {
      id: "politics",
      name: text("Politics and civic life", "Política y vida cívica"),
    },
    {
      id: "geography",
      name: text("Geography and city layout", "Geografía y estructura urbana"),
    },
  ]
    .map(
      (category) =>
        `<section class="compare-category"><div class="compare-category-title"><h3>${category.name}</h3></div><div class="comparison-values" style="--columns:${cities.length}">${cities.map((c) => `<article><p class="compare-city-label">${esc(c.name)}</p><p>${esc(c.details[category.id as keyof City["details"]])}</p></article>`).join("")}</div></section>`,
    )
    .join(
      "",
    )}<section class="compare-category"><div class="compare-category-title"><h3>${text("Pressures and tensions", "Tensiones cotidianas")}</h3></div><div class="comparison-values" style="--columns:${cities.length}">${cities.map((c) => `<article><p class="compare-city-label">${esc(c.name)}</p><p>${c.tradeoffs.map(esc).join("; ")}</p><a class="text-link" href="${esc(c.url)}">${text("Read about", "Leer sobre")} ${esc(c.name)} →</a></article>`).join("")}</div></section>`;
}
async function compare() {
  const form = $<HTMLFormElement>("#compare-form");
  if (!form) return;
  const atlas = await data(),
    out = $("#compare-results")!,
    selects = [...form.querySelectorAll<HTMLSelectElement>("select")];
  const options = (empty = false) =>
    (empty
      ? `<option value="">${text("No third city", "Sin tercera ciudad")}</option>`
      : "") +
    atlas.countries
      .map(
        (c) =>
          `<optgroup label="${esc(c.name)}">${c.cities.map((city) => `<option value="${c.id}:${city.id}">${esc(city.name)}</option>`).join("")}</optgroup>`,
      )
      .join("");
  const params = new URLSearchParams(location.search),
    initial = params.get("cities")?.split(",") ?? [
      "ES:madrid",
      "FR:paris",
      "IT:rome",
    ];
  selects.forEach((s, i) => {
    s.innerHTML = options(i === 2);
    s.value = initial[i] ?? "";
  });
  function render() {
    const selected = selects
      .map((s) =>
        atlas.cities.find((c) => `${c.countryId}:${c.id}` === s.value),
      )
      .filter(Boolean) as City[];
    const distinct = [
      ...new Map(selected.map((c) => [`${c.countryId}:${c.id}`, c])).values(),
    ];
    if (distinct.length < 2) {
      out.innerHTML = `<p role="status">${text("Choose at least two different cities.", "Elige al menos dos ciudades distintas.")}</p>`;
      return;
    }
    out.innerHTML = compareMarkup(distinct, atlas);
    const url = new URL(location.href);
    url.searchParams.set(
      "cities",
      distinct.map((c) => `${c.countryId}:${c.id}`).join(","),
    );
    history.replaceState(null, "", url);
  }
  form.addEventListener("change", render);
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    render();
  });
  render();
}
async function map() {
  const node = $("#atlas-map");
  if (!node) return;
  // Search results and city cards also leave a country map. Remember its page
  // before asynchronous loading, so they cannot return to an older country.
  if (!node.dataset.city && !node.dataset.region) {
    try {
      sessionStorage.setItem("atlas-map-origin", location.pathname);
    } catch {
      /* The country link remains usable without saved continuity. */
    }
  }
  const disclosure = node.closest("details");
  if (disclosure && !disclosure.open)
    await new Promise<void>((resolve) => {
      const onToggle = () => {
        if (disclosure.open) {
          disclosure.removeEventListener("toggle", onToggle);
          resolve();
        }
      };
      disclosure.addEventListener("toggle", onToggle);
    });
  const status = $("#map-status");
  try {
    const atlas = await indexData(),
      { default: libre } = await import("maplibre-gl");
    const cc = node.dataset.country,
      regionId = node.dataset.region,
      selectedCity = node.dataset.city;
    const country = atlas.countries.find((c) => c.id === cc),
      city = atlas.cities.find(
        (c) => `${c.countryId}:${c.id}` === selectedCity,
      );
    const explorer = node.dataset.explorer === "true";
    const countrySelection = !country && !city && !explorer;
    node.dataset.mapMode = countrySelection ? "countries" : explorer ? "explorer" : "cities";
    const countries = await fetch(
      asset(`/data/maps/world.geojson?v=${release}`),
    ).then((r) => r.json());
    const layers = await Promise.all(
      (country ? [country] : []).map((c) =>
        fetch(asset(`/data/maps/${c.slug}-regions.geojson?v=${release}`))
          .then((r) => r.json())
          .then((d) => ({ country: c, geo: d })),
      ),
    );
    const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
    const stateKey = mapStorageKey();
    let savedView:
      | {
          center: [number, number];
          zoom: number;
          region?: string;
          inset?: string;
        }
      | undefined;
    try {
      if (new URLSearchParams(location.search).get("map") === "restore")
        savedView =
          JSON.parse(sessionStorage.getItem(stateKey) || "null") || undefined;
    } catch {
      /* Storage may be unavailable. */
    }
    const overviewZoom = () =>
      Math.max(
        2,
        (country ? country.view.zoom : atlas.overview?.zoom || 3.2) -
          Math.max(0, Math.log2(1050 / Math.max(240, node!.clientWidth))),
      );
    const m = new libre.Map({
      container: node,
      bounds: savedView || city ? undefined : country?.view.bounds,
      fitBoundsOptions: {
        padding: innerWidth < 700 ? 22 : 42,
        maxZoom: country?.view.zoom || 14,
      },
      style: {
        version: 8,
        glyphs: "https://tiles.openfreemap.org/fonts/{fontstack}/{range}.pbf",
        sprite: "https://tiles.openfreemap.org/sprites/ofm_f384/ofm",
        sources: { countries: { type: "geojson", data: countries } },
        layers: [
          {
            id: "water",
            type: "background",
            paint: { "background-color": "#dfe9e7" },
          },
          {
            id: "land",
            type: "fill",
            source: "countries",
            paint: {
              "fill-color": [
                "match",
                ["get", "id"],
                ...atlas.countries.flatMap((c) => [c.id, c.color]),
                "SJ",
                atlas.countries.find((c) => c.id === "NO")?.color || "#eeece4",
                "#eeece4",
              ] as any,
            },
          },
          {
            id: "borders",
            type: "line",
            source: "countries",
            paint: { "line-color": "#a0afa4", "line-width": 0.8 },
          },
        ],
      },
      center: savedView
        ? savedView.center
        : city
          ? [city.lon, city.lat]
          : country
            ? country.view.center
            : atlas.overview?.center || [9, 52],
      zoom: savedView ? savedView.zoom : city ? 9 : overviewZoom(),
      locale:
        lang === "es"
          ? {
              "NavigationControl.ZoomIn": "Acercar",
              "NavigationControl.ZoomOut": "Alejar",
              "FullscreenControl.Enter": "Ver a pantalla completa",
              "FullscreenControl.Exit": "Salir de pantalla completa",
              "AttributionControl.ToggleAttribution": "Mostrar atribuciones",
              "Map.Title": "Mapa",
              "Marker.Title": "Marcador del mapa",
              "Popup.Close": "Cerrar ventana",
              "CooperativeGesturesHandler.WindowsHelpText":
                "Pulsa Ctrl y desplaza la rueda para acercar o alejar el mapa",
              "CooperativeGesturesHandler.MacHelpText":
                "Pulsa ⌘ y desplaza la rueda para acercar o alejar el mapa",
              "CooperativeGesturesHandler.MobileHelpText":
                "Usa dos dedos para mover el mapa",
            }
          : undefined,
      attributionControl: false,
      maxZoom: 19,
      minZoom: 2,
      cooperativeGestures: !!city,
      renderWorldCopies: false,
    });
    function saveView() {
      try {
        const center = m.getCenter();
        sessionStorage.setItem(
          stateKey,
          JSON.stringify({
            center: [center.lng, center.lat],
            zoom: m.getZoom(),
            region: $<HTMLSelectElement>("#map-region")?.value,
            inset: $<HTMLSelectElement>("#map-inset")?.value,
          }),
        );
      } catch {
        /* Navigation works even without storage. */
      }
    }
    function rememberMap() {
      saveView();
      try {
        if (!city)
          sessionStorage.setItem("atlas-map-origin", location.pathname);
      } catch {
        /* Optional continuity. */
      }
    }
    m.on("moveend", saveView);
    addEventListener("pagehide", saveView, { once: true });
    m.dragRotate.disable();
    m.touchZoomRotate.disableRotation();
    m.addControl(
      new libre.NavigationControl({ showCompass: false }),
      "top-right",
    );
    m.addControl(
      new libre.FullscreenControl({ container: node.parentElement! }),
      "top-right",
    );
    m.addControl(
      new libre.AttributionControl({
        compact: false,
        customAttribution: text(
          "© EuroGeographics for the administrative boundaries · Eurostat GISCO",
          "Límites administrativos: © EuroGeographics · Eurostat GISCO",
        ),
      }),
    );
    const fit = (f: any) => {
      const points = (a: any): number[][] =>
        typeof a[0] === "number" ? [a] : a.flatMap(points);
      const b = new libre.LngLatBounds();
      points(f.geometry.coordinates).forEach((p) =>
        b.extend(p as [number, number]),
      );
      m.fitBounds(b, { padding: 45, maxZoom: 8, duration: reduced ? 0 : 500 });
    };
    const popup = new libre.Popup({ closeButton: true, maxWidth: "310px" }),
      markers: {
        marker: Marker;
        city?: City;
        kind: "city" | "country" | "region";
        element: HTMLElement;
      }[] = [];
    m.on("load", () => {
      if (status) status.hidden = true;
      void import("./map-tools").then(({mountMapTools}) => mountMapTools(m,node,{countryId:country?.id,countrySlug:country?.slug,countrySelection})).then(() => dropdowns()).catch(() => { if(status) {status.hidden=false;status.textContent=text("Extra map layers could not load. The atlas is still available.","No se pudieron cargar las capas adicionales. El atlas sigue disponible.");} });
      if (explorer)
        void import("./directory")
          .then(({ mountExplorer }) => mountExplorer(m, node, atlas))
          .catch(() => {
            const status = document.querySelector("#explorer-status");
            if (status)
              status.textContent = text(
                "Places could not load. Please try again.",
                "No se pudieron cargar los lugares. Inténtalo de nuevo.",
              );
          });
      for (const layer of layers) {
        m.addSource("regions-" + layer.country.id, {
          type: "geojson",
          data: layer.geo,
        });
        m.addLayer({
          id: "region-fill-" + layer.country.id,
          type: "fill",
          source: "regions-" + layer.country.id,
          paint: {
            "fill-color": "#628272",
            "fill-opacity": cc === layer.country.id ? 0.07 : 0,
          },
          minzoom: country ? 0 : 4.3,
        });
        m.addLayer({
          id: "region-lines-" + layer.country.id,
          type: "line",
          source: "regions-" + layer.country.id,
          minzoom: country ? 0 : 4.3,
          paint: { "line-color": "#789082", "line-width": 0.9 },
        });
        if (country && layer.country.id === country.id) {
          for (const feature of layer.geo.features) {
            const region = country.regions.find(
              (r) => r.id === feature.properties.id,
            );
            const point = feature.properties.labelPoint;
            if (!region || !point) continue;
            const link = document.createElement("a");
            link.className = "region-map-label";
            link.href = region.url;
            link.textContent = region.name;
            link.setAttribute(
              "aria-label",
              `${text("Explore region:", "Explorar región:")} ${region.name}`,
            );
            link.addEventListener("click", (event) => {
              event.stopPropagation();
              rememberMap();
              const rect = node!.getBoundingClientRect();
              const hit =
                event.detail > 0
                  ? nearestCity(
                      mapCities,
                      (p) => m.project(p),
                      {
                        x: event.clientX - rect.left,
                        y: event.clientY - rect.top,
                      },
                      cityDotHitRadius(m.getZoom()),
                    )
                  : undefined;
              if (hit) {
                event.preventDefault();
                location.href = hit.url;
              }
            });
            markers.push({
              marker: new libre.Marker({ element: link })
                .setLngLat(point)
                .addTo(m),
              kind: "region",
              element: link,
            });
            link.setAttribute("role", "link");
          }
        }
      }
      const mapCities =
        countrySelection || explorer
          ? []
          : atlas.cities.filter((c) => !country || c.countryId === country.id);
      const points = {
        type: "FeatureCollection",
        features: mapCities.map((c) => ({
          type: "Feature",
          properties: { key: `${c.countryId}:${c.id}` },
          geometry: { type: "Point", coordinates: [c.lon, c.lat] },
        })),
      };
      m.addSource("city-points", { type: "geojson", data: points as any });
      m.addLayer({
        id: "city-points",
        type: "circle",
        source: "city-points",
        paint: {
          "circle-color": "#a64e39",
          "circle-radius": [
            "interpolate",
            ["linear"],
            ["zoom"],
            ...CITY_RADIUS_STOPS,
          ] as any,
          "circle-stroke-color": "#fffef9",
          "circle-stroke-width": [
            "interpolate",
            ["linear"],
            ["zoom"],
            2,
            0.3,
            5,
            1,
            10,
            1.8,
          ],
        },
      });
      const hover = new libre.Popup({
        closeButton: false,
        maxWidth: "310px",
        closeOnMove: true,
        offset: 25,
      });
      let hovered: string | undefined;
      let closeHover: ReturnType<typeof setTimeout> | undefined;
      const cityCard = (c: City) =>
        `<p class="eyebrow">${esc(c.regionName)}</p><h3>${esc(c.name)}</h3><p>${esc(c.summary)}</p><a class="map-link" href="${esc(c.url)}">${text("Read about", "Leer sobre")} ${esc(c.name)} →</a>`;
      function cancelHoverClose() {
        if (closeHover) clearTimeout(closeHover);
      }
      function showHover(c: City) {
        if (
          countrySelection ||
          innerWidth < 700 ||
          matchMedia("(hover: none)").matches
        )
          return;
        cancelHoverClose();
        if (hovered === `${c.countryId}:${c.id}` && hover.isOpen()) return;
        hovered = `${c.countryId}:${c.id}`;
        hover.setLngLat([c.lon, c.lat]).setHTML(cityCard(c)).addTo(m);
        hover.getElement().addEventListener("mouseenter", cancelHoverClose);
        hover.getElement().addEventListener("mouseleave", hideHover);
      }
      function hideHover() {
        cancelHoverClose();
        closeHover = setTimeout(() => {
          hover.remove();
          hovered = undefined;
        }, 180);
      }
      function pickCity(point: { x: number; y: number }) {
        return nearestCity(
          mapCities,
          (p) => m.project(p),
          point,
          innerWidth < 700 || matchMedia("(pointer: coarse)").matches ? 23 : 15,
        );
      }
      m.on("mousemove", (event) => {
        if (m.isMoving()) return;
        if (countrySelection) {
          const id = m.queryRenderedFeatures(event.point, {
            layers: ["land"],
          })[0]?.properties?.id;
          m.getCanvas().style.cursor = atlas.countries.some(
            (c) => c.id === (id === "SJ" ? "NO" : id),
          )
            ? "pointer"
            : "";
          return;
        }
        const c = nearestCity(mapCities, (p) => m.project(p), event.point, 11);
        m.getCanvas().style.cursor = c ? "pointer" : "";
        if (c) showHover(c);
        else hideHover();
      });
      m.getCanvas().addEventListener("mouseleave", hideHover);
      m.on("zoomstart", () => {
        hover.remove();
        hovered = undefined;
      });
      m.on("click", (event) => {
        if(node.dataset.mapInspect === "true") return;
        if (countrySelection) {
          const id = m.queryRenderedFeatures(event.point, {
            layers: ["land"],
          })[0]?.properties?.id;
          const selected = atlas.countries.find(
            (c) => c.id === (id === "SJ" ? "NO" : id),
          );
          if (selected) {
            rememberMap();
            location.href = selected.url;
          }
          return;
        }
        const c = pickCity(event.point);
        if (!c) return;
        rememberMap();
        document.dispatchEvent(new Event("atlas-map-click"));
        setTimeout(() => {
          location.href = c.url;
        }, 65);
      });
      node!.addEventListener("click", (event) => {
        if ((event.target as Element).closest("a.map-link")) rememberMap();
      });
      function openCity(c: City) {
        rememberMap();
        location.href = c.url;
      }
      const shown = city ? [city] : mapCities.filter((c) => c.mapLabel);
      for (const c of shown) {
        const b = document.createElement("a");
        b.href = c.url;
        b.className = "city-pin";
        b.ariaLabel = `${text("Explore", "Explorar")} ${c.name}`;
        b.innerHTML = `<span class="pin-name">${esc(c.name)}</span>`;
        b.addEventListener("mouseenter", () => showHover(c));
        b.addEventListener("mouseleave", hideHover);
        b.addEventListener("click", (e) => {
          e.stopPropagation();
          rememberMap();
          if (e.detail > 0) {
            const rect = node!.getBoundingClientRect();
            const hit = nearestCity(
              mapCities,
              (p) => m.project(p),
              { x: e.clientX - rect.left, y: e.clientY - rect.top },
              cityDotHitRadius(m.getZoom()),
            );
            if (hit && (hit.id !== c.id || hit.countryId !== c.countryId)) {
              e.preventDefault();
              location.href = hit.url;
            }
          }
        });
        markers.push({
          marker: new libre.Marker({
            element: b,
            anchor: "left",
            offset: [8, 0],
          })
            .setLngLat([c.lon, c.lat])
            .addTo(m),
          city: c,
          kind: "city",
          element: b,
        });
        b.setAttribute("role", "link");
      }
      if (countrySelection)
        for (const c of atlas.countries) {
          const a = document.createElement("a");
          a.className = "country-label";
          a.href = c.url;
          a.textContent = c.name;
          a.addEventListener("click", (event) => {
            event.stopPropagation();
            rememberMap();
          });
          markers.push({
            marker: new libre.Marker({ element: a })
              .setLngLat(c.view.center)
              .addTo(m),
            kind: "country",
            element: a,
          });
          a.setAttribute("role", "link");
        }
      const leaders = document.createElementNS(
        "http://www.w3.org/2000/svg",
        "svg",
      );
      leaders.classList.add("map-label-leaders");
      leaders.setAttribute("aria-hidden", "true");
      node!.append(leaders);
      const offsets = new WeakMap<Marker, [number, number]>();
      function arrangeLabels() {
        const width = node!.clientWidth,
          height = node!.clientHeight;
        if (!width || !height) return;
        const rect = node!.getBoundingClientRect();
        const cityMarkers = markers.filter(
          (x) =>
            x.kind === "city" && x.city && x.element.style.display !== "none",
        );
        const candidates = cityMarkers
          .map((x) => {
            const p = m.project([x.city!.lon, x.city!.lat]);
            const box = x.element.getBoundingClientRect();
            return {
              key: `${x.city!.countryId}:${x.city!.id}`,
              x: p.x,
              y: p.y,
              width: box.width,
              height: box.height,
            };
          })
          .filter((p) => p.x >= 0 && p.x <= width && p.y >= 0 && p.y <= height);
        const radius = cityDotHitRadius(m.getZoom());
        const controls = Array.from(
          node!.parentElement!.querySelectorAll<HTMLElement>(
            ".map-bottom, .maplibregl-ctrl, .atlas-map-tools",
          ),
        )
          .filter((element) => element.offsetWidth && element.offsetHeight)
          .map((element) => {
            const box = element.getBoundingClientRect();
            return {
              x: box.left - rect.left - 3,
              y: box.top - rect.top - 3,
              width: box.width + 6,
              height: box.height + 6,
            };
          });
        const dots = mapCities
          .map((c) => m.project([c.lon, c.lat]))
          .filter((p) => p.x >= 0 && p.x <= width && p.y >= 0 && p.y <= height)
          .map((p) => ({
            x: p.x - radius,
            y: p.y - radius,
            width: 2 * radius,
            height: 2 * radius,
          }));
        const regionMarkers = markers.filter(
          (x) => x.kind === "region" && x.element.style.display !== "none",
        );
        const regionCandidates = regionMarkers
          .map((x, index) => {
            const p = m.project(x.marker.getLngLat());
            const b = x.element.getBoundingClientRect();
            return {
              key: String(index),
              x: p.x,
              y: p.y,
              width: b.width,
              height: b.height,
            };
          })
          .filter((p) => p.x >= 0 && p.x <= width && p.y >= 0 && p.y <= height);
        const regionPlaced = placeRegionLabels(
          regionCandidates,
          width,
          height,
          dots,
          controls,
        );
        const regionByKey = new Map(regionPlaced.map((p) => [p.key, p]));
        regionMarkers.forEach((x, index) => {
          const p = regionByKey.get(String(index));
          const next: [number, number] = p ? [p.dx, p.dy] : [0, 0];
          const last = offsets.get(x.marker);
          if (
            !last ||
            Math.abs(last[0] - next[0]) > 0.1 ||
            Math.abs(last[1] - next[1]) > 0.1
          ) {
            x.marker.setOffset(next);
            offsets.set(x.marker, next);
          }
        });
        // Compute boxes from the placement result: marker DOM updates can wait
        // until the next frame, making an immediate remeasurement stale.
        const regions = regionPlaced.map((p) => ({
          x: p.x + p.dx - p.width / 2,
          y: p.y + p.dy - p.height / 2,
          width: p.width,
          height: p.height,
        }));
        const placed = placeCityLabels(
          candidates,
          width,
          height,
          regions,
          [...dots, ...controls],
          Math.max(8, radius + 1),
        );
        const byKey = new Map(placed.map((p) => [p.key, p]));
        for (const x of cityMarkers) {
          const p = byKey.get(`${x.city!.countryId}:${x.city!.id}`);
          const next: [number, number] = p ? [p.dx, p.dy] : [8, 0];
          const last = offsets.get(x.marker);
          if (
            !last ||
            Math.abs(last[0] - next[0]) > 0.1 ||
            Math.abs(last[1] - next[1]) > 0.1
          ) {
            x.marker.setOffset(next);
            offsets.set(x.marker, next);
          }
        }
        leaders.setAttribute("viewBox", `0 0 ${width} ${height}`);
        leaders.innerHTML = placed
          .filter((p) => Math.abs(p.dy) > 3 || Math.abs(p.dx - 8) > 3)
          .map((p) => {
            const left = p.x + p.dx,
              top = p.y + p.dy - p.height / 2;
            const endX = Math.max(left, Math.min(left + p.width, p.x));
            const endY = Math.max(top, Math.min(top + p.height, p.y));
            return `<line x1="${p.x}" y1="${p.y}" x2="${endX}" y2="${endY}"/>`;
          })
          .join("");
      }
      function labels() {
        const z = m.getZoom();
        node!.style.setProperty(
          "--map-label-size",
          `${Math.max(10.5, Math.min(14, 10.5 + (z - 3) * 0.65))}px`,
        );
        node!.dataset.zoom = z.toFixed(2);
        for (const x of markers) {
          const visible =
            x.kind === "country"
              ? countrySelection
              : x.kind === "region"
                ? !!country || z >= 4.3
                : !!city || !!country || z >= 4.3;
          x.element.style.display = visible ? "flex" : "none";
        }
        arrangeLabels();
      }
      labels();
      m.on("zoom", labels);
      m.on("move", arrangeLabels);
      m.on("resize", arrangeLabels);
      if (regionId && country && !savedView) {
        const f = layers
          .find((x) => x.country.id === country.id)
          ?.geo.features.find((f: any) => f.properties.id === regionId);
        if (f) fit(f);
      }
      if (savedView) {
        for (const [selector, value] of [
          ["#map-region", savedView.region],
          ["#map-inset", savedView.inset],
        ]) {
          const select = $<HTMLSelectElement>(selector!);
          if (select) {
            select.value = value || "";
            select.dispatchEvent(new Event("atlas-select-refresh"));
          }
        }
      }
      saveView();
      $<HTMLSelectElement>("#map-region")?.addEventListener("change", (e) => {
        const id = (e.target as HTMLSelectElement).value;
        const insetSelect = $<HTMLSelectElement>("#map-inset");
        if (insetSelect) {
          insetSelect.value = "";
          insetSelect.dispatchEvent(new Event("atlas-select-refresh"));
        }
        const f = layers
          .find((x) => x.country.id === country?.id)
          ?.geo.features.find((f: any) => f.properties.id === id);
        if (f) fit(f);
        else reset();
      });
      function reset() {
        for (const selector of ["#map-region", "#map-inset"]) {
          const select = $<HTMLSelectElement>(selector);
          if (select) {
            select.value = "";
            select.dispatchEvent(new Event("atlas-select-refresh"));
          }
        }
        popup.remove();
        hover.remove();
        if (country?.view.bounds) {
          m.fitBounds(country.view.bounds, {
            padding: innerWidth < 700 ? 22 : 42,
            maxZoom: country.view.zoom,
            duration: reduced ? 0 : 500,
          });
          return;
        }
        m.flyTo({
          center: country
            ? country.view.center
            : atlas.overview?.center || [9, 52],
          zoom: overviewZoom(),
          duration: reduced ? 0 : 500,
        });
      }
      $<HTMLButtonElement>("#map-reset")?.addEventListener("click", reset);
      $<HTMLSelectElement>("#map-inset")?.addEventListener("change", (e) => {
        const value = (e.target as HTMLSelectElement).value;
        const inset = country?.view.insets[Number(value)];
        if (value !== "" && inset) {
          const regionSelect = $<HTMLSelectElement>("#map-region");
          if (regionSelect) {
            regionSelect.value = "";
            regionSelect.dispatchEvent(new Event("atlas-select-refresh"));
          }
          m.flyTo({
            center: inset.center,
            zoom: inset.zoom,
            duration: reduced ? 0 : 500,
          });
        }
      });
    });
    m.on("error", (event) => {
      if((event as {sourceId?:string}).sourceId?.startsWith("atlas-tools-")) {
        const detailStatus = node.querySelector<HTMLElement>(".map-tools-status");
        if(detailStatus) detailStatus.textContent=text("A detailed source is temporarily unavailable; the saved atlas is still usable.","Una fuente detallada no está disponible temporalmente; puedes seguir usando el atlas guardado.");
        return;
      }
      if (status) {
        status.hidden = false;
        status.textContent = text(
          "The map could not load. Every city is available below.",
          "No se pudo cargar el mapa. Las ciudades siguen disponibles más abajo.",
        );
      }
    });
    new ResizeObserver(() => m.resize()).observe(node);
  } catch {
    if (status) {
      status.hidden = false;
      status.innerHTML = `${text("Map unavailable.", "Mapa no disponible.")} <a href="${route("/cities/")}">${text("Explore cities", "Explorar ciudades")} →</a>`;
    }
  }
}
navigation();
languageControl();
soundControls();
carousels();
mapReturnLinks();
dropdowns();
void search();
void browse();
void compare();
void map();

if(document.querySelector("[data-timeline]"))void import("./timeline").then(({mountTimelines})=>mountTimelines());
if(document.querySelector("audio[data-recording-src],#calendar-filter"))void import("./media-calendar").then(({mountMediaCalendar})=>mountMediaCalendar());
