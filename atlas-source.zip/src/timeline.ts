import {tr} from "./feature-core";
export function mountTimelines() {
  for(const root of document.querySelectorAll<HTMLElement>("[data-timeline]")) {
    const panels=[...root.querySelectorAll<HTMLElement>("[data-event-panel]")],
      buttons=[...root.querySelectorAll<HTMLButtonElement>("[data-event]")],
      scrub=root.querySelector<HTMLInputElement>("[data-timeline-scrub]")!,
      previous=root.querySelector<HTMLButtonElement>("[data-timeline-previous]")!,
      next=root.querySelector<HTMLButtonElement>("[data-timeline-next]")!,
      play=root.querySelector<HTMLButtonElement>("[data-timeline-play]")!,
      position=root.querySelector<HTMLOutputElement>(".timeline-position")!;
    let index=0,timer:ReturnType<typeof setInterval>|undefined;
    const key="atlas-timeline:"+root.dataset.timeline;
    try{const saved=Number(sessionStorage.getItem(key));if(Number.isInteger(saved)&&saved>=0&&saved<panels.length)index=saved;}catch{}
    function pause() {if(timer)clearInterval(timer);timer=undefined;play.textContent=tr("Play","Reproducir");play.setAttribute("aria-pressed","false");}
    function show(value:number) {
      index=Math.max(0,Math.min(panels.length-1,value));
      panels.forEach((p,i)=>p.hidden=i!==index);
      buttons.forEach((b,i)=>{b.setAttribute("aria-pressed",String(i===index));b.setAttribute("aria-controls",panels[i].id);});
      scrub.value=String(index);scrub.setAttribute("aria-valuetext",buttons[index].textContent||"");
      previous.disabled=index===0;next.disabled=index===panels.length-1;
      position.value=`${index+1} / ${panels.length} · ${buttons[index].textContent}`;
      try{sessionStorage.setItem(key,String(index));}catch{}
    }
    for(const [i,b]of buttons.entries())b.addEventListener("click",()=>{pause();show(i);});
    previous.addEventListener("click",()=>{pause();show(index-1);});
    next.addEventListener("click",()=>{pause();show(index+1);});
    scrub.addEventListener("input",()=>{pause();show(Number(scrub.value));});
    play.addEventListener("click",()=>{
      if(timer){pause();return;}
      if(index===panels.length-1)show(0);
      play.textContent=tr("Pause","Pausar");play.setAttribute("aria-pressed","true");
      timer=setInterval(()=>{show(index+1);if(index===panels.length-1)pause();},5000);
    });
    document.addEventListener("visibilitychange",()=>{if(document.hidden)pause();});
    window.addEventListener("pagehide",pause,{once:true});
    root.querySelector<HTMLElement>(".timeline-controls")!.hidden=false;
    show(index);
  }
}
