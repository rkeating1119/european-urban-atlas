# European Urban Atlas · completed ten-country bilingual edition

Live site: https://rkeating1119.github.io/european-urban-atlas/

Release `33e920cbab96` is deployed and verified publicly. GitHub Pages run [42508762817](https://github.com/rkeating1119/european-urban-atlas/actions/runs/42508762817) succeeded from remote commit `48b3ff2045077c0b1d4a22ff58c595216c3bd3ff`. The publicly downloaded site archive matches the local SHA-256 `b8b479703249bc1c68245b86ac55e4ca9a24569a275ac1aa554ec5496991c445`. The permanent site works independently of the local preview, this chat and open browser tabs.

## Recovery and preservation

The original workspace, local development server, draft output and editorial scratch files survived the usage limit. Production still served161 cities while the saved preview contained417 across ten countries. Recovery commit6197f02 preserved all uncommitted canonical changes before edits. The prior preview and review files were backed up locally. No project was reconstructed or reset. Subsequent source commits preserve the completed reviews and final reference repair; local Git history and review records are exported separately.

## Completed edition

Spain60, France51, Italy50, UK50, Ireland25, Germany50, Switzerland30, Greece35, Norway31 and Sweden35:417 cities and123 regions in English and Spanish, across1112 generated routes. Every city has a short opening, broad social/economic overview and15 sections, including separate geography and architecture, ordinary outer neighborhoods, schools, dated politics, LGBTQ+ institutions and social life. English reading sections and overviews total631,119 words. Natural-language comparison descriptions accompany7 editorial scores and additional qualitative categories; there is no overall ranking.

City circles open cities, region names are separate links, labels preserve geographical anchors, and point sizes track zoom. Country pages use horizontal city carousels. In-site searchable menus, alias search, a persistent language toggle, subtle optional sounds and saved-map return are implemented. The final remaining Spain/Italy reviews were merged with exact field guards. Climate comparison descriptions previously discussing only scenery now use already reviewed weather text. Seville's employment paragraph uses dated primary workplace data; inconsistent optional housing indicators were rejected.

## Verification and limits

The strict non-draft build, TypeScript, worker tests and all map routing/label checks passed. The reader audit has0 errors across1112 routes,18963 bilingual prose fields and all417 profiles. It checked44,919 internal targets and16,743 fragment links. All49 public samples passed with the exact release, including both languages, all country pages, city samples, comparisons and assets. Browser interaction evidence is in BROWSER-QA-READER.json.

The final HTTP sweep covers2425 source URLs:2075 accessible,217 access-blocked,116 network-inconclusive,12 transient/server failures and5 network-unavailable, with0 confirmed broken links. Accessibility is not substantive source verification. A municipal Pamplona walls reference returning404 was replaced with its current, directly read official tourism article.

The21 reader-audit warnings record generalized coastal boundary discrepancies, missing comparable population metadata and recurring cross-city material, chiefly shared national education systems. Correct city points are retained; missing population counts are not invented. Language similarity/length/negation flags remain screening signals in LANGUAGE-SCREENING.json. The two date-transfer flags are a single1986 date moved between Kalamata architecture paragraphs, preserved at whole-section level. Ratings remain qualitative, and local LGBTQ+ institutions do not imply universal acceptance or safety.

No implementation or deployment step remains pending. Future maintenance includes refreshing dated political/demographic material, retrying restricted source links and adding comparable population data where available. Responsive testing is not physical-device certification.
